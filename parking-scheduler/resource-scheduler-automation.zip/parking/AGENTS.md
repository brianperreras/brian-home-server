# Parking automation — agent guide

Asurion Resource Scheduler parking booker: SSO (Node/Playwright) + booking (Java) + cron.

## Layout

| Path | Role |
|------|------|
| `bin/parking` | Global CLI (any directory); install via `scripts/install-cli.sh` |
| `install.sh` / `uninstall-schedules.sh` | Setup / remove cron |
| `resource-scheduler/` | Booking via `ResourceSchedulerBooker` main (`run-manual.sh`, `run-multiple.sh`, `run-scheduled.sh`) |
| `resource-scheduler-sso-login/` | SSO + keep-alive |
| `scripts/` | Shared: crontab, logging, pack-zip, install-cli |
| `Dockerfile` / `docker-compose.yml` / `docker/` | Unraid-native container (cron inside; appdata mounts) |
| `README.md` / `INSTALL.md` / `UNRAID.md` | User docs (Unraid = VM or Docker, not host User Scripts) |

## Non-negotiables

- **Never commit or zip secrets**: `.env`, `session.json`, `schedule.env`, `resources.txt`, `reservation.env`, passphrase files, `logs/`, `target/`, `node_modules/`.
- **SSO DOW = booking DOW − 1** (evening before; e.g. book `2-5` → SSO `1-4` at 9 PM). Optional override `SSO_SCHEDULE_DAYS`.
- **Manual book**: refresh session via keep-alive first; full SSO only if refresh fails. Do not start overnight keep-alive from booking (`SKIP_KEEPALIVE_LOOP=1`).
- **Cron book**: evening-before SSO + keep-alive; book cron starts **1 minute early**, refreshes + compiles, waits until `RS_SCHEDULE_TIME`, then books with `SKIP_SSO_LOGIN=1` / `SKIP_COMPILE=1`.
- **Logging**: use `scripts/log.sh` (bash), `src/log.js` (Node), `Log.java` (Java). Classify INFO / STEP / OK / SUCCESS / WARN / ERROR. Decorate CLI (`bin/parking`) and install/run scripts the same way.
- **After every change**: update AGENTS/rules/skills if needed, wire new user-facing scripts into `bin/parking`, then run `./scripts/pack-zip.sh`.

## Post-change checklist

1. Behavior / commands / layout changed? → update this file + `.cursor/rules/` + `.cursor/skills/` (mirror to `~/.cursor/` when workspace is `$HOME`)
2. New user-facing script? → add command + help + `case` in `bin/parking`; document in `README.md`
3. Always: `./scripts/pack-zip.sh` (unless user said not to)

## Common commands

Prefer the global CLI (works from any cwd after install):

```bash
parking install --schedules
parking book
parking book --dry-run            # simulate retry / next-slot / success
parking dry-run
parking login
parking refresh
parking keepalive start|stop|status
parking status
parking crontab
parking uninstall
parking pack-zip
```

`parking crontab` / cron section of `parking status` show the **target** book time (e.g. `Tue–Fri · midnight`) and a prewarm note; raw cron fires 1m early. Use `PARKING_CRON_RAW=1 parking crontab` for raw lines.

Or from the parking directory:

```bash
./install.sh --schedules
./uninstall-schedules.sh
./scripts/pack-zip.sh
cd resource-scheduler && ./run-multiple.sh
cd resource-scheduler-sso-login && ./run-manual-login.sh
```

## Skills

- `.cursor/skills/parking-post-change` — end-of-turn sync (AGENTS, CLI, zip)
- `.cursor/skills/update-parking-zip` — rebuild zip only
- `.cursor/skills/parking-schedules` — change cron days/times safely
