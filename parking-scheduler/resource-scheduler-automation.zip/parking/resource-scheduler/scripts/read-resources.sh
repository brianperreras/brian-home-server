#!/bin/bash
# Read resource IDs from resources.txt (handles missing trailing newline).
# Supports inline comments: "R405  # P2-C18"
read_resources() {
  local file="$1"
  local id
  RESOURCES=()
  while IFS= read -r line || [[ -n "$line" ]]; do
    line="${line//$'\r'/}"
    # Strip inline comments, then trim
    line="${line%%#*}"
    line="${line#"${line%%[![:space:]]*}"}"
    line="${line%"${line##*[![:space:]]}"}"
    [[ -z "$line" ]] && continue
    # First token is the resource ID (ignore any trailing junk)
    read -r id _ <<<"$line"
    [[ -z "$id" ]] && continue
    RESOURCES+=("$id")
  done < "$file"
}

# Look up bay label from inline comment: "R471  # P3-C18" → P3-C18
resource_label() {
  local file="$1"
  local want="$2"
  local line id label
  [ -f "$file" ] || return 0
  while IFS= read -r line || [[ -n "$line" ]]; do
    line="${line//$'\r'/}"
    [[ "$line" =~ ^[[:space:]]*# ]] && continue
    [[ "$line" != *"#"* ]] && continue
    id="${line%%#*}"
    id="${id#"${id%%[![:space:]]*}"}"
    id="${id%"${id##*[![:space:]]}"}"
    read -r id _ <<<"$id"
    [[ "$id" == "$want" ]] || continue
    label="${line#*#}"
    label="${label#"${label%%[![:space:]]*}"}"
    label="${label%"${label##*[![:space:]]}"}"
    # First token only (P3-C18)
    read -r label _ <<<"$label"
    printf '%s\n' "$label"
    return 0
  done < "$file"
}
