#!/bin/bash
# Load SSO session for Resource Scheduler tests.
# Source from run scripts:  source "$(dirname "$0")/scripts/session.sh"

_SESSION_SH_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TEST_DIR="$(cd "$_SESSION_SH_DIR/.." && pwd)"
SSO_DIR="$(cd "$TEST_DIR/../resource-scheduler-sso-login" && pwd)"
SESSION_FILE="${SESSION_FILE:-$SSO_DIR/output/session.json}"

# Cron-safe PATH and python (no-op if already set)
if [ -z "${PYTHON:-}" ] || ! command -v "${PYTHON:-python3}" >/dev/null 2>&1; then
  # shellcheck source=../../scripts/cron-env.sh
  source "$(cd "$TEST_DIR/.." && pwd)/scripts/cron-env.sh"
fi
PYTHON="${PYTHON:-python3}"

_session_log_error() {
  if declare -F log_error >/dev/null 2>&1; then
    log_error "$*"
  else
    echo "ERROR: $*" >&2
  fi
}

_session_log_warn() {
  if declare -F log_warn >/dev/null 2>&1; then
    log_warn "$*"
  else
    echo "WARN: $*" >&2
  fi
}

_session_log_info() {
  if declare -F log_info >/dev/null 2>&1; then
    log_info "$*"
  else
    echo "$*"
  fi
}

_session_log_step() {
  if declare -F log_step >/dev/null 2>&1; then
    log_step "$*"
  else
    echo "$*"
  fi
}

_session_log_ok() {
  if declare -F log_ok >/dev/null 2>&1; then
    log_ok "$*"
  else
    echo "$*"
  fi
}

load_session_from_file() {
  if [ ! -f "$SESSION_FILE" ]; then
    _session_log_error "Session file not found: $SESSION_FILE"
    return 1
  fi

  RS_SEC_TOKEN="$("$PYTHON" -c 'import json,sys; print(json.load(open(sys.argv[1])).get("secToken",""))' "$SESSION_FILE")"
  RS_COOKIES="$("$PYTHON" -c 'import json,sys; print(json.load(open(sys.argv[1])).get("cookieHeader",""))' "$SESSION_FILE")"
  RS_DISPLAY_NAME="$("$PYTHON" -c 'import json,sys; print(json.load(open(sys.argv[1])).get("displayName") or "")' "$SESSION_FILE")"

  if [ -z "$RS_SEC_TOKEN" ] || [ -z "$RS_COOKIES" ]; then
    _session_log_error "Session file is missing secToken or cookieHeader: $SESSION_FILE"
    return 1
  fi

  export RS_SEC_TOKEN RS_COOKIES RS_DISPLAY_NAME SESSION_FILE
}

session_captured_at() {
  "$PYTHON" -c 'import json,sys; print(json.load(open(sys.argv[1])).get("capturedAt",""))' "$SESSION_FILE" 2>/dev/null || true
}

validate_session_freshness() {
  local max_hours="${1:-6}"
  load_session_from_file || return 1

  local captured
  captured="$(session_captured_at)"
  if [ -z "$captured" ]; then
    _session_log_warn "session.json has no capturedAt timestamp"
    return 0
  fi

  local age_msg
  if ! age_msg="$("$PYTHON" - "$captured" "$max_hours" <<'PY'
import sys
from datetime import datetime, timezone

captured = datetime.fromisoformat(sys.argv[1].replace("Z", "+00:00"))
max_hours = float(sys.argv[2])
age_hours = (datetime.now(timezone.utc) - captured.astimezone(timezone.utc)).total_seconds() / 3600
if age_hours > max_hours:
    print(f"Session is {age_hours:.1f}h old (max {max_hours}h). Re-run 9 PM SSO login.", file=sys.stderr)
    sys.exit(1)
print(f"Session age: {age_hours:.1f}h (max {max_hours}h)")
PY
)"; then
    return 1
  fi
  _session_log_ok "$age_msg"
}

refresh_session_keepalive() {
  if [ ! -f "$SESSION_FILE" ]; then
    return 1
  fi
  if [ ! -f "$SSO_DIR/src/session-keepalive.js" ]; then
    return 1
  fi
  if ! command -v node >/dev/null 2>&1; then
    _session_log_warn "node not found — cannot refresh session"
    return 1
  fi
  _session_log_step "Refreshing SSO session (keep-alive)..."
  if (cd "$SSO_DIR" && node src/session-keepalive.js); then
    load_session_from_file
    return 0
  fi
  _session_log_warn "Session refresh failed — will run full SSO login"
  return 1
}

run_sso_login() {
  if [ ! -x "$SSO_DIR/run-manual-login.sh" ]; then
    _session_log_error "SSO login script not found: $SSO_DIR/run-manual-login.sh"
    return 1
  fi
  _session_log_step "Running SSO login (approve PingID if prompted)..."
  # Nested under booking logs — skip second tee; do not start overnight keep-alive loop
  (cd "$SSO_DIR" && SKIP_LOGIN_LOG=1 SKIP_KEEPALIVE_LOOP=1 ./run-manual-login.sh)
}

ensure_session() {
  if [ "${SKIP_SSO_LOGIN:-0}" = "1" ]; then
    _session_log_info "SKIP_SSO_LOGIN=1 — using existing session file"
    load_session_from_file
    return
  fi

  # Prefer a quiet token refresh; full SSO only when session is missing/expired
  if refresh_session_keepalive; then
    _session_log_ok "SSO session refreshed — ready to book"
    return 0
  fi

  run_sso_login
  load_session_from_file
}

# Prints JVM args for session (use with: java ... $(java_session_args) ...)
java_session_args() {
  if [ -z "${RS_SEC_TOKEN:-}" ] || [ -z "${RS_COOKIES:-}" ]; then
    _session_log_error "Session not loaded. Call ensure_session first."
    return 1
  fi
  printf '%s\n' \
    "-DsessionFile=$SESSION_FILE" \
    "-DsecToken=$RS_SEC_TOKEN" \
    "-Dcookies=$RS_COOKIES"
  if [ -n "${RS_DISPLAY_NAME:-}" ]; then
    printf '%s\n' "-DdisplayName=$RS_DISPLAY_NAME"
  fi
}
