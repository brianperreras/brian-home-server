#!/bin/bash
# Load reservation.env (parking slot start/end times for submit.asp).
load_reservation_env() {
  local dir="${1:-.}"
  if [ -f "$dir/reservation.env" ]; then
    # shellcheck disable=SC1091
    set -a
    source "$dir/reservation.env"
    set +a
  fi
  export RS_START_HR="${RS_START_HR:-6+AM}"
  export RS_START_MIN="${RS_START_MIN:-00}"
  export RS_END_HR="${RS_END_HR:-3+PM}"
  export RS_END_MIN="${RS_END_MIN:-00}"
}

rs_time_display() {
  local hr="$1" min="${2:-00}"
  hr="${hr//+/ }"
  if [ "$min" = "00" ] || [ -z "$min" ]; then
    printf '%s' "$hr"
    return
  fi
  local num="${hr% *}"
  local suffix="${hr##* }"
  printf '%s:%s %s' "$num" "$min" "$suffix"
}

reservation_window_display() {
  printf '%s – %s' \
    "$(rs_time_display "$RS_START_HR" "$RS_START_MIN")" \
    "$(rs_time_display "$RS_END_HR" "$RS_END_MIN")"
}
