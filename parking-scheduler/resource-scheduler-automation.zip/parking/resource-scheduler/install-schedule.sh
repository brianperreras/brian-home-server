#!/bin/bash
# Install reservation schedule from schedule.env (days + hh:mm:ss).
# Uses session.json from evening SSO login — does not re-authenticate.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
RUN_SCRIPT="$SCRIPT_DIR/run-scheduled.sh"
LABEL="com.asurion.resourcescheduler.reservations-weekdays"

# shellcheck source=../scripts/log.sh
source "$(cd "$SCRIPT_DIR/.." && pwd)/scripts/log.sh"

if [ -f "$SCRIPT_DIR/schedule.env" ]; then
  # shellcheck disable=SC1091
  set -a
  source "$SCRIPT_DIR/schedule.env"
  set +a
fi

SCHEDULE_TZ="${RS_SCHEDULE_TZ:-Asia/Manila}"
SCHEDULE_DAYS="${RS_SCHEDULE_DAYS:-1-5}"
SCHEDULE_TIME="${RS_SCHEDULE_TIME:-}"

if [ -n "$SCHEDULE_TIME" ]; then
  if [[ ! "$SCHEDULE_TIME" =~ ^([0-9]{1,2}):([0-9]{2})(:([0-9]{2}))?$ ]]; then
    log_error "Invalid RS_SCHEDULE_TIME='$SCHEDULE_TIME' (use hh:mm:ss)"
    exit 1
  fi
  SCHEDULE_HOUR=$((10#${BASH_REMATCH[1]}))
  SCHEDULE_MINUTE=$((10#${BASH_REMATCH[2]}))
  SCHEDULE_SECOND=$((10#${BASH_REMATCH[4]:-0}))
else
  SCHEDULE_HOUR="${RS_SCHEDULE_HOUR:-0}"
  SCHEDULE_MINUTE="${RS_SCHEDULE_MINUTE:-0}"
  SCHEDULE_SECOND=0
  SCHEDULE_TIME="$(printf '%02d:%02d:%02d' "$SCHEDULE_HOUR" "$SCHEDULE_MINUTE" "$SCHEDULE_SECOND")"
fi

chmod +x "$RUN_SCRIPT"

log_header "Booking schedule install"
log_kv "Days" "$SCHEDULE_DAYS"
log_kv "Time" "${SCHEDULE_TIME} (${SCHEDULE_TZ})"
log_kv "Script" "$RUN_SCRIPT"
log_kv "Session" "../resource-scheduler-sso-login/output/session.json"

# shellcheck source=../scripts/cron-dow.sh
source "$(cd "$SCRIPT_DIR/.." && pwd)/scripts/cron-dow.sh"

install_cron() {
  bash "$(cd "$SCRIPT_DIR/.." && pwd)/scripts/install-crontab.sh"
}

install_launchd() {
  local agents_dir="$HOME/Library/LaunchAgents"
  local plist_path="$agents_dir/${LABEL}.plist"
  local stdout_log="$SCRIPT_DIR/logs/launchd.out.log"
  local stderr_log="$SCRIPT_DIR/logs/launchd.err.log"
  local days_csv

  days_csv="$(expand_cron_dow "$SCHEDULE_DAYS" | paste -sd, -)"

  mkdir -p "$agents_dir" "$SCRIPT_DIR/logs"

  python3 - "$plist_path" "$LABEL" "$RUN_SCRIPT" "$SCHEDULE_HOUR" "$SCHEDULE_MINUTE" "$days_csv" "$stdout_log" "$stderr_log" <<'PY'
import plistlib
import sys
from pathlib import Path

plist_path, label, run_script, hour, minute, days_csv, stdout_log, stderr_log = sys.argv[1:9]
hour, minute = int(hour), int(minute)
days = [int(x) for x in days_csv.split(",") if x != ""]

intervals = [{"Weekday": d, "Hour": hour, "Minute": minute} for d in days]

data = {
    "Label": label,
    "ProgramArguments": [run_script],
    "StartCalendarInterval": intervals,
    "StandardOutPath": stdout_log,
    "StandardErrorPath": stderr_log,
    "RunAtLoad": False,
}

Path(plist_path).write_bytes(plistlib.dumps(data))
PY

  launchctl bootout "gui/$(id -u)/$LABEL" 2>/dev/null || true
  launchctl bootstrap "gui/$(id -u)" "$plist_path"

  log_ok "Installed LaunchAgent (macOS):"
  log_kv "Plist" "$plist_path"
  log_kv "Schedule" "Days ${SCHEDULE_DAYS} at ${SCHEDULE_HOUR}:$(printf '%02d' "$SCHEDULE_MINUTE") (waits :$(printf '%02d' "$SCHEDULE_SECOND"))"
  log_kv "Logs" "$stdout_log"
}

case "$(uname -s)" in
  Darwin)
    install_launchd
    ;;
  Linux)
    install_cron
    ;;
  *)
    log_error "Unsupported OS. Add this to your scheduler manually:"
    log_info "CRON_TZ=${SCHEDULE_TZ}"
    log_info "${SCHEDULE_MINUTE} ${SCHEDULE_HOUR} * * ${SCHEDULE_DAYS} ${RUN_SCRIPT}"
    exit 1
    ;;
esac

log_section "Pipeline"
log_info "Evening SSO (booking days − 1, or SSO_SCHEDULE_DAYS override) → keep-alive"
log_info "Booking days ${SCHEDULE_DAYS} at ${SCHEDULE_TIME} → retry slots until secured"
log_success "Booking schedule installed"
log_info "Test: $RUN_SCRIPT"
