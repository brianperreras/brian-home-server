# Update Instructions

## ⚠️ IMPORTANT: What to Update from curl Commands

When provided with a new `curl` command, session credentials are normally loaded automatically via SSO login (`./run-manual.sh` / `./run-multiple.sh`). For manual curl updates, only change session fields unless explicitly told otherwise:

### ✅ Session credentials (automatic)

Run scripts load from `../resource-scheduler-sso-login/output/session.json`:

- `secToken` → `-DsecToken`
- `cookieHeader` → `-Dcookies`
- `displayName` → booking `txtDesc` as `First Last` (SSO often stores `Last, First`; optional `-DbookingDesc` override)

Do **not** hardcode a person name in `buildFormData()` — it must stay dynamic from SSO.

Re-run SSO login: `../resource-scheduler-sso-login/run-manual-login.sh`

### ✅ Legacy manual curl extract (if needed):

1. **SEC_TOKEN**
   - Extract from `--data-raw` parameter: `sec_token=...`
   - URL decode if needed (e.g., `%3D` → `=`)

2. **COOKIES**
   - Extract from `-b` or `--cookie` parameter
   - Copy the entire cookie string as-is

### ❌ DO NOT Update (unless explicitly requested):

- QR_DATE / reservation date (auto: today + 7 days)
- START_HR
- QR_END_DATE
- END_HR
- SCHEDULED_EXECUTION_TIME
- buildFormData() method contents
- buildRequest() method contents
- Any other configuration fields

## How to Extract Values from curl:

### Example curl:
```bash
curl 'https://example.com/submit.asp' \
  -b 'Cookie1=value1; Cookie2=value2; SecurityToken=xxx' \
  --data-raw 'sec_token=abc123xyz%3D%3D&other=data'
```

### Extract:
1. **SEC_TOKEN**: `abc123xyz==` (URL decoded from `abc123xyz%3D%3D`)
2. **COOKIES**: `Cookie1=value1; Cookie2=value2; SecurityToken=xxx`

## After Updating:

Run the test:
```bash
./run-manual.sh
```

---
**Note**: This restriction helps maintain consistency and prevents accidental overwrites of other configuration values that may have been intentionally set.
