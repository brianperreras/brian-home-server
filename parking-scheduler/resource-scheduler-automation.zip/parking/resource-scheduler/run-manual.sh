#!/bin/bash
# Book first slot only (first line in resources.txt); still retries that slot until timeout.
# Usage: ./run-manual.sh [--dry-run]
set -euo pipefail
cd "$(dirname "$0")"

# shellcheck source=../scripts/log.sh
source "$(cd "$(dirname "$0")/.." && pwd)/scripts/log.sh"
# shellcheck source=scripts/read-resources.sh
source scripts/read-resources.sh

DRY_ARGS=()
while [ $# -gt 0 ]; do
  case "$1" in
    --dry-run|-n)
      DRY_ARGS+=(--dry-run)
      shift
      ;;
    *)
      break
      ;;
  esac
done

if [ -z "${RESOURCE_ID:-}" ] && [ -f resources.txt ]; then
  read_resources resources.txt
  RESOURCE_ID="${RESOURCES[0]:-}"
fi
if [ -z "${RESOURCE_ID:-}" ]; then
  log_error "No booking slot configured. Run ../install.sh or create resources.txt"
  exit 1
fi

export RESOURCE_ID
exec ./run-multiple.sh "${DRY_ARGS[@]+"${DRY_ARGS[@]}"}" "$RESOURCE_ID"
