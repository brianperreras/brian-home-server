# Resource Scheduler Booker

Automated parking booking for Asurion Resource Scheduler (SSO + `submit.asp`).

Books **exactly one** reservation per run: tries slots from `resources.txt` in order, then retries the list until one succeeds or the timeout is hit.

Booking is a plain Java `main` (`com.apitest.reservation.ResourceSchedulerBooker`), not a JUnit test.

## Scripts


| Script             | When                    | What                                                                             |
| ------------------ | ----------------------- | -------------------------------------------------------------------------------- |
| `run-manual.sh`    | You run it              | SSO + book **first** slot from `resources.txt` (retries that slot until secured) |
| `run-multiple.sh`  | You run it              | SSO + try **all** slots in order; retry rounds until one books                   |
| `run-scheduled.sh` | Cron at configured time | Wait until `hh:mm:ss`, refresh session, then book via `run-multiple.sh` (no SSO) |




## Project layout

```
resource-scheduler/
├── resources.txt           # slot try order (ID + optional name comment)
├── reservation.env         # parking slot start/end on booked day
├── schedule.env            # days, hh:mm:ss, days-ahead, retry settings
├── src/main/java/.../      # ResourceSchedulerBooker (main), SessionSupport, Log
├── lib/                    # OkHttp + okio + kotlin-stdlib
├── scripts/                # session.sh, read-resources.sh, load-reservation-env.sh
├── run-manual.sh
├── run-multiple.sh
└── run-scheduled.sh
```



## Manual runs

```bash
./run-manual.sh                       # first slot only
./run-multiple.sh                     # all slots in order; retry until secured
./run-multiple.sh R406 R405 R404      # override list from CLI
SKIP_SSO_LOGIN=1 ./run-manual.sh      # book only — no refresh / SSO
SKIP_SSO_LOGIN=1 ./run-multiple.sh
RESERVATION_DATE=2026-7-4 ./run-manual.sh
```

Manual booking **refreshes the SSO session** (keep-alive) before booking. If refresh fails or there is no session, it runs full SSO login (PingID). It does **not** start the overnight keep-alive loop (that is only for `../resource-scheduler-sso-login/run-manual-login.sh` / evening cron).

Configure slots and reservation times during setup: `../install.sh`

Reconfigure slots: `rm .booking-configured && ../install.sh --skip-credentials`  
Or edit `resources.txt` directly (first slot is also the SSO keep-alive `TopicId`).

## Multi-slot retry

`resources.txt` lists slots in try order. Exactly **one** reservation is booked:

1. Try each slot in order
2. Sleep `BOOK_RETRY_SLEEP_SEC` between failed attempts
3. If the full list fails, start another round
4. Stop on first success, or when `BOOK_RETRY_TIMEOUT_SEC` is exceeded

Example `resources.txt` (car / `C` slots only; see `resources.txt.example` for the full P2–P5 list):

```text
# Slot try order (car / "C" only — motorcycles "M" excluded)
# Primary (also used for SSO keep-alive TopicId)

# P2 Parking
R400  # P2-C12
R405  # P2-C18
R406  # P2-C19

# P3 Parking
R471  # P3-C18
R413  # P3-C30
```

Copy the full mapped list: `cp resources.txt.example resources.txt`  
Non-interactive install: `RS_SLOTS=R400,R405,R406 ../install.sh --skip-credentials`  
(Legacy `RS_PRIMARY_SLOT` / `RS_BACKUP_SLOT` still merge into the list.)

## Reservation time window

Start/end time **on the booked day** — set in `reservation.env`:

```bash
RS_START_HR=7+AM
RS_END_HR=3+PM
```

Prompted during `../install.sh`. Reconfigure: `rm .reservation-configured && ../install.sh --skip-credentials`

## Weekly schedule (`schedule.env`)

```bash
RS_SCHEDULE_TZ=Asia/Manila
RS_SCHEDULE_DAYS=1-5          # cron DOW: 0=Sun … 6=Sat
RS_SCHEDULE_TIME=00:00:00     # target submit time; cron starts 1m early (prewarm)
RS_RESERVATION_DAYS_AHEAD=7   # reservation date = run date + N days
BOOK_RETRY_TIMEOUT_SEC=180
BOOK_RETRY_SLEEP_SEC=2
MAX_SESSION_AGE_HOURS=6
```

After editing, reinstall cron:

```bash
./install-schedule.sh
# or: cd .. && ./install.sh --schedules
```

Race path (default): cron fires **1 minute early** → refresh session + compile Java → wait until `RS_SCHEDULE_TIME` → book immediately (no second refresh/compile). Example: target `00:00:00` Tue–Fri → cron at `23:59` Mon–Thu.

```bash
RS_SCHEDULE_DAYS=2-5
RS_SCHEDULE_TIME=00:00:00
```

SSO cron DOW defaults to `RS_SCHEDULE_DAYS − 1` (e.g. booking `3-5` → SSO `2-4` at 9 PM). Override with `SSO_SCHEDULE_DAYS` in the SSO `.env` if needed.

## Logs


| File                            | When                                           | What                                |
| ------------------------------- | ---------------------------------------------- | ----------------------------------- |
| `logs/run-YYYYMMDD-HHMMSS.log`  | Manual `./run-multiple.sh` / `./run-manual.sh` | Full console output (SSO + booking) |
| `logs/scheduled-*.log`          | Cron `./run-scheduled.sh` (incl. 23:59 prewarm)| Scheduled booking run               |
| `logs/scheduled.log`            | Cron                                           | Append-only history                 |
| `logs/responses/R123-last.html` | Every booking attempt                          | Last `submit.asp` **HTML** response |


**Why HTML?** Resource Scheduler’s booking endpoint returns an HTML schedule page, not JSON. The test saves that page so you can inspect errors (slot taken, session expired, etc.). Open it in a browser or search for phrases like `not available`.

Scheduled SSO logs live in `../resource-scheduler-sso-login/logs/`.

## Scheduled pipeline (default)


| Time (Manila)        | SSO project              | Booking project                                                      |
| -------------------- | ------------------------ | -------------------------------------------------------------------- |
| **9:00 PM** (book − 1) | `run-scheduled-login.sh` | — (evening before booking days)                                    |
| **23:59** (prewarm)  | —                        | `run-scheduled.sh` refresh + compile, wait for `RS_SCHEDULE_TIME`    |
| **00:00:00** (submit)| —                        | book immediately (retry slots until one succeeds)                    |


```bash
cd .. && ./install.sh --schedules
```

Test: `SKIP_SSO_LOGIN=1 ./run-scheduled.sh`

## Booking display name (SSO)

The reservation name (`txtDesc` on `submit.asp`) is **not** hardcoded. It comes from the logged-in SSO user:

1. SSO login / keep-alive scrapes the schedule page and writes `displayName` to `../resource-scheduler-sso-login/output/session.json` (often `Last, First`)
2. Booking converts that to `First Last` for the form
3. If `session.json` has no name yet, booking scrapes it again when refreshing `sec_token`

Optional JVM override (advanced): `-DbookingDesc="First Last"`

After changing SSO users, re-run login so `displayName` updates:

```bash
cd ../resource-scheduler-sso-login && ./run-manual-login.sh
```

## Prerequisites

- Java 11+, `lib/` JARs, `javac`
- Python 3 (scheduled second-precision wait + session helpers)
- SSO credentials in `../resource-scheduler-sso-login/.env`
- Booking slots in `resources.txt` (from `../install.sh`)
- Fresh `session.json` with `secToken`, `cookieHeader`, and preferably `displayName`

Session credentials come from SSO (`../resource-scheduler-sso-login/output/session.json`). Full install guide: `../INSTALL.md`.