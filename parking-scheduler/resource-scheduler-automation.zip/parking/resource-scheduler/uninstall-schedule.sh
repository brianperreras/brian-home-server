#!/bin/bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
LABEL="com.asurion.resourcescheduler.reservations-weekdays"

case "$(uname -s)" in
  Darwin)
    launchctl bootout "gui/$(id -u)/$LABEL" 2>/dev/null || true
    rm -f "$HOME/Library/LaunchAgents/${LABEL}.plist"
    echo "Removed LaunchAgent: $LABEL"
    ;;
  Linux)
    bash "$(cd "$SCRIPT_DIR/.." && pwd)/scripts/uninstall-crontab.sh"
    ;;
  *)
    echo "Remove scheduled job manually."
    exit 1
    ;;
esac
