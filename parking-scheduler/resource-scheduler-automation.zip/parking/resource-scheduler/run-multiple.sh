#!/bin/bash
# Sequential multi-slot booking — exactly ONE reservation per run.
# Tries resources.txt in order; on full-list failure, retries until success or timeout.
# Usage: ./run-multiple.sh [--dry-run] [R123] [R456 ...]
# Or:    ./run-multiple.sh   (reads resources.txt)
#
# Dry-run (no SSO / no submit.asp):
#   ./run-multiple.sh --dry-run
#   BOOK_DRY_RUN=1 ./run-multiple.sh
#   BOOK_DRY_FAIL_COUNT=2 BOOK_DRY_SLEEP_SEC=0.5 ./run-multiple.sh --dry-run
#   BOOK_DRY_SUCCESS_SLOT=R406 ./run-multiple.sh --dry-run

set -euo pipefail
cd "$(dirname "$0")"

# shellcheck source=../scripts/log.sh
source "$(cd "$(dirname "$0")/.." && pwd)/scripts/log.sh"

DRY_RUN="${BOOK_DRY_RUN:-0}"
ARGS=()
while [ $# -gt 0 ]; do
  case "$1" in
    --dry-run|-n)
      DRY_RUN=1
      shift
      ;;
    --help|-h)
      cat <<EOF
Usage: ./run-multiple.sh [--dry-run] [R123] [R456 ...]

  --dry-run   Simulate slot tries / retries / success (no SSO, no booking)

Dry-run env:
  BOOK_DRY_FAIL_COUNT=N       Fail first N attempts, then succeed (default: 2)
  BOOK_DRY_SUCCESS_SLOT=Rxxx  Succeed only when this slot is tried (optional)
  BOOK_DRY_SLEEP_SEC=0.5      Sleep between simulated attempts (default: 0.5)
  BOOK_DRY_TIMEOUT_SEC=30     Retry timeout for dry-run (default: 30)
EOF
      exit 0
      ;;
    *)
      ARGS+=("$1")
      shift
      ;;
  esac
done
set -- "${ARGS[@]+"${ARGS[@]}"}"

# Manual runs: tee stdout/stderr to logs/run-*.log (scheduled wrapper already logs)
if [ -t 1 ] && [ "${SKIP_RUN_LOG:-0}" != "1" ]; then
  mkdir -p logs
  RUN_LOG_FILE="logs/run-$(date +%Y%m%d-%H%M%S).log"
  # Preserve colors on the terminal after tee redirects stdout
  parking_log_enable_color
  export PARKING_LOG_COLOR=1
  export FORCE_COLOR=1
  # Terminal keeps colors; log file strips ANSI escape codes
  exec > >(tee >(sed -e 's/\x1b\[[0-9;]*[a-zA-Z]//g' >>"$RUN_LOG_FILE")) 2>&1
  log_info "Log file: $RUN_LOG_FILE"
fi

# Optional schedule.env (retry timeout, days-ahead, scheduled wait)
if [ -f schedule.env ]; then
  # shellcheck disable=SC1091
  set -a
  source schedule.env
  set +a
fi

# shellcheck source=scripts/read-resources.sh
source scripts/read-resources.sh
# shellcheck source=scripts/load-reservation-env.sh
source scripts/load-reservation-env.sh
load_reservation_env "$PWD"

BOOK_RETRY_TIMEOUT_SEC="${BOOK_RETRY_TIMEOUT_SEC:-180}"
BOOK_RETRY_SLEEP_SEC="${BOOK_RETRY_SLEEP_SEC:-2}"
RS_RESERVATION_DAYS_AHEAD="${RS_RESERVATION_DAYS_AHEAD:-7}"

if [ "$DRY_RUN" = "1" ]; then
  BOOK_RETRY_TIMEOUT_SEC="${BOOK_DRY_TIMEOUT_SEC:-30}"
  BOOK_RETRY_SLEEP_SEC="${BOOK_DRY_SLEEP_SEC:-0.5}"
fi

RESOURCES=()

if [ $# -eq 0 ]; then
    if [ -f "resources.txt" ]; then
        log_step "Reading resources from resources.txt..."
        read_resources resources.txt
    else
        log_error "No arguments and resources.txt not found"
        exit 1
    fi
else
    RESOURCES=("$@")
fi

if [ ${#RESOURCES[@]} -eq 0 ]; then
    log_error "No resources to process"
    exit 1
fi

if [ "$DRY_RUN" = "1" ]; then
  log_header "DRY-RUN Booking (simulate retry — no SSO / no submit)"
else
  log_header "Sequential Booking (one slot — retry until secured)"
fi
log_kv "Try order" "${RESOURCES[*]}"
log_kv "Retry timeout" "${BOOK_RETRY_TIMEOUT_SEC}s"
log_kv "Sleep between" "${BOOK_RETRY_SLEEP_SEC}s"
if [ ${#RESOURCES[@]} -gt 1 ]; then
    log_info "Multiple slots — stops after first successful booking"
fi

if [ "$DRY_RUN" = "1" ]; then
  BOOK_DRY_FAIL_COUNT="${BOOK_DRY_FAIL_COUNT:-2}"
  # Cap fail count so we always succeed within the list unless SUCCESS_SLOT is set
  if [ -z "${BOOK_DRY_SUCCESS_SLOT:-}" ] && [ "$BOOK_DRY_FAIL_COUNT" -ge "${#RESOURCES[@]}" ]; then
    BOOK_DRY_FAIL_COUNT=$((${#RESOURCES[@]} - 1))
    [ "$BOOK_DRY_FAIL_COUNT" -lt 0 ] && BOOK_DRY_FAIL_COUNT=0
  fi
  log_warn "DRY-RUN mode — no real reservation will be created"
  log_kv "Sim fail count" "$BOOK_DRY_FAIL_COUNT (then succeed)"
  if [ -n "${BOOK_DRY_SUCCESS_SLOT:-}" ]; then
    log_kv "Sim success slot" "$BOOK_DRY_SUCCESS_SLOT"
  fi
  log_kv "Reservation window" "$(reservation_window_display) (not submitted)"
  log_kv "Days ahead" "${RS_RESERVATION_DAYS_AHEAD}"
  log_ok "Skipping SSO + Java compile (dry-run)"
else
  # shellcheck source=scripts/session.sh
  source scripts/session.sh
  ensure_session
  log_ok "Session: ${SESSION_FILE}"

  mapfile -t SESSION_ARGS < <(java_session_args)

  if [ "${SKIP_COMPILE:-0}" = "1" ] && [ -d target/classes ] \
      && [ -f target/classes/com/apitest/reservation/ResourceSchedulerBooker.class ]; then
    log_ok "Skipping Java compile (pre-compiled)"
  else
    log_step "Compiling booking Java..."
    mkdir -p target/classes
    javac -cp "lib/*" -d target/classes src/main/java/com/apitest/reservation/*.java
    log_ok "Compilation successful"
  fi

  EXTRA_JAVA_ARGS=()
  if [ -n "${RESERVATION_DATE:-}" ]; then
      EXTRA_JAVA_ARGS+=("-DreservationDate=${RESERVATION_DATE}")
  fi
  EXTRA_JAVA_ARGS+=("-DreservationDaysAhead=${RS_RESERVATION_DAYS_AHEAD}")
  if [ -n "${SCHEDULED_EXECUTION_TIME:-}" ]; then
      EXTRA_JAVA_ARGS+=("-DscheduledExecutionTime=${SCHEDULED_EXECUTION_TIME}")
      log_info "Scheduled wait until: ${SCHEDULED_EXECUTION_TIME}"
  fi
  EXTRA_JAVA_ARGS+=(
    "-DstartHr=${RS_START_HR}" "-DstartMin=${RS_START_MIN}"
    "-DendHr=${RS_END_HR}" "-DendMin=${RS_END_MIN}"
  )
  EXTRA_JAVA_ARGS+=("-Dparking.log.color=${PARKING_LOG_COLOR:-1}")

  log_kv "Reservation window" "$(reservation_window_display)"
  log_kv "Days ahead" "${RS_RESERVATION_DAYS_AHEAD}"
fi

ATTEMPT=0

book_resource() {
    local resource=$1
    if [ "$DRY_RUN" = "1" ]; then
      ATTEMPT=$((ATTEMPT + 1))
      log_info "[dry-run] Attempt #$ATTEMPT for $resource — calling submit.asp (simulated)"

      local succeed=0
      if [ -n "${BOOK_DRY_SUCCESS_SLOT:-}" ]; then
        if [ "$resource" = "$BOOK_DRY_SUCCESS_SLOT" ] && [ "$ATTEMPT" -gt "$BOOK_DRY_FAIL_COUNT" ]; then
          succeed=1
        fi
      elif [ "$ATTEMPT" -gt "$BOOK_DRY_FAIL_COUNT" ]; then
        succeed=1
      fi

      # Brief pause so the retry flow is visible
      sleep "$BOOK_RETRY_SLEEP_SEC"

      if [ "$succeed" -eq 1 ]; then
        return 0
      fi

      log_warn "[dry-run] Response contains: \"not available\" (slot taken)"
      return 1
    fi

    local label=""
    local java_args=()
    if [ -f resources.txt ]; then
      label="$(resource_label resources.txt "$resource" || true)"
    fi
    java_args+=(-DresourceId="$resource")
    if [ -n "$label" ]; then
      java_args+=(-DresourceLabel="$label")
    fi

    java -cp "lib/*:target/classes" \
        "${SESSION_ARGS[@]}" \
        "${EXTRA_JAVA_ARGS[@]}" \
        "${java_args[@]}" \
        com.apitest.reservation.ResourceSchedulerBooker
}

START_EPOCH="$(date +%s)"
ROUND=0

while true; do
    ROUND=$((ROUND + 1))
    NOW_EPOCH="$(date +%s)"
    ELAPSED=$((NOW_EPOCH - START_EPOCH))
    REMAINING=$((BOOK_RETRY_TIMEOUT_SEC - ELAPSED))

    if [ "$ELAPSED" -ge "$BOOK_RETRY_TIMEOUT_SEC" ]; then
        log_error "No slot booked — retry timeout (${BOOK_RETRY_TIMEOUT_SEC}s) exceeded after ${ROUND} round(s)"
        exit 1
    fi

    log_section "Round $ROUND (elapsed ${ELAPSED}s, ~${REMAINING}s remaining)"

    for i in "${!RESOURCES[@]}"; do
        NOW_EPOCH="$(date +%s)"
        ELAPSED=$((NOW_EPOCH - START_EPOCH))
        if [ "$ELAPSED" -ge "$BOOK_RETRY_TIMEOUT_SEC" ]; then
            log_error "No slot booked — retry timeout (${BOOK_RETRY_TIMEOUT_SEC}s) exceeded"
            exit 1
        fi

        RESOURCE="${RESOURCES[$i]}"
        CURRENT=$((i + 1))
        TOTAL=${#RESOURCES[@]}

        log_step "[round $ROUND | $CURRENT/$TOTAL] Trying: $RESOURCE"

        book_status=0
        book_resource "$RESOURCE" || book_status=$?

        if [ "$book_status" -eq 0 ]; then
            if [ "$DRY_RUN" = "1" ]; then
              res_date="${RESERVATION_DATE:-}"
              if [ -z "$res_date" ]; then
                res_date="$(python3 -c "
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
d = datetime.now(ZoneInfo('Asia/Manila')).date() + timedelta(days=int('${RS_RESERVATION_DAYS_AHEAD:-7}'))
print(f'{d.year}-{d.month}-{d.day}')
")"
              fi
              space_label="$RESOURCE"
              if [ -f resources.txt ]; then
                space_label="$(resource_label resources.txt "$RESOURCE" || true)"
                [ -z "$space_label" ] && space_label="$RESOURCE"
              fi
              res_date_label="$(python3 -c "
from datetime import datetime
y, m, d = [int(x) for x in '${res_date}'.split('-')]
dt = datetime(y, m, d)
print(dt.strftime('%A') + ' · ' + '${res_date}')
")"
              log_success_box "DRY-RUN — would book" \
                "Space" "$space_label" \
                "Date" "$res_date_label" \
                "Time" "$(reservation_window_display)"
            fi
            # Live booking: Java already printed the green success box
            exit 0
        fi

        # Exit 2 = daily/quota limit (or other non-retryable). Java already printed warn box.
        if [ "$book_status" -eq 2 ]; then
            exit 2
        fi

        log_warn "Failed: $RESOURCE"
        if [ "$CURRENT" -lt "$TOTAL" ]; then
            log_info "Trying next slot..."
            # Dry-run already slept inside book_resource
            if [ "$DRY_RUN" != "1" ]; then
              sleep "$BOOK_RETRY_SLEEP_SEC"
            fi
        fi
    done

    NOW_EPOCH="$(date +%s)"
    ELAPSED=$((NOW_EPOCH - START_EPOCH))
    if [ "$ELAPSED" -ge "$BOOK_RETRY_TIMEOUT_SEC" ]; then
        log_error "No slot booked — retry timeout (${BOOK_RETRY_TIMEOUT_SEC}s) exceeded after ${ROUND} round(s)"
        exit 1
    fi

    log_warn "Round $ROUND: all slots failed — retrying in ${BOOK_RETRY_SLEEP_SEC}s..."
    sleep "$BOOK_RETRY_SLEEP_SEC"
done
