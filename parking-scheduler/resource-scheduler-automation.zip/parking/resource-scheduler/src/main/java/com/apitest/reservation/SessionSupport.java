package com.apitest.reservation;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Loads SSO session credentials from JVM properties or session.json.
 */
public final class SessionSupport {

    private static final String SESSION_FILE = System.getProperty("sessionFile", "");

    public static final class Session {
        private final String secToken;
        private final String cookies;
        private final String displayName;

        public Session(String secToken, String cookies) {
            this(secToken, cookies, null);
        }

        public Session(String secToken, String cookies, String displayName) {
            this.secToken = secToken;
            this.cookies = cookies;
            this.displayName = displayName;
        }

        public String getSecToken() {
            return secToken;
        }

        public String getCookies() {
            return cookies;
        }

        public String getDisplayName() {
            return displayName;
        }
    }

    private SessionSupport() {
    }

    public static boolean hasSessionFile() {
        return !isBlank(SESSION_FILE) && Files.isRegularFile(Path.of(SESSION_FILE));
    }

    public static Session load() {
        String secToken = System.getProperty("secToken");
        String cookies = System.getProperty("cookies");
        String displayName = System.getProperty("displayName");

        if (isBlank(secToken) || isBlank(cookies) || isBlank(displayName)) {
            Session fromFile = loadFromFile();
            secToken = firstNonBlank(secToken, fromFile.secToken);
            cookies = firstNonBlank(cookies, fromFile.cookies);
            displayName = firstNonBlank(displayName, fromFile.displayName);
        }

        validate(secToken, cookies);
        return new Session(secToken, cookies, displayName);
    }

    /**
     * Re-read session.json (e.g. after SSO login refreshed the file post-schedule wait).
     */
    public static Session reloadFromFile() {
        if (!hasSessionFile()) {
            return load();
        }
        Session fromFile = loadFromFile();
        validate(fromFile.secToken, fromFile.cookies);
        return fromFile;
    }

    private static Session loadFromFile() {
        if (isBlank(SESSION_FILE)) {
            return new Session(null, null, null);
        }

        Path path = Path.of(SESSION_FILE);
        if (!Files.isRegularFile(path)) {
            throw new IllegalStateException("Session file not found: " + SESSION_FILE);
        }

        try {
            String json = Files.readString(path, StandardCharsets.UTF_8);
            return new Session(
                extractJsonString(json, "secToken"),
                extractJsonString(json, "cookieHeader"),
                extractJsonString(json, "displayName")
            );
        } catch (IOException e) {
            throw new IllegalStateException("Failed to read session file: " + SESSION_FILE, e);
        }
    }

    private static void validate(String secToken, String cookies) {
        if (isBlank(secToken) || isBlank(cookies)) {
            throw new IllegalStateException(
                "Missing session credentials. Run parking/resource-scheduler-sso-login/run-manual-login.sh "
                    + "or pass -DsecToken and -Dcookies (and optionally -DsessionFile)."
            );
        }
    }

    private static String extractJsonString(String json, String key) {
        Pattern pattern = Pattern.compile(
            "\"" + Pattern.quote(key) + "\"\\s*:\\s*\"((?:\\\\.|[^\"\\\\])*)\"",
            Pattern.DOTALL
        );
        Matcher matcher = pattern.matcher(json);
        if (!matcher.find()) {
            return null;
        }
        return unescapeJson(matcher.group(1));
    }

    private static String unescapeJson(String value) {
        return value
            .replace("\\\"", "\"")
            .replace("\\\\", "\\")
            .replace("\\n", "\n")
            .replace("\\r", "\r")
            .replace("\\t", "\t");
    }

    private static boolean isBlank(String value) {
        return value == null || value.trim().isEmpty();
    }

    private static String firstNonBlank(String first, String second) {
        return !isBlank(first) ? first : second;
    }
}
