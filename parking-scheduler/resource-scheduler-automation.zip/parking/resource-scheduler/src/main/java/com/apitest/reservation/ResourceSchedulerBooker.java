package com.apitest.reservation;

import okhttp3.*;

import java.io.IOException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.TimeUnit;
import javax.net.ssl.*;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

/**
 * Books one Resource Scheduler parking slot via submit.asp.
 * Invoked by run-multiple.sh (not a JUnit test).
 *
 * Required: -DresourceId=R123
 * Session: -DsecToken / -Dcookies / -DsessionFile (and optional -DdisplayName)
 */
public class ResourceSchedulerBooker {

    private static final String BASE_URL = "https://asurion.resourcescheduler.net/ResourceScheduler/submit.asp";

    private static final ZoneId RESERVATION_ZONE =
        ZoneId.of(System.getProperty("reservationZone", "Asia/Manila"));

    private OkHttpClient client;
    private SessionSupport.Session session;

    // Resource ID — required via -DresourceId (set by run-multiple.sh)
    private static String RESOURCE_ID;

    private static void requireResourceId() {
        RESOURCE_ID = System.getProperty("resourceId", "").trim();
        if (RESOURCE_ID.isEmpty()) {
            throw new IllegalStateException(
                "resourceId system property is required (e.g. -DresourceId=R123 via run-multiple.sh)");
        }
    }

    // Scheduled trigger time (Asia/Manila, format: "yyyy-MM-dd HH:mm:ss").
    // Set via -DscheduledExecutionTime; blank = execute immediately.
    private static final String SCHEDULED_EXECUTION_TIME =
        System.getProperty("scheduledExecutionTime", "").trim();

    private static final int RESERVATION_DAYS_AHEAD =
        Integer.parseInt(System.getProperty("reservationDaysAhead", "7"));

    // Optional fixed date for testing, e.g. -DreservationDate=2026-7-4 (Saturday)
    private static final String RESERVATION_DATE_OVERRIDE =
        System.getProperty("reservationDate", "").trim();

    // Time slot on the reservation date (defaults; override via -DstartHr / -DendHr / -D*Min)
    private static final String START_HR = System.getProperty("startHr", "6+AM");
    private static final String START_MIN = System.getProperty("startMin", "00");
    private static final String END_HR = System.getProperty("endHr", "3+PM");
    private static final String END_MIN = System.getProperty("endMin", "00");

    // Optional override; otherwise taken from SSO session.json displayName / schedule page
    private static final String BOOKING_DESC_OVERRIDE =
        System.getProperty("bookingDesc", "").trim();

    private String bookingDisplayName;
    /** Raw ResDesc for submit.asp (may include capacity). */
    private String resourceDescription;
    /** Short bay label for UI, e.g. P3-C18. */
    private String spaceLabel;

    private static final Pattern[] RES_DESC_PATTERNS = {
        Pattern.compile("name=[\"']ResDesc[\"'][^>]*value=[\"']([^\"']*)[\"']", Pattern.CASE_INSENSITIVE),
        Pattern.compile("value=[\"']([^\"']*)[\"'][^>]*name=[\"']ResDesc[\"']", Pattern.CASE_INSENSITIVE),
    };

    private static final Pattern[] DISPLAY_NAME_PATTERNS = {
        Pattern.compile("name=[\"']txtDesc[\"'][^>]*value=[\"']([^\"']+)[\"']", Pattern.CASE_INSENSITIVE),
        Pattern.compile("value=[\"']([^\"']+)[\"'][^>]*name=[\"']txtDesc[\"']", Pattern.CASE_INSENSITIVE),
        Pattern.compile(
            "id=[\"'](?:lblUserName|lblUser|UserName|txtUserName|spnUser)[\"'][^>]*>\\s*([^<]+)",
            Pattern.CASE_INSENSITIVE
        ),
        Pattern.compile("(?:Logged\\s*in\\s*as|Welcome)\\s*[:\\-]?\\s*([^<\\n\\r|]{3,80})", Pattern.CASE_INSENSITIVE),
        Pattern.compile("(?:var\\s+)?g_sUser(?:Name|FullName)?\\s*=\\s*[\"']([^\"']+)[\"']", Pattern.CASE_INSENSITIVE),
        Pattern.compile("(?:var\\s+)?sUser(?:Name|FullName)?\\s*=\\s*[\"']([^\"']+)[\"']", Pattern.CASE_INSENSITIVE),
    };

    private static String reservationDate() {
        if (!RESERVATION_DATE_OVERRIDE.isEmpty()) {
            return RESERVATION_DATE_OVERRIDE;
        }
        return LocalDate.now(RESERVATION_ZONE)
            .plusDays(RESERVATION_DAYS_AHEAD)
            .format(DateTimeFormatter.ofPattern("yyyy-M-d"));
    }

    private static String resourceTopicId() {
        return RESOURCE_ID.startsWith("R") ? RESOURCE_ID.substring(1) : RESOURCE_ID;
    }

    private static String schedulePageUrl() {
        return "https://asurion.resourcescheduler.net/ResourceScheduler/schedule.asp?Topic=RES&TopicId="
            + resourceTopicId() + "&CDate=" + reservationDate();
    }

    private void setup() {
        session = SessionSupport.load();
        try {
            // Create a trust manager that does not validate certificate chains
            final TrustManager[] trustAllCerts = new TrustManager[] {
                new X509TrustManager() {
                    @Override
                    public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
                    }

                    @Override
                    public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {
                    }

                    @Override
                    public X509Certificate[] getAcceptedIssuers() {
                        return new X509Certificate[]{};
                    }
                }
            };

            // Install the all-trusting trust manager
            final SSLContext sslContext = SSLContext.getInstance("SSL");
            sslContext.init(null, trustAllCerts, new java.security.SecureRandom());

            // Create an ssl socket factory with our all-trusting manager
            final SSLSocketFactory sslSocketFactory = sslContext.getSocketFactory();

            // Create OkHttpClient with SSL configuration and timeouts
            client = new OkHttpClient.Builder()
                .sslSocketFactory(sslSocketFactory, (X509TrustManager)trustAllCerts[0])
                .hostnameVerifier(new HostnameVerifier() {
                    @Override
                    public boolean verify(String hostname, SSLSession session) {
                        return true;
                    }
                })
                .connectTimeout(30, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS)
                .writeTimeout(30, TimeUnit.SECONDS)
                .build();
        } catch (Exception e) {
            throw new RuntimeException("Failed to create OkHttpClient with SSL configuration", e);
        }
    }

    /** Exit code: try next slot. */
    private static final int EXIT_TRY_NEXT = 1;
    /** Exit code: stop retry loop (e.g. daily booking limit). */
    private static final int EXIT_STOP_RETRY = 2;

    public static void main(String[] args) {
        try {
            requireResourceId();
            ResourceSchedulerBooker booker = new ResourceSchedulerBooker();
            booker.setup();
            booker.book();
        } catch (BookingLimitException e) {
            // Warn box already printed — tell shell to stop trying more slots
            System.exit(EXIT_STOP_RETRY);
        } catch (BookingFailedException e) {
            // Already logged via Log.error — shell tries next slot
            System.exit(EXIT_TRY_NEXT);
        } catch (Exception e) {
            Log.error("Booking failed: " + e.getMessage());
            e.printStackTrace(System.err);
            System.exit(EXIT_TRY_NEXT);
        }
    }

    /**
     * Submit one reservation for RESOURCE_ID.
     * Session: run SSO login first, or pass -DsecToken/-Dcookies.
     */
    public void book() throws IOException, InterruptedException {
        // Wait until the scheduled trigger time, then hit the endpoint once
        waitUntilScheduledTime();

        // Re-read session.json after a long wait (refresh via run-manual-login.sh before trigger)
        if (!SCHEDULED_EXECUTION_TIME.trim().isEmpty() && SessionSupport.hasSessionFile()) {
            session = SessionSupport.reloadFromFile();
        }

        submitReservationOnce();
    }

    private static String formatReservationTime(String hr, String min) {
        String display = hr.replace('+', ' ');
        if (min == null || min.isBlank() || "00".equals(min)) {
            return display;
        }
        int space = display.lastIndexOf(' ');
        if (space < 0) {
            return display;
        }
        return display.substring(0, space) + ":" + min + display.substring(space);
    }

    private void printBookingSuccess() {
        String window = formatReservationTime(START_HR, START_MIN)
            + " – "
            + formatReservationTime(END_HR, END_MIN);
        String name = bookingDisplayName != null ? bookingDisplayName : "";
        Log.successBox(
            "Booking confirmed",
            "Space", displaySpaceLabel(),
            "Date", formatReservationDateWithDow(),
            "Time", window,
            "Name", name
        );
    }

    /** e.g. {@code Saturday · 2026-7-18} */
    private static String formatReservationDateWithDow() {
        String raw = reservationDate();
        try {
            LocalDate date = parseReservationDate(raw);
            String dow = date.getDayOfWeek()
                .getDisplayName(java.time.format.TextStyle.FULL, java.util.Locale.ENGLISH);
            return dow + " · " + raw;
        } catch (Exception e) {
            return raw;
        }
    }

    private static LocalDate parseReservationDate(String raw) {
        String[] parts = raw.trim().split("-");
        if (parts.length != 3) {
            return LocalDate.parse(raw.trim());
        }
        return LocalDate.of(
            Integer.parseInt(parts[0]),
            Integer.parseInt(parts[1]),
            Integer.parseInt(parts[2])
        );
    }

    /** Human label like P3-C18; falls back to resource id only if unknown. */
    private String displaySpaceLabel() {
        String fromProp = System.getProperty("resourceLabel", "").trim();
        if (!fromProp.isEmpty()) {
            String normalized = normalizeSpaceLabel(fromProp);
            if (normalized != null) {
                return normalized;
            }
        }
        if (spaceLabel != null && !spaceLabel.isBlank()) {
            return spaceLabel;
        }
        if (resourceDescription != null && !resourceDescription.isBlank()) {
            String normalized = normalizeSpaceLabel(resourceDescription);
            if (normalized != null) {
                return normalized;
            }
        }
        return RESOURCE_ID;
    }

    /** Prefer short bay codes (P2-C18); strip capacity suffixes. */
    private static String normalizeSpaceLabel(String raw) {
        if (raw == null || raw.isBlank()) {
            return null;
        }
        String s = raw.replace('\u00a0', ' ').replace("&nbsp;", " ").trim();
        // Title path: "… => P2 Parking => P2-C18"
        int arrow = s.lastIndexOf("=>");
        if (arrow >= 0) {
            s = s.substring(arrow + 2).trim();
        }
        // "P2-C18 (1)" / "P2-C18 (Capacity 1)"
        s = s.replaceAll("\\s*\\(.*\\)\\s*$", "").trim();
        Matcher bay = Pattern.compile("\\b(P\\d+-C\\d+)\\b", Pattern.CASE_INSENSITIVE).matcher(s);
        if (bay.find()) {
            return bay.group(1).toUpperCase();
        }
        return s.isEmpty() ? null : s;
    }

    /**
     * Load schedule page with session cookies and extract a fresh sec_token for the target date.
     */
    private String refreshSecToken() throws IOException {
        if (SessionSupport.hasSessionFile()) {
            session = SessionSupport.reloadFromFile();
        }

        String scheduleUrl = schedulePageUrl();

        Request getRequest = new Request.Builder()
            .url(scheduleUrl)
            .get()
            .addHeader("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
            .addHeader("Cookie", session.getCookies())
            .addHeader("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36")
            .build();

        try (Response response = client.newCall(getRequest).execute()) {
            String html = response.body() != null ? response.body().string() : "";
            String location = response.header("Location");

            if (response.code() == 302 || response.code() == 301) {
                throw new IOException("Session expired (redirect to " + location + ")");
            }
            if (html.toLowerCase().contains("ndcsso.asurion.com")
                || html.toLowerCase().contains("identifiername")
                || html.toLowerCase().contains("signonbutton")) {
                throw new IOException("Session expired — SSO login page returned");
            }

            String token = extractSecTokenFromHtml(html);
            resourceDescription = extractResDescFromHtml(html);
            if (resourceDescription == null) {
                resourceDescription = extractOptionRawText(html, RESOURCE_ID);
            }
            spaceLabel = extractSpaceLabelFromHtml(html, RESOURCE_ID);
            // Prefer name from the authenticated schedule page when session.json lacks it
            bookingDisplayName = resolveBookingDisplayName(html);
            return token;
        }
    }

    /**
     * Display name for submit.asp txtDesc — -DbookingDesc override, then SSO session, then schedule HTML.
     * Stored/scraped names are often "Last, First"; booking uses "First Last".
     */
    private String resolveBookingDisplayName(String scheduleHtml) {
        if (!BOOKING_DESC_OVERRIDE.isEmpty()) {
            String override = toBookingDisplayName(BOOKING_DESC_OVERRIDE);
            if (override != null) {
                return override;
            }
            return BOOKING_DESC_OVERRIDE.trim();
        }
        if (session != null && session.getDisplayName() != null && !session.getDisplayName().trim().isEmpty()) {
            String fromSession = toBookingDisplayName(session.getDisplayName());
            if (fromSession != null) {
                return fromSession;
            }
        }
        String fromHtml = extractDisplayNameFromHtml(scheduleHtml);
        if (fromHtml != null) {
            return fromHtml;
        }
        throw new IllegalStateException(
            "Missing booking display name. Re-run SSO login so session.json includes displayName, "
                + "or pass -DbookingDesc=\"First Last\"."
        );
    }

    /** Clean scraped name and convert "Last, First" → "First Last" for txtDesc. */
    private static String toBookingDisplayName(String value) {
        String cleaned = normalizeDisplayName(value);
        if (cleaned == null) {
            return null;
        }
        int comma = cleaned.indexOf(',');
        if (comma > 0 && comma < cleaned.length() - 1) {
            String last = cleaned.substring(0, comma).trim();
            String first = cleaned.substring(comma + 1).trim();
            if (!last.isEmpty() && !first.isEmpty()) {
                return first + " " + last;
            }
        }
        return cleaned;
    }

    private static String normalizeDisplayName(String value) {
        if (value == null || value.isBlank()) {
            return null;
        }
        String cleaned = value
            .replace('\u00a0', ' ')
            .replaceAll("\\s+", " ")
            .trim();
        String[] parts = cleaned.split(" ");
        java.util.ArrayList<String> kept = new java.util.ArrayList<>();
        for (String part : parts) {
            kept.add(part);
        }
        while (kept.size() > 1
            && kept.get(kept.size() - 1).matches("(?i)^(welcome|log\\s*out|sign\\s*out|logout|home|help|settings|schedule|resource|menu|search)$")) {
            kept.remove(kept.size() - 1);
        }
        cleaned = String.join(" ", kept);
        if (cleaned.length() < 3 || cleaned.length() > 120) {
            return null;
        }
        if (cleaned.matches("(?i)^(welcome|log\\s*out|sign\\s*out|logout|home|help|settings|schedule|resource|menu|search)$")) {
            return null;
        }
        return cleaned;
    }

    private static String extractDisplayNameFromHtml(String html) {
        if (html == null || html.isBlank()) {
            return null;
        }
        for (Pattern pattern : DISPLAY_NAME_PATTERNS) {
            Matcher matcher = pattern.matcher(html);
            if (matcher.find()) {
                String raw = URLDecoder.decode(matcher.group(1).replace('+', ' '), StandardCharsets.UTF_8);
                String normalized = toBookingDisplayName(raw);
                if (normalized != null) {
                    return normalized;
                }
            }
        }
        return null;
    }

    private static String extractResDescFromHtml(String html) {
        if (html == null || html.isBlank()) {
            return null;
        }
        for (Pattern pattern : RES_DESC_PATTERNS) {
            Matcher matcher = pattern.matcher(html);
            if (matcher.find()) {
                String raw = URLDecoder.decode(matcher.group(1).replace('+', ' '), StandardCharsets.UTF_8)
                    .replace('\u00a0', ' ')
                    .trim();
                if (!raw.isEmpty()) {
                    return raw;
                }
            }
        }
        return null;
    }

    /** Option text for this resource, e.g. {@code P2-C18 (1)}. */
    private static String extractOptionRawText(String html, String resourceId) {
        if (html == null || html.isBlank() || resourceId == null || resourceId.isBlank()) {
            return null;
        }
        Pattern opt = Pattern.compile(
            "<option[^>]*value=[\"']" + Pattern.quote(resourceId.trim()) + "[\"'][^>]*>\\s*([^<]+)",
            Pattern.CASE_INSENSITIVE
        );
        Matcher m = opt.matcher(html);
        if (!m.find()) {
            return null;
        }
        String raw = m.group(1).replace('\u00a0', ' ').replace("&nbsp;", " ").trim();
        return raw.isEmpty() ? null : raw;
    }

    /**
     * Resolve bay label (P2-C18) from schedule/response HTML.
     * Prefers option text for this resource, then page title, then ResDesc.
     */
    private static String extractSpaceLabelFromHtml(String html, String resourceId) {
        if (html == null || html.isBlank()) {
            return null;
        }
        String id = resourceId == null ? "" : resourceId.trim();
        if (!id.isEmpty()) {
            String fromOption = normalizeSpaceLabel(extractOptionRawText(html, id));
            if (fromOption != null) {
                return fromOption;
            }
            // Popup link text: PopUp405 … P2-C18
            String num = id.startsWith("R") || id.startsWith("r") ? id.substring(1) : id;
            Pattern popup = Pattern.compile(
                "PopUp" + Pattern.quote(num) + "[^>]*>\\s*<nobr>([^<]+)",
                Pattern.CASE_INSENSITIVE
            );
            Matcher m = popup.matcher(html);
            if (m.find()) {
                String label = normalizeSpaceLabel(m.group(1));
                if (label != null) {
                    return label;
                }
            }
        }
        String title = extractPageTitle(html);
        if (title != null) {
            String label = normalizeSpaceLabel(title);
            if (label != null && label.matches("(?i)P\\d+-C\\d+")) {
                return label;
            }
        }
        return normalizeSpaceLabel(extractResDescFromHtml(html));
    }

    private static String extractSecTokenFromHtml(String html) throws IOException {
        Pattern[] patterns = {
            Pattern.compile("name=[\"']sec_token[\"'][^>]*value=[\"']([^\"']+)[\"']", Pattern.CASE_INSENSITIVE),
            Pattern.compile("value=[\"']([^\"']+)[\"'][^>]*name=[\"']sec_token[\"']", Pattern.CASE_INSENSITIVE),
        };
        for (Pattern pattern : patterns) {
            Matcher matcher = pattern.matcher(html);
            if (matcher.find()) {
                return URLDecoder.decode(matcher.group(1), StandardCharsets.UTF_8);
            }
        }
        throw new IOException("Could not find sec_token on schedule page");
    }

    private void validateReservationResponse(Response response, String responseBody) throws IOException {
        String location = response.header("Location");
        String lower = responseBody.toLowerCase();

        Path responseLog = Path.of("logs", "responses", RESOURCE_ID + "-last.html");
        Files.createDirectories(responseLog.getParent());
        Files.writeString(responseLog, responseBody, StandardCharsets.UTF_8);

        // Prefer label from the confirmation page (title / options)
        String confirmedLabel = extractSpaceLabelFromHtml(responseBody, RESOURCE_ID);
        if (confirmedLabel != null) {
            spaceLabel = confirmedLabel;
        }

        if (response.code() == 302 || response.code() == 301) {
            if (location != null && location.toLowerCase().contains("schedule.asp")) {
                printBookingSuccess();
                return;
            }
            failBooking("Unexpected redirect: " + location);
        }

        String pageTitle = extractPageTitle(responseBody);
        String detail = extractProcessRequestDetail(responseBody);
        if (isBookingLimitResponse(responseBody, detail)) {
            failBookingLimit(detail);
        }
        if (pageTitle != null) {
            String titleLower = pageTitle.toLowerCase();
            if (titleLower.contains("error")
                || titleLower.contains("login")
                || titleLower.contains("sign on")
                || titleLower.contains("page expired")
                || titleLower.contains("process request")) {
                failBooking(
                    "Booking failed — page title: " + pageTitle
                        + (detail != null ? " — " + detail : "")
                );
            }
        }

        String[] failurePhrases = {
            "session has expired",
            "invalid sec_token",
            "please log in",
            "reservation failed",
            "not available",
            "unable to process",
            "conflict",
            "not authorized",
            "page expired",
        };
        for (String phrase : failurePhrases) {
            if (lower.contains(phrase)) {
                failBooking("Booking failed — response contains: \"" + phrase + "\"");
            }
        }

        if (lower.contains("password") && lower.contains("identifiername")) {
            failBooking("Booking failed — SSO login form returned (session expired)");
        }

        // Success: RS returns HTTP 200 with the full schedule grid (not a 302 redirect).
        if (response.isSuccessful()
                && pageTitle != null
                && pageTitle.toLowerCase().startsWith("schedule for")
                && lower.contains("scheduleweekview")
                && responseBody.length() > 5000) {
            printBookingSuccess();
            return;
        }

        failBooking(
            "Cannot confirm booking — HTTP " + response.code()
                + " (" + responseBody.length() + " bytes)"
                + (detail != null ? " — " + detail : "")
                + ". Check logs/responses/" + RESOURCE_ID + "-last.html"
        );
    }

    /** Log a decorated error, then abort booking (main exits non-zero). */
    private static void failBooking(String message) {
        Log.error(message);
        throw new BookingFailedException(message);
    }

    /** Daily / quota limit — print warn box and stop the slot retry loop. */
    private void failBookingLimit(String detail) {
        String msg = detail != null && !detail.isBlank()
            ? detail
            : "No more resources can be scheduled at this time";
        Log.warnBox(
            "Booking limit reached",
            "Date", formatReservationDateWithDow(),
            "Detail", msg
        );
        throw new BookingLimitException(msg);
    }

    /**
     * RS returns this when the user already has the max reservations
     * for that day/type (further slots will also fail).
     */
    private static boolean isBookingLimitResponse(String html, String detail) {
        String hay = ((html == null ? "" : html) + " " + (detail == null ? "" : detail)).toLowerCase();
        return hay.contains("no more resources of type")
            || hay.contains("can be scheduled at this time")
            || hay.contains("no more resources can be scheduled");
    }

    /** Checked-style abort used instead of JUnit AssertionError. */
    public static final class BookingFailedException extends RuntimeException {
        public BookingFailedException(String message) {
            super(message);
        }
    }

    /** Abort that tells the shell to stop trying other slots. */
    public static final class BookingLimitException extends RuntimeException {
        public BookingLimitException(String message) {
            super(message);
        }
    }

    /** Pull a short human-readable message from RS "Process Request" / error HTML. */
    private static String extractProcessRequestDetail(String html) {
        if (html == null || html.isBlank()) {
            return null;
        }
        // Prefer the red rejection reason RS shows on Process Request pages
        Matcher red = Pattern.compile(
            "forecolor-red[^>]*>([^<]+)",
            Pattern.CASE_INSENSITIVE
        ).matcher(html);
        if (red.find()) {
            String detail = truncateDetail(red.group(1).replaceAll("\\s+", " ").trim());
            if (detail != null) {
                return detail;
            }
        }
        Matcher tagged = Pattern.compile(
            "<(?:font|span|div|p|td)[^>]*>\\s*([^<]{10,200})\\s*</(?:font|span|div|p|td)>",
            Pattern.CASE_INSENSITIVE
        ).matcher(html);
        while (tagged.find()) {
            String text = tagged.group(1).replaceAll("\\s+", " ").trim();
            if (looksLikeBookingError(text)) {
                String detail = truncateDetail(text);
                if (detail != null) {
                    return detail;
                }
            }
        }
        Matcher loose = Pattern.compile(
            "(?:error|failed|unable|invalid|not available|unavailable|already|no more resources)[^.<]{0,120}",
            Pattern.CASE_INSENSITIVE
        ).matcher(html);
        if (loose.find()) {
            String candidate = truncateDetail(loose.group().replaceAll("\\s+", " ").trim());
            if (candidate != null) {
                return candidate;
            }
        }
        return null;
    }

    private static boolean looksLikeBookingError(String text) {
        if (looksLikeScriptGarbage(text)) {
            return false;
        }
        String lower = text.toLowerCase();
        return lower.contains("error")
            || lower.contains("fail")
            || lower.contains("unable")
            || lower.contains("invalid")
            || lower.contains("not available")
            || lower.contains("unavailable")
            || lower.contains("no more resources")
            || lower.contains("already")
            || lower.contains("conflict")
            || lower.contains("expired")
            || lower.contains("required")
            || lower.contains("rejected");
    }

    /** Reject JS/HTML noise scraped from RS error pages (e.g. bot-detection scripts). */
    private static boolean looksLikeScriptGarbage(String text) {
        String lower = text.toLowerCase();
        return lower.contains("_detector")
            || lower.contains("undefined")
            || lower.contains("function")
            || lower.contains("attempts")
            || text.contains("');")
            || text.contains("=>{")
            || text.contains("var ")
            || text.contains("const ")
            || text.contains("=>");
    }

    private static String truncateDetail(String text) {
        if (looksLikeScriptGarbage(text)) {
            return null;
        }
        return text.length() > 160 ? text.substring(0, 160) + "..." : text;
    }

    private static String extractPageTitle(String html) {
        Matcher matcher = Pattern.compile("<title>([^<]*)</title>", Pattern.CASE_INSENSITIVE).matcher(html);
        return matcher.find() ? matcher.group(1).trim() : null;
    }

    /**
     * Block until {@code SCHEDULED_EXECUTION_TIME} (Asia/Manila). If it is blank or
     * already in the past, return immediately.
     */
    private void waitUntilScheduledTime() throws InterruptedException {
        if (SCHEDULED_EXECUTION_TIME.trim().isEmpty()) {
            return;
        }

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        ZonedDateTime target;
        try {
            target = LocalDateTime.parse(SCHEDULED_EXECUTION_TIME.trim(), formatter)
                .atZone(RESERVATION_ZONE);
        } catch (Exception e) {
            Log.warn("Could not parse SCHEDULED_EXECUTION_TIME '" + SCHEDULED_EXECUTION_TIME
                + "': " + e.getMessage() + " - executing immediately");
            return;
        }

        Log.step("Waiting until " + target.format(formatter) + " PHT");

        while (true) {
            ZonedDateTime now = ZonedDateTime.now(RESERVATION_ZONE);
            if (!now.isBefore(target)) {
                break;
            }
            long secondsRemaining = Duration.between(now, target).getSeconds();
            long sleepSeconds = Math.min(60, Math.max(1, secondsRemaining));
            Thread.sleep(sleepSeconds * 1000);
        }
    }

    private void submitReservationOnce() throws IOException {
        String secToken = refreshSecToken();
        String formData = buildFormData(secToken);
        RequestBody body = RequestBody.create(
            formData,
            MediaType.parse("application/x-www-form-urlencoded")
        );
        Request request = buildRequest(body, session.getCookies());

        try (Response response = client.newCall(request).execute()) {
            String responseBody = response.body() != null ? response.body().string() : "";
            validateReservationResponse(response, responseBody);
        }
    }

    /**
     * Helper method to build form data with security token
     */
    private String buildFormData(String secToken) {
        String qrDate = reservationDate();
        String encodedPageUrl = URLEncoder.encode(schedulePageUrl(), StandardCharsets.UTF_8);
        String desc = bookingDisplayName != null ? bookingDisplayName : resolveBookingDisplayName(null);
        String encodedDesc = URLEncoder.encode(desc, StandardCharsets.UTF_8).replace("%20", "+");
        // Prefer live ResDesc from schedule page; fall back to historical default encoding.
        String encodedResDesc = resourceDescription != null && !resourceDescription.isBlank()
            ? URLEncoder.encode(resourceDescription, StandardCharsets.UTF_8).replace("%20", "+")
            : "P5-C12%2520%25281%2529";
        return "sec_token=" + secToken +
               "&PageURL=" + encodedPageUrl +
               "&RedirectToPageURLFlag=1" +
               "&txtDesc=" + encodedDesc +
               "&NumberOfAttendees=" +
               "&Resource=" + RESOURCE_ID +
               "&qrt_start_hr=0" +
               "&qrt_start_min=0" +
               "&qrt_end_hr=0" +
               "&qrt_end_min=0" +
               "&qrt_duration_hr=0" +
               "&qrt_duration_min=0" +
               "&loc_id=26" +
               "&grp_id=125" +
               "&tz=" +
               "&QRDate=" + qrDate +
               "&StartHr=" + START_HR +
               "&StartMin=" + START_MIN +
               "&QREndDate=" + qrDate +
               "&EndHr=" + END_HR +
               "&EndMin=" + END_MIN +
               "&requestedForName=" +
               "&requestedForIsPAB=" +
               "&requestedForID=" +
               "&requestedForEmail=" +
               "&requestedForPhone=" +
               "&requestedForDept=" +
               "&requestedForAcctCode=" +
               "&NumUDF=0" +
               "&ResDesc=" + encodedResDesc +
               "&Topic=QR" +
               "&IsPlanner=0" +
               "&SchedQS=ID%3D" + RESOURCE_ID + "%26comboDtlId%3D" + RESOURCE_ID + "%26quickResId%3Dquickrespop%26_%3D1782859872985%26" +
               "&LocHdr=PDOC+Philippines+Parking" +
               "&hdnVTC=" +
               "&hdnVTCResource=0" +
               "&hdnVTCConfId=" +
               "&submitMore=0";
    }

    /**
     * Helper method to build request with headers and cookies
     */
    private Request buildRequest(RequestBody body, String cookies) {
        return new Request.Builder()
            .url(BASE_URL)
            .method("POST", body)
            .addHeader("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7")
            .addHeader("Accept-Language", "en-US,en;q=0.9")
            .addHeader("Cache-Control", "max-age=0")
            .addHeader("Connection", "keep-alive")
            .addHeader("Content-Type", "application/x-www-form-urlencoded")
            .addHeader("Cookie", cookies)
            .addHeader("Origin", "https://asurion.resourcescheduler.net")
            .addHeader("Referer", schedulePageUrl())
            .addHeader("Sec-Fetch-Dest", "document")
            .addHeader("Sec-Fetch-Mode", "navigate")
            .addHeader("Sec-Fetch-Site", "same-origin")
            .addHeader("Sec-Fetch-User", "?1")
            .addHeader("Upgrade-Insecure-Requests", "1")
            .addHeader("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36")
            .addHeader("sec-ch-ua", "\"Not;A=Brand\";v=\"8\", \"Chromium\";v=\"150\", \"Google Chrome\";v=\"150\"")
            .addHeader("sec-ch-ua-mobile", "?0")
            .addHeader("sec-ch-ua-platform", "\"Windows\"")
            .build();
    }

}
