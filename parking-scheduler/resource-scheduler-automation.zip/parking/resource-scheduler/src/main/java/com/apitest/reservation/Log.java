package com.apitest.reservation;

/**
 * Colored, classified console logging for booking tests.
 * Disable with -Dparking.log.color=false or NO_COLOR / PARKING_LOG_COLOR=0.
 */
final class Log {
    private static final boolean USE_COLOR = detectColor();

    private static final String RESET = USE_COLOR ? "\u001B[0m" : "";
    private static final String BOLD = USE_COLOR ? "\u001B[1m" : "";
    private static final String DIM = USE_COLOR ? "\u001B[2m" : "";
    private static final String RED = USE_COLOR ? "\u001B[31m" : "";
    private static final String GREEN = USE_COLOR ? "\u001B[32m" : "";
    private static final String YELLOW = USE_COLOR ? "\u001B[33m" : "";
    private static final String BLUE = USE_COLOR ? "\u001B[34m" : "";
    private static final String MAGENTA = USE_COLOR ? "\u001B[35m" : "";
    private static final String CYAN = USE_COLOR ? "\u001B[36m" : "";

    private Log() {}

    private static boolean detectColor() {
        String prop = System.getProperty("parking.log.color", "").trim();
        if ("false".equalsIgnoreCase(prop) || "0".equals(prop)) {
            return false;
        }
        if ("true".equalsIgnoreCase(prop) || "1".equals(prop)) {
            return true;
        }
        if (System.getenv("NO_COLOR") != null && !System.getenv("NO_COLOR").isEmpty()) {
            return false;
        }
        String env = System.getenv("PARKING_LOG_COLOR");
        if ("0".equals(env)) {
            return false;
        }
        if ("1".equals(env) || "1".equals(System.getenv("FORCE_COLOR"))) {
            return true;
        }
        return System.console() != null;
    }

    private static void line(String color, String icon, String label, String msg) {
        line(color, icon, label, msg, false, false);
    }

    private static void lineErr(String color, String icon, String label, String msg) {
        line(color, icon, label, msg, true, true);
    }

    private static void line(
        String color, String icon, String label, String msg, boolean toErr, boolean colorMsg
    ) {
        String out;
        if (colorMsg) {
            out = color + BOLD + icon + " " + pad(label, 7) + " " + msg + RESET;
        } else {
            out = color + BOLD + icon + " " + pad(label, 7) + RESET + " " + msg;
        }
        if (toErr) {
            System.err.println(out);
        } else {
            System.out.println(out);
        }
    }

    private static String pad(String s, int width) {
        if (s.length() >= width) {
            return s;
        }
        return s + " ".repeat(width - s.length());
    }

    static void info(String msg) {
        line(CYAN, "ℹ", "INFO", msg);
    }

    static void ok(String msg) {
        line(GREEN, "✔", "OK", msg, false, true);
    }

    static void success(String msg) {
        line(GREEN, "✔", "SUCCESS", msg, false, true);
    }

    static void warn(String msg) {
        lineErr(YELLOW, "⚠", "WARN", msg);
    }

    static void error(String msg) {
        lineErr(RED, "✖", "ERROR", msg);
    }

    static void step(String msg) {
        line(BLUE, "▸", "STEP", msg);
    }

    static void header(String title) {
        String bar = "─".repeat(56);
        String t = title.length() > 54 ? title.substring(0, 54) : title;
        System.out.println();
        System.out.println(BOLD + MAGENTA + "┌" + bar + "┐" + RESET);
        System.out.println(BOLD + MAGENTA + "│ " + pad(t, 54) + " │" + RESET);
        System.out.println(BOLD + MAGENTA + "└" + bar + "┘" + RESET);
        System.out.println();
    }

    /**
     * Green success box. {@code kvs} are alternating key, value pairs.
     */
    static void successBox(String title, String... kvs) {
        coloredBox(GREEN, "✔", title, kvs);
    }

    /** Yellow warning box. {@code kvs} are alternating key, value pairs. */
    static void warnBox(String title, String... kvs) {
        coloredBox(YELLOW, "⚠", title, kvs);
    }

    private static void coloredBox(String color, String icon, String title, String... kvs) {
        String bar = "─".repeat(56);
        String t = title.length() > 52 ? title.substring(0, 52) : title;
        System.out.println();
        System.out.println(BOLD + color + "┌" + bar + "┐" + RESET);
        System.out.println(BOLD + color + "│ " + icon + " " + pad(t, 52) + " │" + RESET);
        if (kvs != null && kvs.length > 0) {
            System.out.println(BOLD + color + "├" + bar + "┤" + RESET);
            for (int i = 0; i + 1 < kvs.length; i += 2) {
                String key = kvs[i] == null ? "" : kvs[i];
                String value = kvs[i + 1] == null ? "" : kvs[i + 1];
                if (value.isBlank()) {
                    continue;
                }
                String row = pad(key, 18) + " " + value;
                if (row.length() > 54) {
                    row = row.substring(0, 54);
                }
                System.out.println(BOLD + color + "│ " + pad(row, 54) + " │" + RESET);
            }
        }
        System.out.println(BOLD + color + "└" + bar + "┘" + RESET);
        System.out.println();
    }

    static void section(String title) {
        System.out.println();
        System.out.println(BOLD + CYAN + "── " + title + " " + "─".repeat(40) + RESET);
    }

    static void kv(String key, String value) {
        System.out.println("   " + DIM + pad(key, 18) + RESET + " " + value);
    }
}
