#!/bin/bash
# Scheduled reservations using evening SSO session (no re-login).
# Cron should fire ~1 minute early (install-crontab.sh). Flow:
#   validate → refresh session → compile → wait until RS_SCHEDULE_TIME → book
# so submit.asp hits as close to midnight as possible.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

# shellcheck source=../scripts/log.sh
source "$(cd "$SCRIPT_DIR/.." && pwd)/scripts/log.sh"

if [ -f "$SCRIPT_DIR/schedule.env" ]; then
  # shellcheck disable=SC1091
  set -a
  source "$SCRIPT_DIR/schedule.env"
  set +a
fi

mkdir -p logs
LOG_FILE="logs/scheduled-$(date +%Y%m%d-%H%M%S).log"

# Preserve classified/colored output on a TTY; strip ANSI only in log files
if [ -t 1 ]; then
  parking_log_enable_color
  export PARKING_LOG_COLOR=1
  export FORCE_COLOR=1
  exec > >(tee >(sed -e 's/\x1b\[[0-9;]*[a-zA-Z]//g' | tee -a "$LOG_FILE" >> logs/scheduled.log)) 2>&1
else
  exec > >(sed -e 's/\x1b\[[0-9;]*[a-zA-Z]//g' | tee -a "$LOG_FILE" >> logs/scheduled.log) 2>&1
fi

export SKIP_SSO_LOGIN=1
MAX_SESSION_AGE_HOURS="${MAX_SESSION_AGE_HOURS:-6}"
RS_SCHEDULE_TZ="${RS_SCHEDULE_TZ:-Asia/Manila}"
RS_SCHEDULE_TIME="${RS_SCHEDULE_TIME:-00:00:00}"

# Next occurrence of RS_SCHEDULE_TIME (supports cron starting the minute before midnight)
SCHEDULED_EXECUTION_TIME="$(
  python3 - "$RS_SCHEDULE_TZ" "$RS_SCHEDULE_TIME" <<'PY'
import sys
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

tz = ZoneInfo(sys.argv[1])
parts = [int(x) for x in sys.argv[2].strip().split(":")]
h, m = parts[0], parts[1]
s = parts[2] if len(parts) > 2 else 0
now = datetime.now(tz)
target = now.replace(hour=h, minute=m, second=s, microsecond=0)
# If target already passed (or we're within the same second), use tomorrow —
# except when we're still before target today (prewarm window).
if target <= now:
    # Allow a small grace: if cron was late by a few seconds past target, book ASAP
    # using "now" as already-reached (wait loop will no-op). Prefer tomorrow only
    # when we clearly started in the prewarm window for the *next* day.
    # Heuristic: if more than 2 minutes past target, aim for tomorrow.
    if (now - target).total_seconds() > 120:
        target += timedelta(days=1)
print(target.strftime("%Y-%m-%d %H:%M:%S"))
PY
)"

wait_until_scheduled_time() {
  local target="$1"
  local tz="$2"
  log_step "Waiting until $target ($tz)..."
  python3 - "$target" "$tz" <<'PY'
import sys
import time
from datetime import datetime
from zoneinfo import ZoneInfo

target_s, tz_name = sys.argv[1], sys.argv[2]
tz = ZoneInfo(tz_name)
target = datetime.strptime(target_s, "%Y-%m-%d %H:%M:%S").replace(tzinfo=tz)
while True:
    now = datetime.now(tz)
    if now >= target:
        print(f"Scheduled time reached: {now.strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]} {tz_name}")
        break
    remaining = (target - now).total_seconds()
    sleep_for = min(0.25, max(0.01, remaining))
    time.sleep(sleep_for)
PY
}

compile_booking_java() {
  log_step "Pre-compiling booking Java (before wait)..."
  mkdir -p target/classes
  javac -cp "lib/*" -d target/classes src/main/java/com/apitest/reservation/*.java
  log_ok "Compilation successful"
}

log_info "Log file: $LOG_FILE"
log_header "Scheduled reservations"
log_kv "Started" "$(date -Iseconds)"
log_kv "Directory" "$SCRIPT_DIR"
log_kv "SSO" "skipped (evening session)"
log_kv "Timezone" "$RS_SCHEDULE_TZ"
log_kv "Target" "$SCHEDULED_EXECUTION_TIME"

# shellcheck source=scripts/session.sh
source scripts/session.sh
validate_session_freshness "$MAX_SESSION_AGE_HOURS"
log_ok "Session file: $SESSION_FILE"

# --- Race path: refresh + compile BEFORE the midnight wait ---
KEEPALIVE_DIR="$(cd "$SCRIPT_DIR/../resource-scheduler-sso-login" && pwd)"
if [ -f "$KEEPALIVE_DIR/output/session.json" ]; then
  log_step "Refreshing session before wait (race path)..."
  if ! (cd "$KEEPALIVE_DIR" && node src/session-keepalive.js); then
    log_error "Session expired before booking. Check keep-alive loop log: $KEEPALIVE_DIR/logs/keepalive-loop.log"
    exit 1
  fi
  log_ok "Session refreshed"
fi

compile_booking_java

wait_until_scheduled_time "$SCHEDULED_EXECUTION_TIME" "$RS_SCHEDULE_TZ"
log_ok "Scheduled time reached — booking now"

# Book immediately (no Java wait, no second refresh/compile)
unset SCHEDULED_EXECUTION_TIME
export SKIP_SSO_LOGIN=1
export SKIP_COMPILE=1
export SKIP_RUN_LOG=1
./run-multiple.sh

log_success "Scheduled reservations finished: $(date -Iseconds)"
