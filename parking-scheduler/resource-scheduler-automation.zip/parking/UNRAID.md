# Unraid deploy guide

Run parking automation on your Unraid box so evening SSO + midnight booking stay on your personal machine. Two supported paths:

| Path | When to use |
|------|-------------|
| **Ubuntu VM** | Closest to a normal laptop install; easiest debugging |
| **Docker** | Unraid-native; always-on container with appdata volumes |

Do **not** install Node/Playwright/Java on the Unraid **host** via User Scripts — host upgrades wipe custom packages and Chromium deps break easily.

---

## Shared prerequisites

- Unraid stays powered on overnight (9 PM SSO → keep-alive → midnight book, Asia/Manila)
- Put appdata on an **always-mounted** pool/cache disk when possible (avoid array spin-up delays at 23:59)
- Network can reach Asurion SSO / Resource Scheduler (and AWS if you use SSM for the password)
- Phone ready for **PingID** when SSO runs (~9 PM or during a manual test login)
- Prefer transferring `resource-scheduler-automation.zip` (no secrets). Recreate config on Unraid; do **not** copy someone else’s `session.json`

Secrets to keep only on Unraid appdata / VM home (never in the zip):

- `resource-scheduler-sso-login/.env`
- `schedule.env`, `resources.txt`, `reservation.env`
- `output/session.json`
- SSO passphrase (`~/.config/resource-scheduler/sso-passphrase`)
- AWS credentials (if using SSM)

---

## Option A — Ubuntu VM

### 1. Create the VM

In Unraid **VMs**:

1. Create **Ubuntu 22.04 or 24.04** (2 vCPU, **2 GB RAM** minimum, 20+ GB disk)
2. Enable autostart
3. Set guest timezone to **Asia/Manila** (or rely on `CRON_TZ=Asia/Manila` after install)
4. Install SSH so you can administer it from your LAN

### 2. Copy the project

From a machine that has the zip (or this repo):

```bash
# on the VM
cd ~
# scp/rsync resource-scheduler-automation.zip here, then:
unzip resource-scheduler-automation.zip
cd parking
```

Or clone/copy the `parking/` tree. The zip already excludes secrets and `node_modules`.

### 3. Install OS packages

```bash
sudo apt update
sudo apt install -y openjdk-17-jdk nodejs npm python3 unzip cron curl

# AWS CLI v2 (needed unless you put RS_PASSWORD in .env and skip SSM)
curl -fsSL "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o /tmp/awscliv2.zip
sudo unzip -q /tmp/awscliv2.zip -d /tmp && sudo /tmp/aws/install
rm -rf /tmp/aws /tmp/awscliv2.zip
```

Ubuntu’s `nodejs` package is often new enough (18+). If `node -v` is older than 18, install Node 20 from [NodeSource](https://github.com/nodesource/distributions) instead.

Playwright’s Chromium needs OS libraries. After `npm install` (or as part of `./install.sh`):

```bash
cd ~/parking/resource-scheduler-sso-login
npm install
sudo npx playwright install-deps chromium
npx playwright install chromium
```

(`./install.sh` also runs `npm install` + `playwright install chromium`; the `install-deps` step is the one you may need once with `sudo`.)

### 4. Configure and enable schedules

```bash
cd ~/parking
./install.sh --schedules
```

You will be prompted for slots, reservation hours, passphrase, and SSO username/password (SSM upload unless `--skip-credentials`).

Approve **PingID** when login runs.

```bash
# PATH (new shells pick this up after install-cli)
export PATH="$HOME/.local/bin:$PATH"

parking status
parking crontab
parking login          # one-shot SSO test — approve PingID
```

### 5. Day-to-day

```bash
parking book           # manual book (refreshes session first)
parking refresh
parking keepalive status
parking uninstall      # remove cron only
```

Change days/times via `schedule.env` / SSO `.env`, then:

```bash
./install.sh --schedules
# or: parking install --schedules
```

### 6. Move off another machine

On the old host (only if you no longer want cron there):

```bash
parking uninstall
```

Run a fresh `parking login` on the VM; do not reuse an old `session.json` from another machine as a shortcut.

### VM troubleshooting

| Problem | Fix |
|---------|-----|
| `node not found` in cron | Use apt/NodeSource system Node; cron sources `scripts/cron-env.sh` (nvm fallback only) |
| PingID timeout | Approve within ~2 minutes of SSO start |
| Wrong book time | Check VM TZ and `CRON_TZ` / `parking crontab` |
| Playwright launch errors | `sudo npx playwright install-deps chromium` then reinstall browser |

Full install reference: [INSTALL.md](INSTALL.md)

---

## Option B — Docker (Unraid-native)

The image includes Node, Playwright Chromium, JDK 17, AWS CLI, and **cron**. Config and session live in Unraid **appdata** bind mounts so rebuilds do not wipe secrets.

### 1. Appdata layout

Create this on an always-on pool (example path):

```text
/mnt/user/appdata/parking/
├── config/
│   ├── .env                 # from .env.example
│   ├── schedule.env         # from schedule.env.example
│   ├── resources.txt        # from resources.txt.example
│   ├── reservation.env      # from reservation.env.example
│   └── sso-passphrase       # optional; or put under home/ (see below)
├── home/
│   └── .config/resource-scheduler/sso-passphrase
├── aws/                     # optional SSM
│   ├── credentials
│   └── config
├── output/                  # session.json appears here after login
├── logs-sso/
└── logs-book/
```

Seed configs from the project examples **before** the first container start (Docker will create a **directory** if you bind-mount a missing **file** — avoid that by creating files first):

```bash
APPDATA=/mnt/user/appdata/parking
mkdir -p "$APPDATA"/{config,home/.config/resource-scheduler,aws,output,logs-sso,logs-book}

# From a machine with the parking tree or unzipped zip:
cp parking/resource-scheduler-sso-login/.env.example          "$APPDATA/config/.env"
cp parking/resource-scheduler/schedule.env.example            "$APPDATA/config/schedule.env"
cp parking/resource-scheduler/resources.txt.example           "$APPDATA/config/resources.txt"
cp parking/resource-scheduler/reservation.env.example         "$APPDATA/config/reservation.env"
```

Edit on the Unraid host (or via share):

1. **`config/.env`** — `RS_USERNAME`, passphrase path, schedule hour; use SSM **or** set `RS_PASSWORD=` for local-only
2. **`config/schedule.env`** — `RS_SCHEDULE_DAYS`, `RS_SCHEDULE_TIME`
3. **`config/resources.txt`** — slot try order
4. **`config/reservation.env`** — start/end on the booked day
5. **Passphrase** — create `home/.config/resource-scheduler/sso-passphrase` (single line) if using encrypted SSM secrets
6. **`aws/credentials`** (+ `config`) if login loads the password from SSM

Set passphrase file path in `.env` if needed:

```bash
RS_CREDENTIALS_PASSPHRASE_FILE=$HOME/.config/resource-scheduler/sso-passphrase
```

(`HOME` inside the container is `/data/home`.)

### 2. Build and start

Copy the `parking/` project (or unzip) onto the Unraid box or a builder that can push the image. From the `parking/` directory:

```bash
export PARKING_APPDATA=/mnt/user/appdata/parking
docker compose build
docker compose up -d
```

On Unraid you can use the **Compose** plugin, or **Docker → Add Container** after building the image, with the same volume mounts as [docker-compose.yml](docker-compose.yml).

Entrypoint behavior:

1. Symlinks `/data/config/*` into the app tree
2. Installs the parking crontab (`CRON_TZ=Asia/Manila`, evening SSO + 1m-early book)
3. Starts `cron` and keeps the container running

### 3. First SSO login (PingID)

Cron will login at 9 PM; for a daytime test:

```bash
docker exec -it parking parking login
# or: docker compose exec parking parking login
```

Approve PingID on your phone. Confirm:

```bash
docker exec -it parking parking status
docker exec -it parking parking crontab
ls -la /mnt/user/appdata/parking/output/session.json
```

### 4. Useful commands

```bash
docker exec -it parking parking book
docker exec -it parking parking book --dry-run
docker exec -it parking parking refresh
docker exec -it parking parking keepalive status

# Reinstall crontab after editing schedule.env / .env on the host
docker exec -it parking parking install --schedules
# or: docker compose exec parking install-crontab

docker compose logs -f
docker compose restart
```

### 5. Rebuild after code updates

```bash
cd /path/to/parking
docker compose build --pull
docker compose up -d
```

Appdata volumes keep config, session, and logs.

### 6. Local password without AWS (optional)

If you do not want AWS CLI/SSM on Unraid, put the password in `config/.env`:

```bash
RS_PASSWORD=your-password
```

and omit the `aws/` mount. Prefer SSM + passphrase when you can — `.env` on a share is easier to leak.

### Docker troubleshooting

| Problem | Fix |
|---------|-----|
| Bind mount became a directory | Remove the mistaken dir; create the **file** on the host, then recreate the container |
| Cron not firing | `docker exec parking crontab -l`; ensure container stayed up overnight |
| `node`/`java` fine but SSO fails | Check `logs-sso/`; PingID timeout; `HEADED=0` is required in the container |
| SSM access denied | Fix `aws/credentials`, region, and passphrase |
| Book at wrong time | Confirm `TZ=Asia/Manila` and `schedule.env`; `parking crontab` |
| Missed midnight after array sleep | Move appdata to cache/pool; keep container on `unless-stopped` |

### Files added for Docker

| Path | Role |
|------|------|
| `Dockerfile` | Playwright base + JDK + cron + AWS CLI + app install |
| `docker-compose.yml` | Unraid appdata volume map |
| `docker/entrypoint.sh` | Link config, install crontab, run cron |
| `.dockerignore` | Exclude secrets / `node_modules` from build context |

---

## Choosing A vs B

- **VM** — same as [INSTALL.md](INSTALL.md); use if you want a full shell environment and interactive `./install.sh` prompts.
- **Docker** — preferred on Unraid if you already run apps via appdata + Compose; config edits stay on the host share.

Either way: one machine owns the cron. Uninstall schedules elsewhere so two hosts do not double-book.
