# Resource Scheduler SSO Login (Headless Sample)

Headless browser sample that logs into [Resource Scheduler](https://asurion.resourcescheduler.net/) through Ping SSO and exports session data for the reservation test project.

## SAML redirect (do not hardcode SSO URLs)

Every visit to [https://asurion.resourcescheduler.net/](https://asurion.resourcescheduler.net/) issues a **new** SAML request and redirects to a **unique, one-time** Ping URL like:

```
https://ndcsso.asurion.com:9031/idp/UMRYcTHGJh/resumeSAML20/idp/SSO.ping
                              ^^^^^^^^^^
                              changes every time
```

That `resumeSAML20` URL is tied to a single login attempt. If you bookmark it, paste it from an old recording, or refresh after it expires, Ping shows **Page Expired**.

**Always start from the RS root URL** and let the browser follow the redirect. The script does this via `RS_ENTRY_URL` — never set `RS_ENTRY_URL` to an `ndcsso.asurion.com` resume link.

## Prerequisites

| Requirement | Used for |
|-------------|----------|
| **Node.js** (18+) and **npm** | Playwright login script |
| **Playwright Chromium** | Headless browser (`npm run install:browsers`) |
| **AWS CLI** | Read/write SSM Parameter Store |
| **Python 3** | Parse credential JSON in shell scripts |
| **AWS credentials** | EC2 instance role, or `AWS_PROFILE` / `aws sso login` on your machine |
| **IAM** | `ssm:GetParameter` on `/credentials/<username>`; `ssm:PutParameter` for one-time upload |
| **Local passphrase file** | Decrypt credentials from SSM (`RS_CREDENTIALS_PASSPHRASE_FILE` in `.env`) |
| **Network** | Access to `asurion.resourcescheduler.net` and `ndcsso.asurion.com` |

**Not stored in git:** `.env`, passphrase file, `output/session.json`.

## What it does

1. Opens `https://asurion.resourcescheduler.net/` (redirects automatically to a fresh Ping SSO URL)
2. Completes Ping SSO (live selectors from `ndcsso.asurion.com`):

   **Step 1 — identifier page**
   | Field | Selector |
   |-------|----------|
   | Username | `#identifierName` |
   | Domain | `#domainInput` → `HQDOMAIN` (`int.asurion.com`) |
   | Next | `#postButton a` |

   **Step 2 — credentials page**
   | Field | Selector |
   |-------|----------|
   | Username | `#username` (`pf.username`, often pre-filled) |
   | Password | `#password` (`pf.pass`) |
   | Sign On | `#signOnButton` (link, not a button) |

3. Loads the schedule page
4. Extracts `sec_token`, session cookies, and the logged-in **display name**
5. Writes `output/session.json` (consumed by `../resource-scheduler` for booking)

## Setup

```bash
cd parking/resource-scheduler-sso-login
cp .env.example .env
npm install
npm run install:browsers
```

### Credentials (SSM + client-side encryption)

Credentials are **encrypted on your machine** before upload. SSM only stores ciphertext — AWS admins can read the blob but not your password without your local passphrase.

**1. Create a local passphrase file** (never commit or upload):

```bash
mkdir -p ~/.config/resource-scheduler
read -rsp "Choose a passphrase: " pass && echo
printf '%s' "$pass" > ~/.config/resource-scheduler/sso-passphrase
chmod 600 ~/.config/resource-scheduler/sso-passphrase
unset pass
```

**2. Upload encrypted credentials to SSM** (prompts for username, password, and passphrase):

```bash
./scripts/put-sso-credentials-to-ssm.sh
```

Stores at `/credentials/<username>` (e.g. `/credentials/your.username`).

**3. Configure `.env`:**

```bash
RS_USERNAME=your.username
RS_CREDENTIALS_PASSPHRASE_FILE=$HOME/.config/resource-scheduler/sso-passphrase
# AWS_REGION=us-east-1   # if needed
# AWS_PROFILE=your-profile
```

SSM stores an encrypted blob (AES-256-GCM + PBKDF2), not plaintext JSON.

**IAM:** `ssm:GetParameter` / `ssm:PutParameter` on `/credentials/*`.

**Cron:** the passphrase file must exist on the server (`RS_CREDENTIALS_PASSPHRASE_FILE` in `.env`).

**Local fallback:** set both `RS_USERNAME` and `RS_PASSWORD` in `.env` instead of using SSM.

## Scripts

| Script | When | What |
|--------|------|------|
| **`run-manual-login.sh`** | You run it | SSO login → `session.json` (token, cookies, display name) |
| **`run-scheduled-login.sh`** | Cron (default 9 PM) | Same, then keep-alive until booking window |
| **`run-session-keepalive.sh`** | Keep-alive loop | Refresh `sec_token` (+ `displayName` when found) |

## Run

```bash
./run-manual-login.sh
```

Or with a visible browser (helpful while validating selectors):

```bash
npm run login:headed
```

Successful login logs include `display name: ...` when the schedule page exposes the logged-in user.

## Weekday schedule (evening SSO)

Refresh `output/session.json` automatically every evening before booking (default 9 PM; configurable).

```bash
# Optional: set timezone in .env (default Asia/Manila)
# SSO_SCHEDULE_TZ=Asia/Manila
# SSO_SCHEDULE_HOUR=21
# SSO_SCHEDULE_MINUTE=0

./install-schedule.sh
```

- **macOS**: installs a LaunchAgent
- **Linux**: installs a crontab entry with `CRON_TZ`

SSO DOW defaults to `RS_SCHEDULE_DAYS − 1` in `../resource-scheduler/schedule.env` (e.g. booking `3-5` → SSO `2-4` at 9 PM). Override with `SSO_SCHEDULE_DAYS` in `.env` if needed. Prefer installing both projects together:

```bash
cd .. && ./install.sh --schedules
```

Runs the same as `./run-manual-login.sh` (headless when `HEADED=0` in `.env`), then keep-alive until the booking window.

Test the scheduled job manually:

```bash
./run-scheduled-login.sh
```

Logs: `logs/scheduled.log` and `logs/scheduled-YYYYMMDD-HHMMSS.log`

Remove schedule:

```bash
./uninstall-schedule.sh
```

For a visible browser during scheduled runs, set `HEADED=1` in `.env`.

## Output

`output/session.json` contains:

| Field | Purpose |
|-------|---------|
| `secToken` | Form token for `submit.asp` |
| `displayName` | Logged-in user from the schedule page (often `Last, First`) — booking uses this for `txtDesc` as `First Last` |
| `cookieHeader` | Cookie string for authenticated requests |
| `cookies` | Raw cookie objects from Playwright |
| `capturedAt` | ISO timestamp (freshness checks) |
| `scheduleUrl` | Schedule page used when the session was captured |
| `lastKeepAliveAt` | Set by keep-alive refreshes |

See `output/session.json.example` for the shape.

**Booking name:** each SSO user gets their own `displayName`. No hardcoded booker name in the Java form — re-run login after switching accounts.

## Configuration

| Variable | Description |
|----------|-------------|
| `RS_USERNAME` | SSO login id; loads password from `/credentials/<username>` |
| `RS_CREDENTIALS_PASSPHRASE_FILE` | Local passphrase file (never stored in AWS) |
| `RS_CREDENTIALS_PASSPHRASE` | Passphrase env override (avoid for cron) |
| `AWS_REGION` | AWS region for SSM (optional; uses CLI default) |
| `AWS_PROFILE` | AWS CLI profile (optional) |
| `RS_PASSWORD` | SSO password (local fallback only; omit when using SSM) |
| `RS_DOMAIN` | Ping domain dropdown when shown (default: `HQDOMAIN`) |
| `RS_ENTRY_URL` | Resource Scheduler entry point |
| `RS_TOPIC_ID` | Primary slot topic id (set by `parking/install.sh`, e.g. `123` for R123) |
| `RS_SCHEDULE_URL` | Schedule page used to scrape `sec_token` / display name (set by `parking/install.sh`) |
| `HEADED` | Set to `1` to show the browser |
| `SSO_MAX_ATTEMPTS` | Login retries before error (default: `3`) |
| `SSO_RETRY_DELAY_MS` | Pause between retries in ms (default: `3000`) |
| `SESSION_OUTPUT` | Path for exported session JSON |
| `SSO_SCHEDULE_TZ` | Timezone for cron schedule (default: `Asia/Manila`) |
| `SSO_SCHEDULE_HOUR` | Hour for weekday schedule (default: `21` = 9 PM) |
| `SSO_SCHEDULE_MINUTE` | Minute for weekday schedule (default: `0`) |
| `SSO_SCHEDULE_DAYS` | Optional cron DOW override; default = `RS_SCHEDULE_DAYS − 1` |

## Notes

- Keep `.env`, passphrase files, and `output/session.json` out of git. SSM holds ciphertext only; passphrase stays on your machine.
- Ping SSO pages can change; if login fails, run `npm run login:headed` and adjust selectors in `src/sso-login.js`.
- MFA or conditional access may block fully headless login. Use headed mode or complete MFA manually once, then inspect the flow.
- Failed logins retry up to `SSO_MAX_ATTEMPTS` times (default 3), with a fresh browser each attempt. Useful if Face ID times out.
- Session is consumed by `resource-scheduler` via `scripts/session.sh` (`-DsecToken`, `-Dcookies`, `-DdisplayName`, `-DsessionFile`).

## Related project

```bash
cd ../resource-scheduler
./run-multiple.sh              # SSO + try slots in order; retry until one books
./run-manual.sh                # first slot only (retries that slot)
SKIP_SSO_LOGIN=1 ./run-multiple.sh
```

Booking name comes from this project’s `session.json` → `displayName`. See `../resource-scheduler/README.md`.

## Weekday pipeline

| Time (Manila) | SSO | Booking |
|---------------|-----|---------|
| **9:00 PM** (booking − 1) | `run-scheduled-login.sh` → keep-alive every 5 min | — |
| **23:59** (1m early) | — | `../resource-scheduler/run-scheduled.sh` refresh + compile, then wait |
| **00:00:00** (submit target) | — | book immediately |

SSO runs on `RS_SCHEDULE_DAYS − 1`. `RS_SCHEDULE_TIME` is the **submit** second; book cron starts 1 minute early (`BOOK_PREWARM_MINUTES`). Example: book `2-5` @ midnight → SSO `1-4` @ 9 PM, book cron `1-4` @ 23:59. See `../resource-scheduler/README.md` and `../INSTALL.md`.
