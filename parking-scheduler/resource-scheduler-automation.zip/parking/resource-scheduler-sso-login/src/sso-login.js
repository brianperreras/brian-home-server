import 'dotenv/config';
import { chromium } from 'playwright';
import { mkdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { log } from './log.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT_DIR = path.resolve(__dirname, '..');

const USERNAME = process.env.RS_USERNAME?.trim() ?? '';
const PASSWORD = process.env.RS_PASSWORD ?? '';
const DOMAIN = process.env.RS_DOMAIN?.trim() || 'HQDOMAIN';
const ENTRY_URL =
  process.env.RS_ENTRY_URL?.trim() ||
  'https://asurion.resourcescheduler.net/';

function resolveScheduleUrl() {
  const fromEnv = process.env.RS_SCHEDULE_URL?.trim();
  if (fromEnv) {
    return fromEnv;
  }
  const topicId = process.env.RS_TOPIC_ID?.trim();
  if (topicId) {
    return `https://asurion.resourcescheduler.net/ResourceScheduler/schedule.asp?Topic=RES&TopicId=${topicId}&CDate=2026-1-1`;
  }
  throw new Error(
    'RS_SCHEDULE_URL or RS_TOPIC_ID must be set. Run parking/install.sh to configure booking slots.',
  );
}

const SCHEDULE_URL = resolveScheduleUrl();
const SESSION_OUTPUT =
  process.env.SESSION_OUTPUT?.trim() ||
  path.join(ROOT_DIR, 'output', 'session.json');
const HEADED = process.env.HEADED === '1';
const MAX_ATTEMPTS = Math.max(1, parseInt(process.env.SSO_MAX_ATTEMPTS ?? '3', 10) || 3);
const RETRY_DELAY_MS = Math.max(0, parseInt(process.env.SSO_RETRY_DELAY_MS ?? '3000', 10) || 3000);
const POST_LOGIN_TIMEOUT_MS = Math.max(
  30000,
  parseInt(process.env.SSO_POST_LOGIN_TIMEOUT_MS ?? '180000', 10) || 180000,
);

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function isNavigationContextError(error) {
  const message = error?.message ?? String(error);
  return /execution context was destroyed|navigation|target closed|frame was detached/i.test(message);
}

async function describeLoginPage(page) {
  let lastError;
  for (let attempt = 1; attempt <= 6; attempt++) {
    try {
      await page.waitForLoadState('domcontentloaded', { timeout: 10000 });
      const url = page.url();
      const title = await page.title();
      const snippet = (await page.locator('body').innerText({ timeout: 5000 }))
        .replace(/\s+/g, ' ')
        .trim()
        .slice(0, 500);
      return { url, title, snippet };
    } catch (error) {
      lastError = error;
      if (!isNavigationContextError(error) || attempt === 6) {
        throw error;
      }
      await sleep(250 * attempt);
    }
  }
  throw lastError ?? new Error('Could not read Ping SSO page');
}

async function saveFailureScreenshot(page, label) {
  const outputDir = path.join(ROOT_DIR, 'output');
  await mkdir(outputDir, { recursive: true });
  const shotPath = path.join(outputDir, `sso-failure-${label}-${Date.now()}.png`);
  await page.screenshot({ path: shotPath, fullPage: true });
  return shotPath;
}

async function dismissPasswordExpiryPrompt(page) {
  const { title, snippet } = await describeLoginPage(page);
  if (!/password expiring|change it later|change password/i.test(`${title} ${snippet}`)) {
    return false;
  }

  const dismiss = page.locator('#cancelButton, a:has-text("Change it later")').first();
  if ((await dismiss.count()) === 0) {
    return false;
  }

  log.step('Dismissing password-expiry prompt via "Change it later"');
  await dismiss.click();
  await page.waitForLoadState('domcontentloaded', { timeout: 30000 }).catch(() => {});
  return true;
}

async function waitForResourceScheduler(page) {
  log.step(
    'Waiting for redirect to Resource Scheduler — approve PingID on your phone if prompted...',
  );

  const deadline = Date.now() + POST_LOGIN_TIMEOUT_MS;
  let lastStatus = '';

  while (Date.now() < deadline) {
    const url = page.url();
    if (url.includes('resourcescheduler.net')) {
      log.ok(`SSO complete. Landed on: ${url}`);
      return;
    }

    await dismissPasswordExpiryPrompt(page);

    const { title, snippet } = await describeLoginPage(page);
    const status = `${title} | ${snippet.slice(0, 160)}`;
    if (status !== lastStatus) {
      const secondsLeft = Math.max(0, Math.round((deadline - Date.now()) / 1000));
      log.info(`Still on SSO (${secondsLeft}s left): ${status}`);
      lastStatus = status;
    }

    if (/page expired/i.test(`${title} ${snippet}`)) {
      const shotPath = await saveFailureScreenshot(page, 'expired');
      throw new Error(
        `Ping SAML page expired after Sign On. Do not open logged resume URLs manually. Screenshot: ${shotPath}`,
      );
    }

    if (/invalid|incorrect|failed|denied|locked|try again/i.test(snippet)) {
      const shotPath = await saveFailureScreenshot(page, 'error');
      throw new Error(
        `SSO rejected credentials or session: ${snippet.slice(0, 240)}. Screenshot: ${shotPath}`,
      );
    }

    try {
      await page.waitForURL(
        (candidate) => candidate.hostname.includes('resourcescheduler.net'),
        { timeout: 10000, waitUntil: 'domcontentloaded' },
      );
      log.ok(`SSO complete. Landed on: ${page.url()}`);
      return;
    } catch {
      await sleep(2000);
    }
  }

  const info = await describeLoginPage(page);
  const shotPath = await saveFailureScreenshot(page, 'timeout');
  throw new Error(
    `Timed out after Sign On (${POST_LOGIN_TIMEOUT_MS / 1000}s). ` +
      `Last page: ${info.title} — ${info.snippet.slice(0, 240)}. ` +
      `If PingID was shown, approve the notification on your phone during the run. Screenshot: ${shotPath}`,
  );
}

function requireCredentials() {
  if (!USERNAME || !PASSWORD) {
    log.error('Missing credentials.');
    log.error(
      'Set RS_USERNAME in .env (SSM path /credentials/<username>) or RS_USERNAME/RS_PASSWORD for local fallback.',
    );
    process.exit(1);
  }
}

async function performPingSsoLogin(page) {
  log.step('Waiting for Ping SSO login page...');
  await page.waitForURL(/ndcsso\.asurion\.com/, { timeout: 120000, waitUntil: 'domcontentloaded' });
  await page.waitForSelector('#identifierName', { timeout: 30000 });

  // Step 1 — identifier page (from live RS redirect inspection)
  // #identifierName, #domainInput (HQDOMAIN / int.asurion.com), #postButton a
  await page.locator('#identifierName').fill(USERNAME);
  log.step('Filled username via #identifierName');

  const domainSelect = page.locator('#domainInput');
  if (await domainSelect.isVisible()) {
    try {
      await domainSelect.selectOption({ label: DOMAIN });
    } catch {
      await domainSelect.selectOption({ value: 'int.asurion.com' });
    }
    log.step(`Selected domain via #domainInput (${DOMAIN})`);
  }

  await page.locator('#postButton a').click();
  log.step('Clicked Next via #postButton a');

  // Step 2 — credentials page: #username (pf.username), #password (pf.pass), #signOnButton (link)
  await page.waitForSelector('#password', { timeout: 30000 });

  const rsUsername = page.locator('#username');
  if (await rsUsername.isVisible()) {
    const current = await rsUsername.inputValue();
    if (!current.trim()) {
      await rsUsername.fill(USERNAME);
      log.step('Filled username via #username');
    }
  }

  await page.locator('#password').fill(PASSWORD);
  log.step('Filled password via #password');

  await page.locator('#signOnButton').click();
  log.step('Clicked Sign On via #signOnButton');

  await dismissPasswordExpiryPrompt(page);
  await waitForResourceScheduler(page);
}

async function extractSecToken(page) {
  const inputToken = page.locator('input[name="sec_token"]').first();
  if ((await inputToken.count()) > 0) {
    const value = await inputToken.inputValue();
    if (value) {
      return value;
    }
  }

  const html = await page.content();
  const patterns = [
    /name=["']sec_token["'][^>]*value=["']([^"']+)["']/i,
    /value=["']([^"']+)["'][^>]*name=["']sec_token["']/i,
    /sec_token=([^&"'\s]+)/i,
  ];

  for (const pattern of patterns) {
    const match = html.match(pattern);
    if (match?.[1]) {
      return decodeURIComponent(match[1]);
    }
  }

  throw new Error('Could not find sec_token on the schedule page.');
}

/**
 * Logged-in display name for submit.asp txtDesc (typically "Last, First").
 * Prefer form/header fields on the authenticated Resource Scheduler page.
 */
const DISPLAY_NAME_UI_WORDS =
  /^(welcome|log\s*out|sign\s*out|logout|home|help|settings|schedule|resource|menu|search)$/i;

function normalizeDisplayName(value) {
  if (!value) {
    return null;
  }
  let cleaned = String(value)
    .replace(/&nbsp;/gi, ' ')
    .replace(/&#(\d+);/g, (_, n) => String.fromCharCode(Number(n)))
    .replace(/&amp;/gi, '&')
    .replace(/&lt;/gi, '<')
    .replace(/&gt;/gi, '>')
    .replace(/&quot;/gi, '"')
    .replace(/\s+/g, ' ')
    .trim();
  // Strip trailing nav/UI tokens glued onto names (e.g. "Perreras, Brian Help")
  const parts = cleaned.split(/\s+/);
  while (parts.length > 1 && DISPLAY_NAME_UI_WORDS.test(parts[parts.length - 1])) {
    parts.pop();
  }
  cleaned = parts.join(' ');
  if (!cleaned || cleaned.length < 3 || cleaned.length > 120) {
    return null;
  }
  // Reject obvious non-name UI strings
  if (DISPLAY_NAME_UI_WORDS.test(cleaned)) {
    return null;
  }
  return cleaned;
}

function extractDisplayNameFromHtml(html) {
  if (!html) {
    return null;
  }

  const patterns = [
    /name=["']txtDesc["'][^>]*value=["']([^"']+)["']/i,
    /value=["']([^"']+)["'][^>]*name=["']txtDesc["']/i,
    /id=["'](?:lblUserName|lblUser|UserName|txtUserName|spnUser)["'][^>]*>\s*([^<]+)/i,
    /(?:Logged\s*in\s*as|Welcome)\s*[:\-]?\s*([^<\n\r|]{3,80})/i,
    /(?:var\s+)?g_sUser(?:Name|FullName)?\s*=\s*["']([^"']+)["']/i,
    /(?:var\s+)?sUser(?:Name|FullName)?\s*=\s*["']([^"']+)["']/i,
    /["']displayName["']\s*[:=]\s*["']([^"']+)["']/i,
  ];

  for (const pattern of patterns) {
    const match = html.match(pattern);
    const name = normalizeDisplayName(match?.[1] ? decodeURIComponent(match[1].replace(/\+/g, ' ')) : null);
    if (name) {
      return name;
    }
  }
  return null;
}

async function extractDisplayName(page) {
  const fromInput = page.locator('input[name="txtDesc"]').first();
  if ((await fromInput.count()) > 0) {
    const value = normalizeDisplayName(await fromInput.inputValue());
    if (value) {
      return value;
    }
  }

  const fromLabel = page.locator('#lblUserName, #lblUser, #UserName, #txtUserName, #spnUser').first();
  if ((await fromLabel.count()) > 0) {
    const value = normalizeDisplayName(await fromLabel.innerText());
    if (value) {
      return value;
    }
  }

  const fromDom = await page.evaluate(() => {
    const pick = (value) => (value || '').replace(/\s+/g, ' ').trim();

    const txtDesc = document.querySelector('input[name="txtDesc"]');
    if (txtDesc?.value) {
      return pick(txtDesc.value);
    }

    for (const sel of ['#lblUserName', '#lblUser', '#UserName', '#txtUserName', '#spnUser']) {
      const el = document.querySelector(sel);
      if (el?.textContent) {
        return pick(el.textContent);
      }
    }

    const bodyText = document.body?.innerText || '';
    const welcome = bodyText.match(/(?:Logged\s*in\s*as|Welcome)\s*[:\-]?\s*([^\n|]{3,80})/i);
    if (welcome?.[1]) {
      return pick(welcome[1]);
    }

    // Resource Scheduler often shows "Last, First" in the top chrome
    const commaName = bodyText.match(
      /\b([A-Za-z][A-Za-z'\-]+,\s*[A-Za-z][A-Za-z'\-]+(?:\s+(?!Help|Home|Logout|Settings|Schedule)[A-Za-z][A-Za-z'\-]*)?)\b/,
    );
    if (commaName?.[1]) {
      return pick(commaName[1]);
    }

    return '';
  }).catch(() => '');

  const normalizedDom = normalizeDisplayName(fromDom);
  if (normalizedDom) {
    return normalizedDom;
  }

  return extractDisplayNameFromHtml(await page.content());
}

function buildCookieHeader(cookies) {
  return cookies.map((cookie) => `${cookie.name}=${cookie.value}`).join('; ');
}

async function saveSession(context, page, secToken, displayName) {
  const cookies = await context.cookies('https://asurion.resourcescheduler.net');
  const payload = {
    capturedAt: new Date().toISOString(),
    scheduleUrl: page.url(),
    secToken,
    displayName: displayName || undefined,
    cookieHeader: buildCookieHeader(cookies),
    cookies,
  };

  const outputPath = path.resolve(ROOT_DIR, SESSION_OUTPUT);
  await mkdir(path.dirname(outputPath), { recursive: true });
  await writeFile(outputPath, `${JSON.stringify(payload, null, 2)}\n`, 'utf8');

  log.success(`Session saved to: ${outputPath}`);
  log.info(`sec_token prefix: ${secToken.slice(0, 24)}...`);
  if (displayName) {
    log.ok(`display name: ${displayName}`);
  } else {
    log.warn('display name: (not found on schedule page — booking will try again at submit)');
  }
  log.info(`cookie count: ${cookies.length}`);
}

async function captureSessionOnce() {
  const browser = await chromium.launch({ headless: !HEADED });
  try {
    const context = await browser.newContext({
      ignoreHTTPSErrors: true,
      viewport: { width: 977, height: 854 },
    });
    const page = await context.newPage();

    log.step(`Opening: ${ENTRY_URL}`);
    await page.goto(ENTRY_URL, { waitUntil: 'domcontentloaded', timeout: 120000 });

    if (!page.url().includes('ndcsso.asurion.com')) {
      await page.waitForURL(/ndcsso\.asurion\.com|resourcescheduler\.net/, {
        timeout: 120000,
      });
    }

    if (page.url().includes('ndcsso.asurion.com') || page.url().includes('ping')) {
      log.info('Redirected to Ping SSO (single-use URL — do not open manually)');
      await performPingSsoLogin(page);
    } else if (page.url().includes('resourcescheduler.net')) {
      log.ok('Already on Resource Scheduler; skipping SSO form.');
    } else {
      throw new Error(`Unexpected landing page after entry URL: ${page.url()}`);
    }

    log.step(`Opening schedule page: ${SCHEDULE_URL}`);
    await page.goto(SCHEDULE_URL, { waitUntil: 'domcontentloaded', timeout: 120000 });

    if (page.url().includes('ndcsso.asurion.com')) {
      log.warn('Schedule page redirected to SSO; logging in again.');
      await performPingSsoLogin(page);
      await page.goto(SCHEDULE_URL, { waitUntil: 'domcontentloaded', timeout: 120000 });
    }

    const secToken = await extractSecToken(page);
    const displayName = await extractDisplayName(page);
    await saveSession(context, page, secToken, displayName);
  } finally {
    await browser.close();
  }
}

async function main() {
  requireCredentials();

  let lastError;

  for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
    try {
      log.header(`SSO login attempt ${attempt}/${MAX_ATTEMPTS}`);
      await captureSessionOnce();
      log.success('SSO login succeeded.');
      return;
    } catch (error) {
      lastError = error;
      log.error(`Attempt ${attempt} failed: ${error.message}`);

      if (attempt < MAX_ATTEMPTS) {
        log.warn(`Retrying in ${RETRY_DELAY_MS / 1000}s...`);
        await sleep(RETRY_DELAY_MS);
      }
    }
  }

  throw lastError ?? new Error('SSO login failed');
}

main().catch((error) => {
  log.error(`SSO login failed: ${error.message}`);
  process.exit(1);
});
