import 'dotenv/config';
import { readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { log } from './log.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT_DIR = path.resolve(__dirname, '..');

const SESSION_OUTPUT =
  process.env.SESSION_OUTPUT?.trim() ||
  path.join(ROOT_DIR, 'output', 'session.json');
const RESERVATION_DAYS_AHEAD = Math.max(
  0,
  parseInt(process.env.RESERVATION_DAYS_AHEAD ?? '7', 10) || 7,
);
const RESERVATION_TZ = process.env.RS_SCHEDULE_TZ?.trim() || 'Asia/Manila';
const USER_AGENT =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36';

const SSO_MARKERS = ['ndcsso.asurion.com', 'identifiername', 'signonbutton'];
const SEC_TOKEN_PATTERNS = [
  /name=["']sec_token["'][^>]*value=["']([^"']+)["']/i,
  /value=["']([^"']+)["'][^>]*name=["']sec_token["']/i,
];

function reservationDate() {
  const target = Date.now() + RESERVATION_DAYS_AHEAD * 24 * 60 * 60 * 1000;
  const parts = new Intl.DateTimeFormat('en-US', {
    timeZone: RESERVATION_TZ,
    year: 'numeric',
    month: 'numeric',
    day: 'numeric',
  }).formatToParts(new Date(target));
  const get = (type) => parts.find((part) => part.type === type)?.value;
  return `${get('year')}-${get('month')}-${get('day')}`;
}

function resolveTopicId(session) {
  const fromEnv = process.env.RS_TOPIC_ID?.trim();
  if (fromEnv) {
    return fromEnv;
  }
  if (session.scheduleUrl?.includes('schedule.asp')) {
    const url = new URL(session.scheduleUrl);
    const id = url.searchParams.get('TopicId');
    if (id) {
      return id;
    }
  }
  throw new Error(
    'RS_TOPIC_ID not set and session has no TopicId. Run parking/install.sh to configure booking slots.',
  );
}

function schedulePageUrl(session) {
  const topicId = resolveTopicId(session);
  const base =
    'https://asurion.resourcescheduler.net/ResourceScheduler/schedule.asp?Topic=RES&TopicId=';

  if (session.scheduleUrl?.includes('schedule.asp')) {
    const url = new URL(session.scheduleUrl);
    url.searchParams.set('CDate', reservationDate());
    return url.toString();
  }

  return `${base}${topicId}&CDate=${reservationDate()}`;
}

function extractSecToken(html) {
  for (const pattern of SEC_TOKEN_PATTERNS) {
    const match = html.match(pattern);
    if (match?.[1]) {
      return decodeURIComponent(match[1]);
    }
  }
  return null;
}

const DISPLAY_NAME_UI_WORDS =
  /^(welcome|log\s*out|sign\s*out|logout|home|help|settings|schedule|resource|menu|search)$/i;

function normalizeDisplayName(value) {
  if (!value) {
    return null;
  }
  let cleaned = String(value)
    .replace(/&nbsp;/gi, ' ')
    .replace(/&#(\d+);/g, (_, n) => String.fromCharCode(Number(n)))
    .replace(/&amp;/gi, '&')
    .replace(/\s+/g, ' ')
    .trim();
  const parts = cleaned.split(/\s+/);
  while (parts.length > 1 && DISPLAY_NAME_UI_WORDS.test(parts[parts.length - 1])) {
    parts.pop();
  }
  cleaned = parts.join(' ');
  if (!cleaned || cleaned.length < 3 || cleaned.length > 120) {
    return null;
  }
  if (DISPLAY_NAME_UI_WORDS.test(cleaned)) {
    return null;
  }
  return cleaned;
}

function extractDisplayName(html) {
  if (!html) {
    return null;
  }
  const patterns = [
    /name=["']txtDesc["'][^>]*value=["']([^"']+)["']/i,
    /value=["']([^"']+)["'][^>]*name=["']txtDesc["']/i,
    /id=["'](?:lblUserName|lblUser|UserName|txtUserName|spnUser)["'][^>]*>\s*([^<]+)/i,
    /(?:Logged\s*in\s*as|Welcome)\s*[:\-]?\s*([^<\n\r|]{3,80})/i,
    /(?:var\s+)?g_sUser(?:Name|FullName)?\s*=\s*["']([^"']+)["']/i,
    /(?:var\s+)?sUser(?:Name|FullName)?\s*=\s*["']([^"']+)["']/i,
  ];
  for (const pattern of patterns) {
    const match = html.match(pattern);
    const name = normalizeDisplayName(
      match?.[1] ? decodeURIComponent(match[1].replace(/\+/g, ' ')) : null,
    );
    if (name) {
      return name;
    }
  }
  return null;
}

function isSsoLoginPage(html) {
  const lower = html.toLowerCase();
  return SSO_MARKERS.some((marker) => lower.includes(marker));
}

async function loadSession() {
  const sessionPath = path.resolve(ROOT_DIR, SESSION_OUTPUT);
  const raw = await readFile(sessionPath, 'utf8');
  const session = JSON.parse(raw);

  if (!session.cookieHeader) {
    throw new Error(`Session file is missing cookieHeader: ${sessionPath}`);
  }

  return { sessionPath, session };
}

async function saveSession(sessionPath, session) {
  await writeFile(sessionPath, `${JSON.stringify(session, null, 2)}\n`, 'utf8');
}

async function main() {
  const { sessionPath, session } = await loadSession();
  const url = schedulePageUrl(session);

  log.info(`Session file: ${sessionPath}`);
  log.info(`Reservation date: ${reservationDate()} (${RESERVATION_TZ}, today + ${RESERVATION_DAYS_AHEAD})`);
  log.step(`Refreshing schedule page: ${url}`);

  const response = await fetch(url, {
    method: 'GET',
    redirect: 'manual',
    headers: {
      Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
      Cookie: session.cookieHeader,
      'User-Agent': USER_AGENT,
    },
  });

  if (response.status >= 300 && response.status < 400) {
    throw new Error(`Session expired (redirect to ${response.headers.get('location') ?? 'login'})`);
  }

  if (!response.ok) {
    throw new Error(`Schedule page returned HTTP ${response.status}`);
  }

  const html = await response.text();
  if (isSsoLoginPage(html)) {
    throw new Error('Session expired — SSO login page returned');
  }

  const secToken = extractSecToken(html);
  if (!secToken) {
    throw new Error('Could not find sec_token on schedule page');
  }

  const displayName = extractDisplayName(html);

  // Keep cookieHeader from SSO login — merging Set-Cookie here broke sessions on the next ping.
  session.secToken = secToken;
  session.scheduleUrl = url;
  session.lastKeepAliveAt = new Date().toISOString();
  if (displayName) {
    session.displayName = displayName;
  }

  await saveSession(sessionPath, session);

  log.ok(`Keep-alive OK at ${session.lastKeepAliveAt}`);
  log.info(`sec_token prefix: ${secToken.slice(0, 24)}...`);
  if (displayName) {
    log.ok(`display name: ${displayName}`);
  }
}

main().catch((error) => {
  log.error(`Keep-alive failed: ${error.message}`);
  process.exit(1);
});
