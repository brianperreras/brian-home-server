import 'dotenv/config';
import { spawn } from 'node:child_process';
import { readFile, appendFile, mkdir } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT_DIR = path.resolve(__dirname, '..');

const SESSION_OUTPUT =
  process.env.SESSION_OUTPUT?.trim() ||
  path.join(ROOT_DIR, 'output', 'session.json');
const LOG_FILE =
  process.env.EXPIRY_PROBE_LOG?.trim() ||
  path.join(ROOT_DIR, 'logs', 'expiry-probe.log');
const RESERVATION_TZ = process.env.RS_SCHEDULE_TZ?.trim() || 'Asia/Manila';
const USER_AGENT =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36';

const SSO_MARKERS = ['ndcsso.asurion.com', 'identifiername', 'signonbutton'];

function parseArgs(argv) {
  const args = {
    mode: 'keepalive',
    intervalMinutes: 10,
    idleWaitMinutes: 180,
    maxHours: 8,
  };

  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    if (arg === '--mode' && argv[i + 1]) {
      args.mode = argv[++i];
    } else if (arg === '--interval-minutes' && argv[i + 1]) {
      args.intervalMinutes = Math.max(1, parseInt(argv[++i], 10) || 10);
    } else if (arg === '--idle-wait-minutes' && argv[i + 1]) {
      args.idleWaitMinutes = Math.max(1, parseInt(argv[++i], 10) || 180);
    } else if (arg === '--max-hours' && argv[i + 1]) {
      args.maxHours = Math.max(1, parseFloat(argv[++i]) || 8);
    }
  }

  return args;
}

function reservationDate() {
  const target = Date.now() + 7 * 24 * 60 * 60 * 1000;
  const parts = new Intl.DateTimeFormat('en-US', {
    timeZone: RESERVATION_TZ,
    year: 'numeric',
    month: 'numeric',
    day: 'numeric',
  }).formatToParts(new Date(target));
  const get = (type) => parts.find((part) => part.type === type)?.value;
  return `${get('year')}-${get('month')}-${get('day')}`;
}

function resolveTopicId(session) {
  const fromEnv = process.env.RS_TOPIC_ID?.trim();
  if (fromEnv) {
    return fromEnv;
  }
  if (session.scheduleUrl?.includes('schedule.asp')) {
    const url = new URL(session.scheduleUrl);
    const id = url.searchParams.get('TopicId');
    if (id) {
      return id;
    }
  }
  throw new Error(
    'RS_TOPIC_ID not set and session has no TopicId. Run parking/install.sh to configure booking slots.',
  );
}

function schedulePageUrl(session) {
  if (session.scheduleUrl?.includes('schedule.asp')) {
    const url = new URL(session.scheduleUrl);
    url.searchParams.set('CDate', reservationDate());
    return url.toString();
  }
  const topicId = resolveTopicId(session);
  return `https://asurion.resourcescheduler.net/ResourceScheduler/schedule.asp?Topic=RES&TopicId=${topicId}&CDate=${reservationDate()}`;
}

function isSsoLoginPage(html) {
  const lower = html.toLowerCase();
  return SSO_MARKERS.some((marker) => lower.includes(marker));
}

function formatDuration(ms) {
  const totalMinutes = Math.round(ms / 60000);
  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;
  if (hours === 0) return `${minutes}m`;
  return `${hours}h ${minutes}m`;
}

async function logLine(message) {
  const line = `[${new Date().toISOString()}] ${message}\n`;
  process.stdout.write(line);
  await mkdir(path.dirname(LOG_FILE), { recursive: true });
  await appendFile(LOG_FILE, line, 'utf8');
}

async function loadSession() {
  const sessionPath = path.resolve(ROOT_DIR, SESSION_OUTPUT);
  const session = JSON.parse(await readFile(sessionPath, 'utf8'));
  if (!session.cookieHeader) {
    throw new Error(`Missing cookieHeader in ${sessionPath}`);
  }
  if (!session.capturedAt) {
    throw new Error(`Missing capturedAt in ${sessionPath}`);
  }
  return { sessionPath, session };
}

async function probeSession(session, url) {
  const response = await fetch(url, {
    method: 'GET',
    redirect: 'manual',
    headers: {
      Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
      Cookie: session.cookieHeader,
      'User-Agent': USER_AGENT,
    },
  });

  if (response.status >= 300 && response.status < 400) {
    return {
      ok: false,
      reason: `redirect to ${response.headers.get('location') ?? 'login'}`,
    };
  }

  if (!response.ok) {
    return { ok: false, reason: `HTTP ${response.status}` };
  }

  const html = await response.text();
  if (isSsoLoginPage(html)) {
    return { ok: false, reason: 'SSO login page returned' };
  }

  return { ok: true, reason: 'schedule page OK' };
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function runKeepaliveScript() {
  return new Promise((resolve, reject) => {
    const child = spawn('node', ['src/session-keepalive.js'], {
      cwd: ROOT_DIR,
      env: process.env,
      stdio: ['ignore', 'pipe', 'pipe'],
    });

    let output = '';
    child.stdout.on('data', (chunk) => {
      output += chunk;
    });
    child.stderr.on('data', (chunk) => {
      output += chunk;
    });
    child.on('close', (code) => {
      if (code === 0) {
        resolve(output.trim());
        return;
      }
      const lastLine = output.trim().split('\n').pop() ?? `exit ${code}`;
      reject(new Error(lastLine));
    });
  });
}

async function runIdleProbe(idleWaitMinutes) {
  const { sessionPath, session } = await loadSession();
  const loginAt = Date.parse(session.capturedAt);
  const url = schedulePageUrl(session);

  await logLine(`MODE=idle session=${sessionPath}`);
  await logLine(`Login capturedAt=${session.capturedAt}`);
  await logLine(`Waiting ${idleWaitMinutes} minutes with zero requests before probe...`);

  await sleep(idleWaitMinutes * 60 * 1000);

  const elapsedMs = Date.now() - loginAt;
  const result = await probeSession(session, url);

  if (result.ok) {
    await logLine(
      `IDLE_PROBE_OK elapsed=${formatDuration(elapsedMs)} idle_wait=${idleWaitMinutes}m — session survived ${idleWaitMinutes}m idle`,
    );
    return 0;
  }

  await logLine(
    `IDLE_PROBE_FAIL elapsed=${formatDuration(elapsedMs)} idle_wait=${idleWaitMinutes}m reason=${result.reason}`,
  );
  return 1;
}

async function runKeepaliveProbe(intervalMinutes, maxHours) {
  const { sessionPath, session } = await loadSession();
  const loginAt = Date.parse(session.capturedAt);
  const maxMs = maxHours * 60 * 60 * 1000;
  let probeCount = 0;

  await logLine(`MODE=keepalive session=${sessionPath}`);
  await logLine(`Login capturedAt=${session.capturedAt}`);
  await logLine(`Uses session-keepalive.js every ${intervalMinutes}m until failure or ${maxHours}h max`);

  while (Date.now() - loginAt < maxMs) {
    probeCount += 1;
    const elapsedMs = Date.now() - loginAt;

    try {
      const output = await runKeepaliveScript();
      const summary = output.split('\n').slice(-2).join(' | ');
      await logLine(
        `PROBE #${probeCount} OK elapsed=${formatDuration(elapsedMs)} ${summary}`,
      );
    } catch (error) {
      await logLine(
        `SESSION_EXPIRED probe=#${probeCount} elapsed=${formatDuration(elapsedMs)} reason=${error.message}`,
      );
      await logLine(
        `RESULT keepalive_interval=${intervalMinutes}m session_lifetime=${formatDuration(elapsedMs)}`,
      );
      return 1;
    }

    const nextDelayMs = intervalMinutes * 60 * 1000;
    const remainingMs = maxMs - (Date.now() - loginAt);
    if (remainingMs <= nextDelayMs) {
      break;
    }
    await sleep(nextDelayMs);
  }

  const elapsedMs = Date.now() - loginAt;
  await logLine(
    `SESSION_STILL_VALID after ${formatDuration(elapsedMs)} with ${probeCount} probes every ${intervalMinutes}m (max ${maxHours}h reached)`,
  );
  return 0;
}

async function main() {
  const args = parseArgs(process.argv.slice(2));

  if (args.mode === 'idle') {
    process.exitCode = await runIdleProbe(args.idleWaitMinutes);
    return;
  }

  if (args.mode === 'keepalive') {
    process.exitCode = await runKeepaliveProbe(args.intervalMinutes, args.maxHours);
    return;
  }

  throw new Error(`Unknown mode: ${args.mode}. Use keepalive or idle.`);
}

main().catch(async (error) => {
  await logLine(`PROBE_ERROR ${error.message}`);
  process.exitCode = 1;
});
