/**
 * Colored, classified console logging for SSO scripts.
 * Disable with NO_COLOR=1 or PARKING_LOG_COLOR=0.
 */

const useColor =
  !process.env.NO_COLOR &&
  process.env.PARKING_LOG_COLOR !== '0' &&
  (process.env.PARKING_LOG_COLOR === '1' ||
    process.env.FORCE_COLOR === '1' ||
    Boolean(process.stdout.isTTY));

const c = {
  reset: useColor ? '\x1b[0m' : '',
  bold: useColor ? '\x1b[1m' : '',
  dim: useColor ? '\x1b[2m' : '',
  red: useColor ? '\x1b[31m' : '',
  green: useColor ? '\x1b[32m' : '',
  yellow: useColor ? '\x1b[33m' : '',
  blue: useColor ? '\x1b[34m' : '',
  magenta: useColor ? '\x1b[35m' : '',
  cyan: useColor ? '\x1b[36m' : '',
};

function line(stream, color, icon, label, msg, { colorMsg = false } = {}) {
  if (colorMsg) {
    stream.write(`${color}${c.bold}${icon} ${label.padEnd(7)} ${msg}${c.reset}\n`);
  } else {
    stream.write(`${color}${c.bold}${icon} ${label.padEnd(7)}${c.reset} ${msg}\n`);
  }
}

export const log = {
  info(msg) {
    line(process.stdout, c.cyan, 'ℹ', 'INFO', msg);
  },
  ok(msg) {
    line(process.stdout, c.green, '✔', 'OK', msg, { colorMsg: true });
  },
  success(msg) {
    line(process.stdout, c.green, '✔', 'SUCCESS', msg, { colorMsg: true });
  },
  warn(msg) {
    line(process.stderr, c.yellow, '⚠', 'WARN', msg, { colorMsg: true });
  },
  error(msg) {
    line(process.stderr, c.red, '✖', 'ERROR', msg, { colorMsg: true });
  },
  step(msg) {
    line(process.stdout, c.blue, '▸', 'STEP', msg);
  },
  header(title) {
    const bar = '─'.repeat(56);
    process.stdout.write(
      `\n${c.bold}${c.magenta}┌${bar}┐${c.reset}\n` +
        `${c.bold}${c.magenta}│ ${String(title).padEnd(54)} │${c.reset}\n` +
        `${c.bold}${c.magenta}└${bar}┘${c.reset}\n\n`,
    );
  },
  section(title) {
    process.stdout.write(`\n${c.bold}${c.cyan}── ${title} ${'─'.repeat(40)}${c.reset}\n`);
  },
  kv(key, value) {
    process.stdout.write(`   ${c.dim}${String(key).padEnd(18)}${c.reset} ${value}\n`);
  },
};

export { useColor };
