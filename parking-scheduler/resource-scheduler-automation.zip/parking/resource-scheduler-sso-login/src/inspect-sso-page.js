import { chromium } from 'playwright';

const browser = await chromium.launch({ headless: true });
const page = await browser.newPage({ ignoreHTTPSErrors: true });
await page.goto('https://asurion.resourcescheduler.net/', {
  waitUntil: 'domcontentloaded',
  timeout: 120000,
});

await page.waitForURL(/ndcsso\.asurion\.com/, { timeout: 120000 });
await page.waitForLoadState('networkidle');
await page.waitForTimeout(2000);

console.log('URL:', page.url());
console.log('Title:', await page.title());

const fields = await page.evaluate(() => {
  const out = { inputs: [], selects: [], buttons: [], links: [] };
  document.querySelectorAll('input').forEach((el) => {
    out.inputs.push({
      id: el.id,
      name: el.name,
      type: el.type,
      placeholder: el.placeholder,
      visible: el.offsetParent !== null,
    });
  });
  document.querySelectorAll('select').forEach((el) => {
    out.selects.push({
      id: el.id,
      name: el.name,
      options: [...el.options].map((o) => ({ value: o.value, text: o.text })),
      visible: el.offsetParent !== null,
    });
  });
  document.querySelectorAll('button').forEach((el) => {
    out.buttons.push({
      id: el.id,
      name: el.name,
      type: el.type,
      text: el.innerText.trim(),
      visible: el.offsetParent !== null,
    });
  });
  document.querySelectorAll('a').forEach((el) => {
    const text = el.innerText.trim();
    if (text) {
      out.links.push({
        id: el.id,
        href: el.getAttribute('href'),
        text,
        visible: el.offsetParent !== null,
      });
    }
  });
  return out;
});

console.log(JSON.stringify(fields, null, 2));

const nextLink = page.locator('a:has-text("Next")').first();
if (await nextLink.count()) {
  const nextMeta = await nextLink.evaluate((el) => ({
    id: el.id,
    href: el.getAttribute('href'),
    parentId: el.parentElement?.id,
    outer: el.outerHTML.slice(0, 200),
  }));
  console.log('Next link:', JSON.stringify(nextMeta, null, 2));
}

// Fill dummy values and click Next to inspect password step (no real credentials)
await page.locator('#identifierName').fill('probe-user');
await page.locator('#domainInput').selectOption({ label: 'HQDOMAIN' });
await page.locator('a:has-text("Next")').first().click();
await page.waitForLoadState('networkidle');
await page.waitForTimeout(2000);

console.log('After Next URL:', page.url());
console.log('After Next Title:', await page.title());

const step2 = await page.evaluate(() => {
  const out = { inputs: [], buttons: [], links: [] };
  document.querySelectorAll('input').forEach((el) => {
    out.inputs.push({
      id: el.id,
      name: el.name,
      type: el.type,
      visible: el.offsetParent !== null,
    });
  });
  document.querySelectorAll('button').forEach((el) => {
    out.buttons.push({
      id: el.id,
      name: el.name,
      type: el.type,
      text: el.innerText.trim(),
      visible: el.offsetParent !== null,
    });
  });
  document.querySelectorAll('a').forEach((el) => {
    const text = el.innerText.trim();
    if (text) {
      out.links.push({ id: el.id, text, visible: el.offsetParent !== null });
    }
  });
  return out;
});
console.log('Step 2 fields:', JSON.stringify(step2, null, 2));
await browser.close();
