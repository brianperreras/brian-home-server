/** @type {import('@playwright/test').PlaywrightTestConfig} */
export default {
  timeout: 120000,
  use: {
    headless: process.env.HEADED !== '1',
    ignoreHTTPSErrors: true,
    viewport: { width: 1280, height: 720 },
  },
};
