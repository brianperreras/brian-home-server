# Fix: `run-manual-login.sh` empty / missing logs

Share this with anyone setting up the parking automation (or paste into Cursor AI to apply the same fix).

## Problem

After running `./run-manual-login.sh`, log files were created but stayed **empty** during the run (and sometimes after):

- `logs/manual-YYYYMMDD-HHMMSS.log`

SSO could still succeed (session saved, keep-alive loop started), but there was nothing useful in the manual logs.

## Root cause

Logging used a **subshell piped to `tee`**:

```bash
{
  echo "Manual SSO login started..."
  run_manual_login
  echo "Manual SSO login finished..."
} 2>&1 | sed ... | tee -a "$LOG_FILE"
```

Issues with this pattern:

1. **Block buffering** — when stdout is not a TTY (pipe), output is buffered until the subshell exits. A long SSO run (PingID, Playwright) can take 1–2+ minutes with an empty log file the whole time.
2. **No live terminal output** — the pipeline had no terminal `tee`, so interactive runs showed little or nothing on screen while waiting.
3. **Looked broken** — opening the log mid-run showed 0 bytes even though the script was working.

## Fix

Use **`exec` + process substitution + `tee`** so each line is written immediately to:

- the terminal
- `logs/manual-YYYYMMDD-HHMMSS.log` (append)

Same pattern as `resource-scheduler/run-multiple.sh`.

## Files to change

1. `resource-scheduler-sso-login/run-manual-login.sh`
2. `resource-scheduler-sso-login/run-scheduled-login.sh` (same pipe issue for 9 PM cron logs)

---

## 1. `run-manual-login.sh`

**Remove** the old block at the bottom:

```bash
{
  echo "================================================"
  echo "Manual SSO login started: $(date -Iseconds)"
  ...
  run_manual_login
  ...
} 2>&1 | sed -e 's/\x1b\[[0-9;]*[a-zA-Z]//g' | tee -a "$LOG_FILE"
```

**Replace** with (keep the existing `SKIP_LOGIN_LOG=1` early exit and `run_manual_login` function unchanged):

```bash
if [ "${SKIP_LOGIN_LOG:-0}" = "1" ]; then
  run_manual_login
  exit 0
fi

mkdir -p logs
LOG_FILE="logs/manual-$(date +%Y%m%d-%H%M%S).log"
ANSI_STRIP=(sed -e 's/\x1b\[[0-9;]*[a-zA-Z]//g')

# Pipe-through logging buffers until the script exits; use exec + tee for live output.
exec > >(
  tee >("${ANSI_STRIP[@]}" >>"$LOG_FILE")
) 2>&1

echo "Log file: $LOG_FILE"
echo "================================================"
echo "Manual SSO login started: $(date -Iseconds)"
echo "Working directory: $SCRIPT_DIR"
echo "HEADED=${HEADED:-0}"
echo "================================================"

run_manual_login

echo "Manual SSO login finished: $(date -Iseconds)"
echo "Session file: ${SESSION_OUTPUT:-output/session.json}"
```

---

## 2. `run-scheduled-login.sh`

**Remove** the old piped block:

```bash
{
  echo "Scheduled SSO login started..."
  SKIP_LOGIN_LOG=1 ./run-manual-login.sh
  echo "Scheduled SSO login finished..."
} 2>&1 | tee -a "$LOG_FILE" >> logs/scheduled.log
```

**Replace** with:

```bash
mkdir -p logs
LOG_FILE="logs/scheduled-$(date +%Y%m%d-%H%M%S).log"
ANSI_STRIP=(sed -e 's/\x1b\[[0-9;]*[a-zA-Z]//g')

exec > >(
  tee >("${ANSI_STRIP[@]}" >>"$LOG_FILE") >("${ANSI_STRIP[@]}" >>logs/scheduled.log)
) 2>&1

echo "Log file: $LOG_FILE"
echo "================================================"
echo "Scheduled SSO login started: $(date -Iseconds)"
echo "Working directory: $SCRIPT_DIR"
echo "================================================"

SKIP_LOGIN_LOG=1 ./run-manual-login.sh

echo "Scheduled SSO login finished: $(date -Iseconds)"
echo "Session file: ${SESSION_OUTPUT:-output/session.json}"
```

---

## Logging behavior after fix

| Script | Log files |
|--------|-----------|
| `./run-manual-login.sh` | `logs/manual-*.log` |
| `./run-scheduled-login.sh` (9 PM cron) | `logs/scheduled-*.log`, `logs/scheduled.log` |
| Keep-alive loop (after SSO) | `logs/keepalive-loop.log` (unchanged) |

**Note:** `run-scheduled-login.sh` sets `SKIP_LOGIN_LOG=1` when calling `run-manual-login.sh` so output is not duplicated. Cron/scheduled runs log only to `scheduled-*.log`, not `manual-*.log`.

---

## Verify

```bash
cd resource-scheduler-sso-login
./run-manual-login.sh
```

You should see immediately:

```text
Log file: logs/manual-20260709-100500.log
================================================
Manual SSO login started: ...
```

In another terminal while SSO is running:

```bash
tail -f logs/manual-20260709-*.log
```

Lines should appear **live**, not only after the script finishes.

---

## Cursor AI prompt (copy/paste)

```text
Apply the log fix described in LOG-FIX-manual-login.md:
- Update run-manual-login.sh to use exec + tee instead of a piped subshell for logging
- Update run-scheduled-login.sh the same way
- Do not change run_manual_login() logic or SKIP_LOGIN_LOG behavior
```
