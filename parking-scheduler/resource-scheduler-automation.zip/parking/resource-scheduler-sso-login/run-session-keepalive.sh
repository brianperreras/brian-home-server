#!/bin/bash
# Ping the schedule page with saved session cookies (idle keep-alive).
# Does not run SSO — use run-manual-login.sh if this fails.
set -euo pipefail
set -o pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

# shellcheck source=../scripts/cron-env.sh
source "$(cd "$SCRIPT_DIR/.." && pwd)/scripts/cron-env.sh"

if [ -f "$SCRIPT_DIR/.env" ]; then
  # shellcheck disable=SC1091
  set -a
  source "$SCRIPT_DIR/.env"
  set +a
fi

mkdir -p logs
LOG_FILE="logs/keepalive-$(date +%Y%m%d-%H%M%S).log"

SSO_SUCCESS_MARKER="${SSO_SUCCESS_MARKER:-output/.sso-success-$(date +%Y%m%d)}"
if [ ! -f "$SSO_SUCCESS_MARKER" ]; then
  echo "No successful SSO today ($(date +%Y-%m-%d)); skipping keep-alive."
  echo "Run ./run-manual-login.sh or wait for the 9 PM SSO cron."
  exit 0
fi

{
  echo "================================================"
  echo "Session keep-alive started: $(date -Iseconds)"
  echo "Working directory: $SCRIPT_DIR"
  echo "================================================"

  if ! node src/session-keepalive.js; then
    echo "Session keep-alive failed: $(date -Iseconds)"
    exit 1
  fi

  echo "Session keep-alive finished: $(date -Iseconds)"
} 2>&1 | tee -a "$LOG_FILE" >> logs/keepalive.log
