#!/bin/bash
# Measure when Resource Scheduler SSO session expires.
#
# Examples:
#   ./run-session-expiry-probe.sh keepalive              # probe every 10m until fail
#   ./run-session-expiry-probe.sh keepalive 5            # probe every 5m
#   ./run-session-expiry-probe.sh idle 180               # wait 180m idle, probe once
#   ./run-session-expiry-probe.sh login-and-keepalive 10 # fresh SSO, then probe every 10m
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

# shellcheck source=../scripts/cron-env.sh
source "$(cd "$SCRIPT_DIR/.." && pwd)/scripts/cron-env.sh"

if [ -f "$SCRIPT_DIR/.env" ]; then
  # shellcheck disable=SC1091
  set -a
  source "$SCRIPT_DIR/.env"
  set +a
fi

mkdir -p logs
MODE="${1:-keepalive}"
INTERVAL="${2:-10}"
IDLE_WAIT="${2:-180}"

run_probe() {
  node src/session-expiry-probe.js "$@"
}

case "$MODE" in
  keepalive)
    echo "Keep-alive expiry probe: every ${INTERVAL}m until session fails (max 8h)"
    run_probe --mode keepalive --interval-minutes "$INTERVAL"
    ;;
  idle)
    echo "Idle expiry probe: wait ${IDLE_WAIT}m with no requests, then probe once"
    run_probe --mode idle --idle-wait-minutes "$IDLE_WAIT"
    ;;
  login-and-keepalive)
    echo "Fresh SSO login, then keep-alive probe every ${INTERVAL}m"
    SKIP_LOGIN_LOG=1 HEADED=0 ./run-manual-login.sh
    echo ""
    run_probe --mode keepalive --interval-minutes "$INTERVAL"
    ;;
  login-and-idle)
    echo "Fresh SSO login, then idle wait ${IDLE_WAIT}m before probe"
    SKIP_LOGIN_LOG=1 HEADED=0 ./run-manual-login.sh
    echo ""
    run_probe --mode idle --idle-wait-minutes "$IDLE_WAIT"
    ;;
  *)
    echo "Usage: $0 {keepalive [minutes]|idle [wait-minutes]|login-and-keepalive [minutes]|login-and-idle [wait-minutes]}" >&2
    exit 1
    ;;
esac
