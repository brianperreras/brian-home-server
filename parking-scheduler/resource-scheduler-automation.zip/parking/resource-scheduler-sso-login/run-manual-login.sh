#!/bin/bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

# shellcheck source=../scripts/cron-env.sh
source "$(cd "$SCRIPT_DIR/.." && pwd)/scripts/cron-env.sh"
# shellcheck source=../scripts/log.sh
source "$(cd "$SCRIPT_DIR/.." && pwd)/scripts/log.sh"

run_manual_login() {
  if [ ! -f .env ]; then
    log_error "Missing .env file. Copy .env.example to .env and configure credentials:"
    log_info "  cp .env.example .env"
    exit 1
  fi

  # shellcheck source=scripts/load-sso-credentials.sh
  set +e
  # shellcheck disable=SC1091
  source "$SCRIPT_DIR/scripts/load-sso-credentials.sh"
  load_status=$?
  set -e

  if [ "$load_status" -ne 0 ]; then
    log_error "Failed to load credentials."
    log_info "Set RS_USERNAME and RS_PASSWORD in .env (Unraid: /mnt/user/appdata/parking/config/.env)."
    exit 1
  fi

  if [ -z "${RS_USERNAME:-}" ] || [ -z "${RS_PASSWORD:-}" ]; then
    log_error "Missing credentials."
    log_info "Set RS_USERNAME and RS_PASSWORD in .env (Unraid: /mnt/user/appdata/parking/config/.env)."
    exit 1
  fi

  if ! command -v node >/dev/null 2>&1; then
    log_error "node not found on PATH. Install Node or fix cron PATH."
    exit 1
  fi

  if [ ! -d node_modules ]; then
    log_step "Installing dependencies..."
    npm install
    npx playwright install chromium
    log_ok "Dependencies installed"
  fi

  log_step "Running SSO login..."
  node src/sso-login.js

  # Mark today's SSO success so scheduled keep-alive crons know a session is valid.
  SSO_SUCCESS_MARKER="${SSO_SUCCESS_MARKER:-output/.sso-success-$(date +%Y%m%d)}"
  touch "$SSO_SUCCESS_MARKER"
  log_ok "SSO success marker: $SSO_SUCCESS_MARKER"

  log_step "Running session keep-alive..."
  node src/session-keepalive.js

  if [ "${SKIP_KEEPALIVE_LOOP:-0}" = "1" ]; then
    log_info "Skipping overnight keep-alive loop (SKIP_KEEPALIVE_LOOP=1)"
  else
    log_step "Starting keep-alive loop (every 5m until 12:05 AM)..."
    ./run-session-keepalive-loop.sh start
  fi
}

if [ "${SKIP_LOGIN_LOG:-0}" = "1" ]; then
  run_manual_login
  exit 0
fi

mkdir -p logs
LOG_FILE="logs/manual-$(date +%Y%m%d-%H%M%S).log"
if [ -t 1 ]; then
  parking_log_enable_color
  export PARKING_LOG_COLOR=1
  export FORCE_COLOR=1
fi
# Same pattern as resource-scheduler/run-multiple.sh — terminal + log file, line-by-line.
exec > >(tee >(sed -e 's/\x1b\[[0-9;]*[a-zA-Z]//g' >>"$LOG_FILE")) 2>&1

log_info "Log file: $LOG_FILE"
log_header "Manual SSO login"
log_kv "Started" "$(date -Iseconds)"
log_kv "Directory" "$SCRIPT_DIR"
log_kv "HEADED" "${HEADED:-0}"

run_manual_login

log_success "Manual SSO login finished: $(date -Iseconds)"
log_ok "Session file: ${SESSION_OUTPUT:-output/session.json}"
