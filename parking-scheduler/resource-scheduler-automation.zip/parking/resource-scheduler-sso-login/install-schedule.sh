#!/bin/bash
# Install evening SSO login + session keep-alive (evening before booking days).
# Linux: crontab | macOS: LaunchAgent (recommended for Face ID + browser UI)
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PARKING_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
SCHEDULER_DIR="$PARKING_DIR/resource-scheduler"
RUN_SCRIPT="$SCRIPT_DIR/run-scheduled-login.sh"
LABEL="com.asurion.resourcescheduler.sso-weekdays"

# shellcheck source=../scripts/cron-dow.sh
source "$PARKING_DIR/scripts/cron-dow.sh"
# shellcheck source=../scripts/log.sh
source "$PARKING_DIR/scripts/log.sh"

if [ -f "$SCRIPT_DIR/.env" ]; then
  # shellcheck disable=SC1091
  set -a
  source "$SCRIPT_DIR/.env"
  set +a
fi
if [ -f "$SCHEDULER_DIR/schedule.env" ]; then
  # shellcheck disable=SC1091
  set -a
  source "$SCHEDULER_DIR/schedule.env"
  set +a
fi

SCHEDULE_TZ="${SSO_SCHEDULE_TZ:-${RS_SCHEDULE_TZ:-Asia/Manila}}"
SCHEDULE_HOUR="${SSO_SCHEDULE_HOUR:-21}"
SCHEDULE_MINUTE="${SSO_SCHEDULE_MINUTE:-0}"
BOOK_DAYS="${RS_SCHEDULE_DAYS:-1-5}"
# Evening SSO = booking days − 1 (override with SSO_SCHEDULE_DAYS)
if [ -n "${SSO_SCHEDULE_DAYS:-}" ]; then
  SSO_DAYS="$SSO_SCHEDULE_DAYS"
else
  SSO_DAYS="$(shift_cron_dow "$BOOK_DAYS" -1)"
fi

chmod +x "$RUN_SCRIPT" "$SCRIPT_DIR/run-session-keepalive-loop.sh"

log_header "SSO schedule install"
log_kv "Days" "$SSO_DAYS"
log_kv "Time" "${SCHEDULE_HOUR}:$(printf '%02d' "$SCHEDULE_MINUTE") (${SCHEDULE_TZ})"
if [ -n "${SSO_SCHEDULE_DAYS:-}" ]; then
  log_info "SSO DOW from SSO_SCHEDULE_DAYS override"
else
  log_ok "SSO DOW = RS_SCHEDULE_DAYS − 1 (${BOOK_DAYS} → ${SSO_DAYS})"
fi
log_info "Keep-alive: every 5m until 12:05 AM after SSO succeeds"
log_kv "Script" "$RUN_SCRIPT"

install_cron() {
  # shellcheck source=../../scripts/install-crontab.sh
  bash "$PARKING_DIR/scripts/install-crontab.sh"
}

install_launchd() {
  local agents_dir="$HOME/Library/LaunchAgents"
  local plist_path="$agents_dir/${LABEL}.plist"
  local stdout_log="$SCRIPT_DIR/logs/launchd.out.log"
  local stderr_log="$SCRIPT_DIR/logs/launchd.err.log"
  local days_csv

  days_csv="$(expand_cron_dow "$SSO_DAYS" | paste -sd, -)"

  mkdir -p "$agents_dir" "$SCRIPT_DIR/logs"

  python3 - "$plist_path" "$LABEL" "$RUN_SCRIPT" "$SCHEDULE_HOUR" "$SCHEDULE_MINUTE" "$days_csv" "$stdout_log" "$stderr_log" <<'PY'
import plistlib
import sys
from pathlib import Path

plist_path, label, run_script, hour, minute, days_csv, stdout_log, stderr_log = sys.argv[1:9]
hour, minute = int(hour), int(minute)
days = [int(x) for x in days_csv.split(",") if x != ""]

intervals = [{"Weekday": d, "Hour": hour, "Minute": minute} for d in days]

data = {
    "Label": label,
    "ProgramArguments": [run_script],
    "StartCalendarInterval": intervals,
    "StandardOutPath": stdout_log,
    "StandardErrorPath": stderr_log,
    "RunAtLoad": False,
}

Path(plist_path).write_bytes(plistlib.dumps(data))
PY

  launchctl bootout "gui/$(id -u)/$LABEL" 2>/dev/null || true
  launchctl bootstrap "gui/$(id -u)" "$plist_path"

  log_ok "Installed LaunchAgent (macOS):"
  log_kv "Plist" "$plist_path"
  log_kv "Schedule" "Days ${SSO_DAYS} at ${SCHEDULE_HOUR}:$(printf '%02d' "$SCHEDULE_MINUTE") local Mac time"
  log_kv "Logs" "$stdout_log"
}

case "$(uname -s)" in
  Darwin)
    install_launchd
    ;;
  Linux)
    install_cron
    ;;
  *)
    log_error "Unsupported OS. Add this to your scheduler manually:"
    log_info "CRON_TZ=${SCHEDULE_TZ}"
    log_info "${SCHEDULE_MINUTE} ${SCHEDULE_HOUR} * * ${SSO_DAYS} ${RUN_SCRIPT}"
    exit 1
    ;;
esac

log_section "Pipeline"
log_info "SSO ${SSO_DAYS} @ ${SCHEDULE_HOUR}:$(printf '%02d' "$SCHEDULE_MINUTE") → keep-alive until 12:05 AM"
log_info "Booking days ${BOOK_DAYS} (SSO is evening-before unless SSO_SCHEDULE_DAYS override)"
log_success "SSO schedule installed"
log_info "Test: $RUN_SCRIPT"
log_info "Status: $SCRIPT_DIR/run-session-keepalive-loop.sh status"
log_info "Runs headless when HEADED=0 in .env"
