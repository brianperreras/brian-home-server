#!/bin/bash
# Scheduled SSO login (weekdays 9 PM). Same as run-manual-login.sh (headless by default).
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

# shellcheck source=../scripts/cron-env.sh
source "$(cd "$SCRIPT_DIR/.." && pwd)/scripts/cron-env.sh"
# shellcheck source=../scripts/log.sh
source "$(cd "$SCRIPT_DIR/.." && pwd)/scripts/log.sh"

mkdir -p logs
LOG_FILE="logs/scheduled-$(date +%Y%m%d-%H%M%S).log"
if [ -t 1 ]; then
  parking_log_enable_color
  export PARKING_LOG_COLOR=1
  export FORCE_COLOR=1
fi
LOG_PIPE="$(mktemp -u "${TMPDIR:-/tmp}/rs-scheduled-log.XXXXXX")"
mkfifo "$LOG_PIPE"
tee \
  >(sed -e 's/\x1b\[[0-9;]*[a-zA-Z]//g' >>"$LOG_FILE") \
  >(sed -e 's/\x1b\[[0-9;]*[a-zA-Z]//g' >>logs/scheduled.log) \
  <"$LOG_PIPE" &
LOG_TEE_PID=$!
exec >"$LOG_PIPE" 2>&1
trap 'exec >&- 2>&- || true; wait "$LOG_TEE_PID" 2>/dev/null || true; rm -f "$LOG_PIPE"' EXIT

log_info "Log file: $LOG_FILE"
log_header "Scheduled SSO login"
log_kv "Started" "$(date -Iseconds)"
log_kv "Directory" "$SCRIPT_DIR"

SKIP_LOGIN_LOG=1 ./run-manual-login.sh

log_success "Scheduled SSO login finished: $(date -Iseconds)"
log_ok "Session file: ${SESSION_OUTPUT:-output/session.json}"
