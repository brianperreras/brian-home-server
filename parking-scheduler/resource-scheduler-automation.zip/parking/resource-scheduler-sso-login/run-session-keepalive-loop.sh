#!/bin/bash
# Keep session alive with schedule-page pings every N minutes until booking time.
# Started automatically after 9 PM SSO — no second login needed.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

# shellcheck source=../scripts/cron-env.sh
source "$(cd "$SCRIPT_DIR/.." && pwd)/scripts/cron-env.sh"
# shellcheck source=../scripts/log.sh
source "$(cd "$SCRIPT_DIR/.." && pwd)/scripts/log.sh"

if [ -f "$SCRIPT_DIR/.env" ]; then
  # shellcheck disable=SC1091
  set -a
  source "$SCRIPT_DIR/.env"
  set +a
fi

KEEPALIVE_INTERVAL_MINUTES="${KEEPALIVE_INTERVAL_MINUTES:-5}"
KEEPALIVE_UNTIL_HOUR="${KEEPALIVE_UNTIL_HOUR:-0}"
KEEPALIVE_UNTIL_MINUTE="${KEEPALIVE_UNTIL_MINUTE:-5}"
KEEPALIVE_TZ="${KEEPALIVE_TZ:-${SSO_SCHEDULE_TZ:-Asia/Manila}}"
PID_FILE="${KEEPALIVE_PID_FILE:-output/.keepalive-loop.pid}"
LOG_FILE="${KEEPALIVE_LOOP_LOG:-logs/keepalive-loop.log}"

mkdir -p logs output

stop_existing_loop() {
  if [ ! -f "$PID_FILE" ]; then
    return 0
  fi

  local old_pid
  old_pid="$(cat "$PID_FILE" 2>/dev/null || true)"
  if [ -n "$old_pid" ] && kill -0 "$old_pid" 2>/dev/null; then
    log_info "Stopping previous keep-alive loop (pid $old_pid)"
    kill "$old_pid" 2>/dev/null || true
    wait "$old_pid" 2>/dev/null || true
  fi
  rm -f "$PID_FILE"
}

until_epoch() {
  "$PYTHON" - "$KEEPALIVE_TZ" "$KEEPALIVE_UNTIL_HOUR" "$KEEPALIVE_UNTIL_MINUTE" <<'PY'
import sys
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

tz = ZoneInfo(sys.argv[1])
target_hour = int(sys.argv[2])
target_minute = int(sys.argv[3])
now = datetime.now(tz)

target = now.replace(hour=target_hour, minute=target_minute, second=0, microsecond=0)
if target <= now:
    target += timedelta(days=1)

print(int(target.timestamp()))
PY
}

run_loop() {
  local until_epoch interval_seconds
  until_epoch="$(until_epoch)"
  interval_seconds=$((KEEPALIVE_INTERVAL_MINUTES * 60))

  {
    echo "================================================"
    echo "Keep-alive loop started: $(date -Iseconds)"
    echo "Interval: every ${KEEPALIVE_INTERVAL_MINUTES}m"
    echo "Until: ${KEEPALIVE_UNTIL_HOUR}:$(printf '%02d' "$KEEPALIVE_UNTIL_MINUTE") (${KEEPALIVE_TZ})"
    echo "PID: $$"
    echo "================================================"
  } >>"$LOG_FILE"

  while [ "$(date +%s)" -lt "$until_epoch" ]; do
    local stamp
    stamp="$(date -Iseconds)"
    if node src/session-keepalive.js >>"$LOG_FILE" 2>&1; then
      echo "[$stamp] keep-alive OK" >>"$LOG_FILE"
    else
      echo "[$stamp] keep-alive FAILED — session may be expired" >>"$LOG_FILE"
    fi

    if [ "$(date +%s)" -ge "$until_epoch" ]; then
      break
    fi
    sleep "$interval_seconds"
  done

  {
    echo "Keep-alive loop finished: $(date -Iseconds)"
    echo ""
  } >>"$LOG_FILE"
  rm -f "$PID_FILE"
}

case "${1:-start}" in
  start)
    stop_existing_loop
    run_loop &
    echo $! >"$PID_FILE"
    disown
    log_success "Keep-alive loop started (pid $(cat "$PID_FILE"), every ${KEEPALIVE_INTERVAL_MINUTES}m until ${KEEPALIVE_UNTIL_HOUR}:$(printf '%02d' "$KEEPALIVE_UNTIL_MINUTE") ${KEEPALIVE_TZ})"
    log_kv "Log" "$LOG_FILE"
    ;;
  stop)
    stop_existing_loop
    log_ok "Keep-alive loop stopped"
    ;;
  status)
    if [ -f "$PID_FILE" ] && kill -0 "$(cat "$PID_FILE")" 2>/dev/null; then
      log_ok "Keep-alive loop running (pid $(cat "$PID_FILE"))"
      exit 0
    fi
    log_warn "Keep-alive loop not running"
    exit 1
    ;;
  foreground)
    stop_existing_loop
    run_loop
    ;;
  *)
    log_error "Usage: $0 {start|stop|status|foreground}"
    exit 1
    ;;
esac
