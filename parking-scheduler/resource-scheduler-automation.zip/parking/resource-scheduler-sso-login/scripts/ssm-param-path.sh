#!/bin/bash
# Build SSM parameter path from SSO username: /credentials/<username>

SSM_PARAM_ROOT="/credentials"

ssm_param_path_for_username() {
  local username="$1"
  username="${username#"${username%%[![:space:]]*}"}"
  username="${username%"${username##*[![:space:]]}"}"

  if [ -z "$username" ]; then
    echo "Username is required to build SSM parameter path." >&2
    return 1
  fi

  if [[ "$username" == */* ]]; then
    echo "Username must not contain /." >&2
    return 1
  fi

  printf '%s/%s' "$SSM_PARAM_ROOT" "$username"
}
