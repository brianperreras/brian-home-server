#!/bin/bash
# Read user input from the controlling terminal when possible.

prompt_read() {
  local __var_name="$1"
  local prompt_text="$2"
  local secret="${3:-0}"
  local value=""
  local tty_path=""

  tty_path="$(tty 2>/dev/null || true)"

  if [ -n "$tty_path" ] && [ -r "$tty_path" ] && [ -w "$tty_path" ]; then
    if [ "$secret" = "1" ]; then
      printf '%s' "$prompt_text" >"$tty_path"
      IFS= read -rs value <"$tty_path"
      printf '\n' >"$tty_path"
    else
      printf '%s' "$prompt_text" >"$tty_path"
      IFS= read -r value <"$tty_path"
    fi
  elif [ -t 0 ]; then
    if [ "$secret" = "1" ]; then
      read -rsp "$prompt_text" value
      echo >&2
    else
      read -rp "$prompt_text" value
    fi
  fi

  if [ -z "$value" ]; then
    echo "$prompt_text" >&2
    echo "No terminal available for input. Set RS_USERNAME in .env or run from a terminal." >&2
    return 1
  fi

  printf -v "$__var_name" '%s' "$value"
}
