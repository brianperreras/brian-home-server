#!/usr/bin/env node
import crypto from 'node:crypto';
import { readFileSync } from 'node:fs';
import { pathToFileURL } from 'node:url';

const VERSION = 1;
const KDF_ITERATIONS = 310_000;
const SALT_BYTES = 16;
const IV_BYTES = 12;
const KEY_BYTES = 32;

export function encryptPlaintext(plaintext, passphrase) {
  const salt = crypto.randomBytes(SALT_BYTES);
  const iv = crypto.randomBytes(IV_BYTES);
  const key = crypto.pbkdf2Sync(passphrase, salt, KDF_ITERATIONS, KEY_BYTES, 'sha256');
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  const ciphertext = Buffer.concat([cipher.update(plaintext, 'utf8'), cipher.final()]);
  const tag = cipher.getAuthTag();

  return JSON.stringify({
    v: VERSION,
    kdf: 'pbkdf2-sha256',
    iterations: KDF_ITERATIONS,
    salt: salt.toString('base64'),
    iv: iv.toString('base64'),
    tag: tag.toString('base64'),
    ciphertext: ciphertext.toString('base64'),
  });
}

export function decryptPayload(encryptedJson, passphrase) {
  const data =
    typeof encryptedJson === 'string' ? JSON.parse(encryptedJson) : encryptedJson;

  if (data.v !== VERSION) {
    throw new Error(`Unsupported credential blob version: ${data.v ?? 'unknown'}`);
  }

  const salt = Buffer.from(data.salt, 'base64');
  const iv = Buffer.from(data.iv, 'base64');
  const tag = Buffer.from(data.tag, 'base64');
  const ciphertext = Buffer.from(data.ciphertext, 'base64');
  const iterations = data.iterations ?? KDF_ITERATIONS;
  const key = crypto.pbkdf2Sync(passphrase, salt, iterations, KEY_BYTES, 'sha256');
  const decipher = crypto.createDecipheriv('aes-256-gcm', key, iv);
  decipher.setAuthTag(tag);

  return Buffer.concat([decipher.update(ciphertext), decipher.final()]).toString('utf8');
}

export function isEncryptedPayload(value) {
  try {
    const data = JSON.parse(value);
    return (
      data.v === VERSION &&
      typeof data.ciphertext === 'string' &&
      typeof data.salt === 'string' &&
      typeof data.iv === 'string' &&
      typeof data.tag === 'string'
    );
  } catch {
    return false;
  }
}

function readPassphraseFromEnv() {
  if (process.env.RS_CREDENTIALS_PASSPHRASE) {
    return process.env.RS_CREDENTIALS_PASSPHRASE;
  }

  const file = process.env.RS_CREDENTIALS_PASSPHRASE_FILE?.trim();
  if (file) {
    return readFileSync(file, 'utf8').replace(/\r?\n$/, '');
  }

  return null;
}

function usage() {
  console.error(`Usage:
  credential-crypto.mjs encrypt [--stdin-plaintext]
  credential-crypto.mjs decrypt [--stdin-blob]
  credential-crypto.mjs is-encrypted <blob>

Passphrase via RS_CREDENTIALS_PASSPHRASE or RS_CREDENTIALS_PASSPHRASE_FILE.`);
}

async function readStdin() {
  const chunks = [];
  for await (const chunk of process.stdin) {
    chunks.push(chunk);
  }
  return Buffer.concat(chunks).toString('utf8');
}

async function main() {
  const [command, ...rest] = process.argv.slice(2);

  if (command === 'is-encrypted') {
    const blob = rest[0] ?? (await readStdin());
    process.stdout.write(isEncryptedPayload(blob.trim()) ? 'yes\n' : 'no\n');
    return;
  }

  const passphrase = readPassphraseFromEnv();
  if (!passphrase) {
    console.error('Set RS_CREDENTIALS_PASSPHRASE or RS_CREDENTIALS_PASSPHRASE_FILE.');
    process.exit(1);
  }

  if (command === 'encrypt') {
    const plaintext = rest[0] ?? (await readStdin());
    process.stdout.write(encryptPlaintext(plaintext.trimEnd(), passphrase));
    return;
  }

  if (command === 'decrypt') {
    const blob = rest[0] ?? (await readStdin());
    process.stdout.write(decryptPayload(blob.trim(), passphrase));
    return;
  }

  usage();
  process.exit(1);
}

const isMain = import.meta.url === pathToFileURL(process.argv[1]).href;
if (isMain) {
  main().catch((error) => {
    console.error(error.message);
    process.exit(1);
  });
}
