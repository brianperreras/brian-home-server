#!/bin/bash
# Load RS_USERNAME / RS_PASSWORD from environment or local .env only.
# Intended to be sourced from run-manual-login.sh (uses return, not exit).
# AWS SSM credential loading is disabled in this deployment.

_load_sso_credentials_from_env_file() {
  local key="$1"
  grep -E "^${key}=" .env 2>/dev/null | head -1 | cut -d= -f2- | sed 's/^["'\''"]//; s/["'\''"]$//' | tr -d '\r'
}

if [ -n "${RS_USERNAME:-}" ] && [ -n "${RS_PASSWORD:-}" ]; then
  return 0
fi

if [ -f .env ]; then
  env_user="$(_load_sso_credentials_from_env_file RS_USERNAME)"
  env_pass="$(_load_sso_credentials_from_env_file RS_PASSWORD)"
  if [ -n "$env_user" ]; then
    export RS_USERNAME="$env_user"
  fi
  if [ -n "$env_pass" ]; then
    export RS_PASSWORD="$env_pass"
  fi
  if [ -n "${RS_USERNAME:-}" ] && [ -n "${RS_PASSWORD:-}" ]; then
    return 0
  fi
fi

echo "Set RS_USERNAME and RS_PASSWORD in .env (Unraid: /mnt/user/appdata/parking/config/.env)." >&2
echo "AWS SSM credential loading is disabled in this deployment." >&2
return 1
