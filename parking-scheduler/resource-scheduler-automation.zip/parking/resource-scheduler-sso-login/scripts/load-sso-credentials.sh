#!/bin/bash
# Load RS_USERNAME / RS_PASSWORD from SSM Parameter Store when configured.
# Intended to be sourced from run-manual-login.sh (uses return, not exit).

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

# shellcheck source=scripts/ssm-param-path.sh
source "$(dirname "${BASH_SOURCE[0]}")/ssm-param-path.sh"

_load_sso_credentials_from_env_file() {
  local key="$1"
  grep -E "^${key}=" .env 2>/dev/null | head -1 | cut -d= -f2- | sed 's/^["'\''"]//; s/["'\''"]$//' | tr -d '\r'
}

if [ -n "${RS_USERNAME:-}" ] && [ -n "${RS_PASSWORD:-}" ]; then
  return 0
fi

if [ -f .env ]; then
  env_user="$(_load_sso_credentials_from_env_file RS_USERNAME)"
  env_pass="$(_load_sso_credentials_from_env_file RS_PASSWORD)"
  if [ -n "$env_user" ] && [ -n "$env_pass" ]; then
    export RS_USERNAME="$env_user"
    export RS_PASSWORD="$env_pass"
    return 0
  fi
fi

login_id="${RS_USERNAME:-}"
if [ -z "$login_id" ] && [ -f .env ]; then
  login_id="$(_load_sso_credentials_from_env_file RS_USERNAME)"
fi
if [ -z "$login_id" ]; then
  echo "Set RS_USERNAME in .env (SSM path: /credentials/<username>)." >&2
  return 1
fi

RS_SSM_CREDENTIALS_PARAM="$(ssm_param_path_for_username "$login_id")" || return 1

if ! command -v aws >/dev/null 2>&1; then
  echo "aws CLI not found. Install AWS CLI or set RS_USERNAME/RS_PASSWORD in .env." >&2
  return 1
fi

if ! command -v node >/dev/null 2>&1; then
  echo "node not found (needed to decrypt SSM credentials)." >&2
  return 1
fi

secret_blob=""
if ! secret_blob="$(aws ssm get-parameter \
  --name "$RS_SSM_CREDENTIALS_PARAM" \
  --with-decryption \
  --query 'Parameter.Value' \
  --output text 2>&1)"; then
  echo "Failed to fetch SSM parameter: $RS_SSM_CREDENTIALS_PARAM" >&2
  echo "$secret_blob" >&2
  return 1
fi

credentials_json="$secret_blob"
if [ "$(printf '%s' "$secret_blob" | node "$ROOT_DIR/scripts/credential-crypto.mjs" is-encrypted)" = "yes" ]; then
  # shellcheck source=read-passphrase.sh
  source "$(dirname "${BASH_SOURCE[0]}")/read-passphrase.sh" || return 1

  if ! credentials_json="$(printf '%s' "$secret_blob" | RS_CREDENTIALS_PASSPHRASE="$RS_CREDENTIALS_PASSPHRASE" node "$ROOT_DIR/scripts/credential-crypto.mjs" decrypt 2>&1)"; then
    echo "Failed to decrypt SSM credentials (wrong passphrase?)." >&2
    echo "$credentials_json" >&2
    return 1
  fi
fi

if ! eval "$(printf '%s' "$credentials_json" | python3 -c "
import json, shlex, sys

try:
    data = json.load(sys.stdin)
except json.JSONDecodeError as exc:
    print(f'echo Invalid credentials JSON: {exc} >&2', file=sys.stderr)
    sys.exit(1)

username = data.get('username', '')
password = data.get('password', '')
if not username or not password:
    print('echo Credentials JSON must include username and password keys >&2', file=sys.stderr)
    sys.exit(1)

print(f'export RS_USERNAME={shlex.quote(str(username))}')
print(f'export RS_PASSWORD={shlex.quote(str(password))}')
")"; then
  return 1
fi
