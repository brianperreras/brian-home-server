#!/bin/bash
# Resolve RS_CREDENTIALS_PASSPHRASE from env, file, or interactive prompt.
# Intended to be sourced (uses return).

_read_passphrase_from_env_file() {
  local key="$1"
  if [ ! -f .env ]; then
    return 0
  fi
  grep -E "^${key}=" .env 2>/dev/null | head -1 | cut -d= -f2- | sed 's/^["'\''"]//; s/["'\''"]$//' | tr -d '\r'
}

if [ -n "${RS_CREDENTIALS_PASSPHRASE:-}" ]; then
  return 0
fi

_expand_env_path() {
  local path="$1"
  path="${path/#\~/$HOME}"
  case "$path" in
    *\$HOME*) path="${path//\$HOME/$HOME}" ;;
  esac
  printf '%s' "$path"
}

if [ -z "${RS_CREDENTIALS_PASSPHRASE_FILE:-}" ] && [ -f .env ]; then
  RS_CREDENTIALS_PASSPHRASE_FILE="$(_read_passphrase_from_env_file RS_CREDENTIALS_PASSPHRASE_FILE)"
fi

if [ -n "${RS_CREDENTIALS_PASSPHRASE_FILE:-}" ]; then
  RS_CREDENTIALS_PASSPHRASE_FILE="$(_expand_env_path "$RS_CREDENTIALS_PASSPHRASE_FILE")"
fi

if [ -n "${RS_CREDENTIALS_PASSPHRASE_FILE:-}" ] && [ -f "$RS_CREDENTIALS_PASSPHRASE_FILE" ]; then
  RS_CREDENTIALS_PASSPHRASE="$(tr -d '\r\n' < "$RS_CREDENTIALS_PASSPHRASE_FILE")"
  export RS_CREDENTIALS_PASSPHRASE
  return 0
fi

if [ -t 0 ]; then
  read -rsp "Credentials passphrase: " RS_CREDENTIALS_PASSPHRASE
  echo >&2
  export RS_CREDENTIALS_PASSPHRASE
  return 0
fi

if [ -r /dev/tty ]; then
  read -rsp "Credentials passphrase: " RS_CREDENTIALS_PASSPHRASE </dev/tty
  echo >&2
  export RS_CREDENTIALS_PASSPHRASE
  return 0
fi

echo "Missing credentials passphrase." >&2
echo "Set RS_CREDENTIALS_PASSPHRASE_FILE in .env (for cron) or run interactively." >&2
return 1
