#!/bin/bash
# One-time setup: store client-encrypted SSO credentials in SSM Parameter Store.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR/.."

# shellcheck source=scripts/ssm-param-path.sh
source "$SCRIPT_DIR/ssm-param-path.sh"
# shellcheck source=scripts/prompt-input.sh
source "$SCRIPT_DIR/prompt-input.sh"

usage() {
  cat <<EOF
Usage: $0

Encrypts RS_USERNAME / RS_PASSWORD locally, then stores ciphertext in SSM.
Parameter path is derived from the username: /credentials/<username>

Username and password are always prompted interactively (unless set in the environment).
Passphrase: RS_CREDENTIALS_PASSPHRASE, RS_CREDENTIALS_PASSPHRASE_FILE, or prompt.

Requires: aws CLI with ssm:PutParameter permission.
EOF
}

if [ "${1:-}" = "-h" ] || [ "${1:-}" = "--help" ]; then
  usage
  exit 0
fi

if [ -n "${1:-}" ]; then
  echo "This script takes no arguments. Parameter path is derived from the SSO username." >&2
  exit 1
fi

AWS_REGION="${AWS_REGION:-${AWS_DEFAULT_REGION:-}}"

if ! command -v aws >/dev/null 2>&1; then
  echo "aws CLI not found." >&2
  exit 1
fi

if ! command -v node >/dev/null 2>&1; then
  echo "node not found." >&2
  exit 1
fi

if [ -z "${RS_USERNAME:-}" ]; then
  prompt_read RS_USERNAME "SSO username: " || exit 1
fi

if [ -z "${RS_PASSWORD:-}" ]; then
  prompt_read RS_PASSWORD "SSO password: " 1 || exit 1
fi

RS_USERNAME="${RS_USERNAME#"${RS_USERNAME%%[![:space:]]*}"}"
RS_USERNAME="${RS_USERNAME%"${RS_USERNAME##*[![:space:]]}"}"

if [ -z "$RS_USERNAME" ] || [ -z "$RS_PASSWORD" ]; then
  echo "Username and password are required." >&2
  exit 1
fi

PARAM_NAME="$(ssm_param_path_for_username "$RS_USERNAME")"

# shellcheck source=scripts/read-passphrase.sh
source "$SCRIPT_DIR/read-passphrase.sh"

plaintext="$(RS_USERNAME="$RS_USERNAME" RS_PASSWORD="$RS_PASSWORD" python3 -c "
import json, os
print(json.dumps({
    'username': os.environ['RS_USERNAME'],
    'password': os.environ['RS_PASSWORD'],
}))
")"

payload="$(printf '%s' "$plaintext" | RS_CREDENTIALS_PASSPHRASE="$RS_CREDENTIALS_PASSPHRASE" node scripts/credential-crypto.mjs encrypt)"

region_args=()
if [ -n "$AWS_REGION" ]; then
  region_args=(--region "$AWS_REGION")
fi

aws ssm put-parameter \
  "${region_args[@]}" \
  --name "$PARAM_NAME" \
  --type SecureString \
  --value "$payload" \
  --overwrite \
  --description "Client-encrypted Resource Scheduler SSO credentials"

echo "Stored encrypted credentials in SSM parameter: $PARAM_NAME"
echo "Add to .env:"
echo "  RS_USERNAME=$RS_USERNAME"
echo "  RS_CREDENTIALS_PASSPHRASE_FILE=\$HOME/.config/resource-scheduler/sso-passphrase"
echo "Do not store RS_PASSWORD in .env."
