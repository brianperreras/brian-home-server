#!/bin/bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
LABEL="com.asurion.resourcescheduler.sso-weekdays"
KEEPALIVE_LABEL="com.asurion.resourcescheduler.keepalive-weekdays"

case "$(uname -s)" in
  Darwin)
    launchctl bootout "gui/$(id -u)/$LABEL" 2>/dev/null || true
    rm -f "$HOME/Library/LaunchAgents/${LABEL}.plist"
    echo "Removed LaunchAgent: $LABEL"
    launchctl bootout "gui/$(id -u)/$KEEPALIVE_LABEL" 2>/dev/null || true
    rm -f "$HOME/Library/LaunchAgents/${KEEPALIVE_LABEL}.plist"
    echo "Removed legacy keep-alive LaunchAgent (if present): $KEEPALIVE_LABEL"
    "$SCRIPT_DIR/run-session-keepalive-loop.sh" stop 2>/dev/null || true
    ;;
  Linux)
    bash "$(cd "$SCRIPT_DIR/.." && pwd)/scripts/uninstall-crontab.sh"
    ;;
  *)
    echo "Remove scheduled job manually."
    exit 1
    ;;
esac
