---
name: update-parking-zip
description: >-
  Rebuilds resource-scheduler-automation.zip from the parking tree, excluding
  secrets and runtime junk. Use after any parking code or doc change, when the
  user asks to update the zip, or when packaging for distribution.
---

# Update parking distributable zip

## When to run

- After editing anything in this parking project (also part of `parking-post-change`)
- When the user says "update the zip" / "pack the zip"

## Steps

1. Run:

```bash
./scripts/pack-zip.sh
# or: parking pack-zip
```

Optional output path as first argument.

2. Verify secrets are absent:

```bash
unzip -Z1 ../resource-scheduler-automation.zip | grep -E '\.env$|schedule\.env$|resources\.txt$|reservation\.env$|session\.json$|node_modules|target/|logs/' || echo OK
```

3. Tell the user the zip path was refreshed.

## Exclusions (must keep)

`.env`, `session.json`, `schedule.env`, `resources.txt`, `reservation.env`, marker files, `logs/`, `target/`, `node_modules/`, passphrases, `*.log`, `*.class`
