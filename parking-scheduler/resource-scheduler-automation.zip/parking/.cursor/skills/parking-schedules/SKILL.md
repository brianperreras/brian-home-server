---
name: parking-schedules
description: >-
  Change parking SSO and booking cron days/times safely, then reinstall crontab.
  Use when editing schedule.env, SSO_SCHEDULE_*, RS_SCHEDULE_*, BOOK_PREWARM_*,
  or when the user asks to update cron, booking days, SSO schedule, evening-before
  SSO, or midnight prewarm / race-path timing.
---

# Parking cron schedules

## Config

| Setting | File |
|---------|------|
| Booking days + **submit** time | `resource-scheduler/schedule.env` → `RS_SCHEDULE_DAYS`, `RS_SCHEDULE_TIME` |
| Prewarm lead (minutes) | env `BOOK_PREWARM_MINUTES` when running `install-crontab.sh` (default `1`; `0` = fire at target HH:MM) |
| SSO clock | `resource-scheduler-sso-login/.env` → `SSO_SCHEDULE_HOUR`, `SSO_SCHEDULE_MINUTE` |
| SSO DOW override | same `.env` → `SSO_SCHEDULE_DAYS` (default = `RS_SCHEDULE_DAYS − 1`) |

DOW: `0=Sun … 6=Sat`. Example book `3-5` = Wed–Fri submit → SSO `2-4` (Tue–Thu) at 9 PM.

## SSO = evening before booking

Default SSO cron DOW is **`RS_SCHEDULE_DAYS − 1`** so login runs the night before midnight booking.

Example: book `2-5` (Tue–Fri) → SSO `1-4` (Mon–Thu) at 9 PM → keep-alive → book prewarm `23:59` Mon–Thu → submit `00:00` Tue–Fri.

## Race path (book cron)

`RS_SCHEDULE_TIME` is the submit target. Installer places the book cron **1 minute early** so `run-scheduled.sh` can:

1. Refresh session (keep-alive)
2. Compile Java
3. Wait until `RS_SCHEDULE_TIME`
4. Book with `SKIP_SSO_LOGIN=1` + `SKIP_COMPILE=1`

## Apply

```bash
parking install --schedules
# or: ./scripts/install-crontab.sh
parking crontab                 # human target time + notes
PARKING_CRON_RAW=1 parking crontab
```

## Remove

```bash
parking uninstall
```

## After changes

Follow skill `parking-post-change` (update AGENTS/rules/skills if needed, then pack zip).
