---
name: parking-post-change
description: >-
  After parking code or doc changes, update AGENTS.md, Cursor rules/skills,
  wire any new user-facing scripts into the parking CLI (bin/parking), then
  rebuild the distributable zip. Use at the end of parking work, when adding
  scripts, or when the user asks to sync agents/rules/skills/CLI.
---

# Parking post-change sync

## Checklist

Copy and complete:

```
- [ ] Behavior/commands/layout changed? → update AGENTS.md + rules + skills
- [ ] New user-facing .sh / entrypoint? → wire into bin/parking
- [ ] README mentions new command?
- [ ] ./scripts/pack-zip.sh ran successfully
```

## Wire a new script into `parking` CLI

Edit `bin/parking`:

1. Add `log_kv` line under **Commands** in `usage()`
2. Add a `case` branch (and aliases if useful)
3. Prefer:

```bash
banner_and_run "Short title" "$DIR" ./path/to/script.sh "$@"
```

4. Re-run `scripts/install-cli.sh` if the symlink might be stale (usually not needed; symlink points at `bin/parking`)
5. Update `AGENTS.md` common commands + `README.md` “Run from any directory”

## Pack zip

```bash
./scripts/pack-zip.sh
# or: parking pack-zip
```

Confirm secrets excluded.
