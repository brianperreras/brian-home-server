#!/bin/bash
# Pack parking/ into resource-scheduler-automation.zip (no secrets / runtime junk).
set -euo pipefail

PARKING_DIR="$(cd "$(dirname "$0")/.." && pwd)"
HOME_DIR="$(cd "$PARKING_DIR/.." && pwd)"
OUT_ZIP="${1:-$HOME_DIR/resource-scheduler-automation.zip}"
BAK_ZIP="${OUT_ZIP}.bak"

# shellcheck source=log.sh
source "$(dirname "$0")/log.sh"

cd "$HOME_DIR"

log_step "Packing parking/ → $OUT_ZIP"

# Keep only one previous zip: replace .bak and drop any old stamped backups
rm -f "${OUT_ZIP}".bak-*
if [ -f "$OUT_ZIP" ]; then
  cp -a "$OUT_ZIP" "$BAK_ZIP"
  log_info "Backup: $BAK_ZIP (1 previous only)"
fi

rm -f "$OUT_ZIP"

# Zip from parent so archive root is parking/
zip -r "$OUT_ZIP" "$(basename "$PARKING_DIR")" \
  -x 'parking/.git/*' \
  -x 'parking/.git/**' \
  -x 'parking/resource-scheduler-sso-login/node_modules/*' \
  -x 'parking/resource-scheduler-sso-login/node_modules/**' \
  -x 'parking/resource-scheduler/target/*' \
  -x 'parking/resource-scheduler/target/**' \
  -x 'parking/resource-scheduler/logs/*' \
  -x 'parking/resource-scheduler/logs/**' \
  -x 'parking/resource-scheduler-sso-login/logs/*' \
  -x 'parking/resource-scheduler-sso-login/logs/**' \
  -x 'parking/resource-scheduler-sso-login/.playwright/*' \
  -x 'parking/resource-scheduler-sso-login/.playwright/**' \
  -x 'parking/resource-scheduler-sso-login/.env' \
  -x 'parking/resource-scheduler-sso-login/output/session.json' \
  -x 'parking/resource-scheduler-sso-login/output/.keepalive-loop.pid' \
  -x 'parking/resource-scheduler-sso-login/output/.sso-success-*' \
  -x 'parking/resource-scheduler/schedule.env' \
  -x 'parking/resource-scheduler/resources.txt' \
  -x 'parking/resource-scheduler/reservation.env' \
  -x 'parking/resource-scheduler/.booking-configured' \
  -x 'parking/resource-scheduler/.reservation-configured' \
  -x 'parking/**/*.log' \
  -x 'parking/**/*.class' \
  -x 'parking/**/.DS_Store' \
  -x 'parking/resource-scheduler-sso-login/.credentials-passphrase' \
  -x 'parking/resource-scheduler-sso-login/sso-passphrase' \
  >/dev/null

log_success "Wrote: $OUT_ZIP"
log_kv "Size" "$(ls -lh "$OUT_ZIP" | awk '{print $5}')"

if unzip -Z1 "$OUT_ZIP" | grep -E '\.env$|schedule\.env$|resources\.txt$|reservation\.env$|session\.json$|node_modules|/target/|/logs/|\.git/' >/dev/null; then
  log_error "zip contains secrets or runtime paths"
  unzip -Z1 "$OUT_ZIP" | grep -E '\.env$|schedule\.env$|resources\.txt$|reservation\.env$|session\.json$|node_modules|/target/|/logs/|\.git/' >&2 || true
  exit 1
fi

log_ok "No secrets/logs/node_modules/target"
log_kv "Files" "$(unzip -Z1 "$OUT_ZIP" | wc -l)"
