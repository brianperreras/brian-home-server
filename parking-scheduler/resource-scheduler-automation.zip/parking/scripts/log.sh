#!/bin/bash
# Colored, classified terminal logging for parking scripts.
# Source this file; do not execute.
# Colors on when stdout is a TTY, or PARKING_LOG_COLOR=1 / FORCE_COLOR=1.
# Disable with NO_COLOR=1 or PARKING_LOG_COLOR=0.

_parking_log_use_color() {
  if [ "${NO_COLOR:-}" != "" ] || [ "${PARKING_LOG_COLOR:-}" = "0" ]; then
    return 1
  fi
  if [ "${PARKING_LOG_COLOR:-}" = "1" ] || [ "${FORCE_COLOR:-}" = "1" ]; then
    return 0
  fi
  [ -t 1 ]
}

_parking_log_init() {
  if _parking_log_use_color; then
    _LOG_RESET=$'\033[0m'
    _LOG_BOLD=$'\033[1m'
    _LOG_DIM=$'\033[2m'
    _LOG_RED=$'\033[31m'
    _LOG_GREEN=$'\033[32m'
    _LOG_YELLOW=$'\033[33m'
    _LOG_BLUE=$'\033[34m'
    _LOG_MAGENTA=$'\033[35m'
    _LOG_CYAN=$'\033[36m'
    _LOG_WHITE=$'\033[37m'
  else
    _LOG_RESET= _LOG_BOLD= _LOG_DIM=
    _LOG_RED= _LOG_GREEN= _LOG_YELLOW= _LOG_BLUE=
    _LOG_MAGENTA= _LOG_CYAN= _LOG_WHITE=
  fi
}

_parking_log_init

# Call after redirecting stdout (e.g. tee) if you captured TTY earlier.
parking_log_enable_color() {
  PARKING_LOG_COLOR=1
  _parking_log_init
}

_log_line() {
  local color="$1" icon="$2" label="$3" msg="$4"
  local color_msg="${5:-0}"
  if [ "$color_msg" = "1" ]; then
    # WARN / ERROR: color the tag and the message
    printf '%s%s%s %-7s %s%s\n' "${color}" "${_LOG_BOLD}" "$icon" "$label" "$msg" "${_LOG_RESET}"
  else
    printf '%s%s%s %-7s%s %s\n' "${color}" "${_LOG_BOLD}" "$icon" "$label" "${_LOG_RESET}" "$msg"
  fi
}

log_info()    { _log_line "$_LOG_CYAN"    "ℹ"  "INFO"    "$*"; }
log_ok()      { _log_line "$_LOG_GREEN"   "✔"  "OK"      "$*" 1; }
log_success() { _log_line "$_LOG_GREEN"   "✔"  "SUCCESS" "$*" 1; }
log_warn()    { _log_line "$_LOG_YELLOW"  "⚠"  "WARN"    "$*" 1 >&2; }
log_error()   { _log_line "$_LOG_RED"     "✖"  "ERROR"   "$*" 1 >&2; }
log_step()    { _log_line "$_LOG_BLUE"    "▸"  "STEP"    "$*"; }
log_debug()   { _log_line "$_LOG_DIM"     "·"  "DEBUG"   "$*"; }

log_header() {
  local title="$*"
  local bar
  bar="$(printf '─%.0s' {1..56})"
  printf '\n%s%s┌%s┐%s\n' "$_LOG_BOLD" "$_LOG_MAGENTA" "$bar" "$_LOG_RESET"
  printf '%s%s│ %-54s │%s\n' "$_LOG_BOLD" "$_LOG_MAGENTA" "$title" "$_LOG_RESET"
  printf '%s%s└%s┘%s\n\n' "$_LOG_BOLD" "$_LOG_MAGENTA" "$bar" "$_LOG_RESET"
}

# Colored box helper. $1=color $2=icon $3=title then key value pairs.
_log_colored_box() {
  local color="$1" icon="$2" title="$3"
  shift 3
  local bar
  bar="$(printf '─%.0s' {1..56})"
  printf '\n%s%s┌%s┐%s\n' "$_LOG_BOLD" "$color" "$bar" "$_LOG_RESET"
  printf '%s%s│ %s %-52s │%s\n' "$_LOG_BOLD" "$color" "$icon" "$title" "$_LOG_RESET"
  if [ "$#" -gt 0 ]; then
    printf '%s%s├%s┤%s\n' "$_LOG_BOLD" "$color" "$bar" "$_LOG_RESET"
    while [ "$#" -ge 2 ]; do
      local key="$1" value="$2"
      shift 2
      [ -z "$value" ] && continue
      printf '%s%s│ %-18s %-35s │%s\n' "$_LOG_BOLD" "$color" "$key" "$value" "$_LOG_RESET"
    done
  fi
  printf '%s%s└%s┘%s\n\n' "$_LOG_BOLD" "$color" "$bar" "$_LOG_RESET"
}

# Green success box: log_success_box "Booked" "Space" "P3-C18" "Date" "..."
log_success_box() {
  local title="$1"
  shift
  _log_colored_box "$_LOG_GREEN" "✔" "$title" "$@"
}

# Yellow warning box: log_warn_box "Booking limit" "Date" "..."
log_warn_box() {
  local title="$1"
  shift
  _log_colored_box "$_LOG_YELLOW" "⚠" "$title" "$@"
}

log_section() {
  local title="$*"
  printf '\n%s%s── %s %s%s\n' "$_LOG_BOLD" "$_LOG_CYAN" "$title" "$(printf '─%.0s' {1..40})" "$_LOG_RESET"
}

log_kv() {
  local key="$1"
  shift
  printf '   %s%-18s%s %s\n' "$_LOG_DIM" "$key" "$_LOG_RESET" "$*"
}
