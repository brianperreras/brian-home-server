#!/bin/bash
# Remove parking cron block (Linux).
set -euo pipefail

# shellcheck source=log.sh
source "$(dirname "${BASH_SOURCE[0]}")/log.sh"

MARKER_BEGIN="# >>> parking resource-scheduler (Asia/Manila)"
MARKER_END="# <<< parking resource-scheduler"

is_parking_line() {
  case "$1" in
    "$MARKER_BEGIN"|"$MARKER_END") return 0 ;;
    "# resource-scheduler-"*) return 0 ;;
    *resource-scheduler-sso-login*|*resource-scheduler-test*|*resource-scheduler/run-*|*resource-scheduler/install*) return 0 ;;
    *run-scheduled-login.sh*|*run-scheduled.sh*|*run-scheduled-reservations.sh*) return 0 ;;
    *run-session-keepalive.sh*) return 0 ;;
    CRON_TZ=Asia/Manila) return 0 ;;
  esac
  return 1
}

filter_crontab() {
  local in_block=0
  while IFS= read -r line || [ -n "$line" ]; do
    if [ "$line" = "$MARKER_BEGIN" ]; then
      in_block=1
      continue
    fi
    if [ "$line" = "$MARKER_END" ]; then
      in_block=0
      continue
    fi
    if [ "$in_block" -eq 1 ]; then
      continue
    fi
    if is_parking_line "$line"; then
      continue
    fi
    printf '%s\n' "$line"
  done
}

filter_crontab < <(crontab -l 2>/dev/null || true) | sed '/./,$!d' | crontab -
log_success "Removed parking resource-scheduler cron block"
