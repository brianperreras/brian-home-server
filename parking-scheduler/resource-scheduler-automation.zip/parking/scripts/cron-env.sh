#!/bin/bash
# Minimal environment for cron / launchd (no login shell PATH).
export HOME="${HOME:-$(getent passwd "$(whoami)" 2>/dev/null | cut -d: -f6)}"

if [ -s "${HOME}/.nvm/nvm.sh" ]; then
  export NVM_DIR="${HOME}/.nvm"
  # shellcheck source=/dev/null
  . "${NVM_DIR}/nvm.sh" --no-use 2>/dev/null || . "${NVM_DIR}/nvm.sh"
fi

# Prefer latest nvm node if not already on PATH
if ! command -v node >/dev/null 2>&1; then
  latest_node_bin="$(ls -1d "${HOME}/.nvm/versions/node/"*/bin 2>/dev/null | sort -V | tail -1)"
  if [ -n "$latest_node_bin" ]; then
    export PATH="${latest_node_bin}:${PATH:-}"
  fi
fi

export PATH="/usr/local/bin:/usr/bin:/bin:${PATH:-}"
export TZ="${TZ:-Asia/Manila}"
export PYTHON="${PYTHON:-$(command -v python3 2>/dev/null || echo /usr/bin/python3)}"
