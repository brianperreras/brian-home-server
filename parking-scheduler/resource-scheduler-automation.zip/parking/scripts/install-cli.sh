#!/bin/bash
# Put `parking` on PATH via ~/.local/bin (works from any directory).
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
CLI="$ROOT/bin/parking"
BIN_DIR="${PARKING_CLI_BIN_DIR:-$HOME/.local/bin}"
LINK="$BIN_DIR/parking"

# shellcheck source=log.sh
source "$(dirname "$0")/log.sh"

if [ ! -x "$CLI" ]; then
  chmod +x "$CLI"
fi

mkdir -p "$BIN_DIR"
ln -sfn "$CLI" "$LINK"
log_ok "Linked $LINK -> $CLI"

case ":$PATH:" in
  *":$BIN_DIR:"*) log_ok "$BIN_DIR already on PATH" ;;
  *)
    log_warn "$BIN_DIR is not on PATH in this shell"
    log_info "Open a new terminal, or run: export PATH=\"$BIN_DIR:\$PATH\""
    ;;
esac

log_success "You can run: parking help"
log_info "Examples: parking book | parking login | parking status"
