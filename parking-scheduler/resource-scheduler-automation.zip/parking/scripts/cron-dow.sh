#!/bin/bash
# Cron day-of-week helpers (0=Sun … 6=Sat).
# Source this file; do not execute.

# Expand cron-style DOW (e.g. 1-5,0,6) to one integer per line.
expand_cron_dow() {
  python3 - "$1" <<'PY'
import sys
raw = sys.argv[1].strip()
days = set()
for part in raw.split(","):
    part = part.strip()
    if not part:
        continue
    if "-" in part:
        a, b = part.split("-", 1)
        start, end = int(a), int(b)
        if start <= end:
            days.update(range(start, end + 1))
        else:
            days.update(range(start, 7))
            days.update(range(0, end + 1))
    else:
        days.add(int(part))
for d in sorted(days):
    if d < 0 or d > 6:
        raise SystemExit(f"Invalid DOW {d} in {raw!r} (0=Sun..6=Sat)")
    print(d)
PY
}

# Human-readable DOW: 1-5 → Mon–Fri, 2-5 → Tue–Fri, 1,3,5 → Mon, Wed, Fri
format_cron_dow() {
  python3 - "$1" <<'PY'
import sys
NAMES = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]
raw = sys.argv[1].strip()
days = set()
for part in raw.split(","):
    part = part.strip()
    if not part:
        continue
    if "-" in part:
        a, b = part.split("-", 1)
        start, end = int(a), int(b)
        if start <= end:
            days.update(range(start, end + 1))
        else:
            days.update(range(start, 7))
            days.update(range(0, end + 1))
    else:
        days.add(int(part))
ordered = sorted(days)
if not ordered:
    print("?")
    raise SystemExit(0)
for d in ordered:
    if d < 0 or d > 6:
        raise SystemExit(f"Invalid DOW {d} in {raw!r}")
# Contiguous range → Mon–Fri style
if len(ordered) > 1 and ordered == list(range(ordered[0], ordered[-1] + 1)):
    print(f"{NAMES[ordered[0]]}–{NAMES[ordered[-1]]}")
else:
    print(", ".join(NAMES[d] for d in ordered))
PY
}

# Shift cron DOW by N days (can be negative). Example: shift_cron_dow 2-5 -1 → 1-4
shift_cron_dow() {
  python3 - "$1" "$2" <<'PY'
import sys

raw = sys.argv[1].strip()
delta = int(sys.argv[2])

def expand(raw: str):
    days = set()
    for part in raw.split(","):
        part = part.strip()
        if not part:
            continue
        if "-" in part:
            a, b = part.split("-", 1)
            start, end = int(a), int(b)
            if start <= end:
                days.update(range(start, end + 1))
            else:
                days.update(range(start, 7))
                days.update(range(0, end + 1))
        else:
            days.add(int(part))
    return sorted(days)

def compress(days):
    if not days:
        return ""
    if len(days) > 1 and days == list(range(days[0], days[-1] + 1)):
        return f"{days[0]}-{days[-1]}"
    return ",".join(str(d) for d in days)

shifted = sorted({(d + delta) % 7 for d in expand(raw)})
print(compress(shifted))
PY
}

# Human-readable clock from cron minute + hour (and optional :SS)
# Args: minute hour [second]
format_cron_clock() {
  local minute="$1" hour="$2" second="${3:-}"
  python3 - "$minute" "$hour" "$second" <<'PY'
import sys
minute = int(sys.argv[1])
hour = int(sys.argv[2])
second = sys.argv[3].strip()
ampm = "AM" if hour < 12 else "PM"
h12 = hour % 12
if h12 == 0:
    h12 = 12
if second != "":
    print(f"{h12}:{minute:02d}:{int(second):02d} {ampm}")
else:
    print(f"{h12}:{minute:02d} {ampm}")
PY
}

# Summarize a parking cron line as human text.
# Prints: ROLE|WHEN|SCRIPT  (ROLE=SSO|Book)
format_parking_cron_line() {
  python3 - "$1" <<'PY'
import re
import sys

NAMES = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]
line = sys.argv[1].strip()
# minute hour dom month dow rest
m = re.match(
    r"^(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(.+)$",
    line,
)
if not m:
    print(f"?|{line}|")
    raise SystemExit(0)

minute, hour, _dom, _month, dow, rest = m.groups()
script = rest.split("#", 1)[0].strip()
role = "SSO" if "run-scheduled-login" in script else ("Book" if "run-scheduled.sh" in script else "Job")

def expand_dow(raw: str):
    days = set()
    for part in raw.split(","):
        part = part.strip()
        if not part:
            continue
        if "-" in part:
            a, b = part.split("-", 1)
            start, end = int(a), int(b)
            if start <= end:
                days.update(range(start, end + 1))
            else:
                days.update(range(start, 7))
                days.update(range(0, end + 1))
        else:
            days.add(int(part))
    return sorted(days)

def fmt_dow(raw: str) -> str:
    ordered = expand_dow(raw)
    if not ordered:
        return raw
    if len(ordered) > 1 and ordered == list(range(ordered[0], ordered[-1] + 1)):
        return f"{NAMES[ordered[0]]}–{NAMES[ordered[-1]]}"
    return ", ".join(NAMES[d] for d in ordered)

def fmt_clock(minute_s: str, hour_s: str) -> str:
    minute_i = int(minute_s)
    hour_i = int(hour_s)
    if hour_i == 0 and minute_i == 0:
        return "midnight"
    if hour_i == 12 and minute_i == 0:
        return "noon"
    ampm = "AM" if hour_i < 12 else "PM"
    h12 = hour_i % 12 or 12
    return f"{h12}:{minute_i:02d} {ampm}"

when = f"{fmt_dow(dow)} at {fmt_clock(minute, hour)}"
# Prefer short script basename for display
import os
base = os.path.basename(script.split()[0]) if script else ""
print(f"{role}|{when}|{base}")
PY
}
