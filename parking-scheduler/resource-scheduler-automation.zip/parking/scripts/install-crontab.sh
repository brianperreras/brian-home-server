#!/bin/bash
# Install both parking cron jobs as one clean block (Linux).
set -euo pipefail

# shellcheck source=log.sh
source "$(dirname "${BASH_SOURCE[0]}")/log.sh"

PARKING_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
SSO_DIR="$PARKING_DIR/resource-scheduler-sso-login"
SCHEDULER_DIR="$PARKING_DIR/resource-scheduler"

MARKER_BEGIN="# >>> parking resource-scheduler (Asia/Manila)"
MARKER_END="# <<< parking resource-scheduler"

if [ -f "$SSO_DIR/.env" ]; then
  # shellcheck disable=SC1091
  set -a
  source "$SSO_DIR/.env"
  set +a
fi
if [ -f "$SCHEDULER_DIR/schedule.env" ]; then
  # shellcheck disable=SC1091
  set -a
  source "$SCHEDULER_DIR/schedule.env"
  set +a
fi

SCHEDULE_TZ="${SSO_SCHEDULE_TZ:-${RS_SCHEDULE_TZ:-Asia/Manila}}"
SSO_HOUR="${SSO_SCHEDULE_HOUR:-21}"
SSO_MINUTE="${SSO_SCHEDULE_MINUTE:-0}"
BOOK_DAYS="${RS_SCHEDULE_DAYS:-1-5}"
BOOK_TIME="${RS_SCHEDULE_TIME:-}"

# Prefer RS_SCHEDULE_TIME (hh:mm:ss); fall back to legacy HOUR/MINUTE
if [ -n "$BOOK_TIME" ]; then
  if [[ ! "$BOOK_TIME" =~ ^([0-9]{1,2}):([0-9]{2})(:([0-9]{2}))?$ ]]; then
    log_error "Invalid RS_SCHEDULE_TIME='$BOOK_TIME' (use hh:mm:ss)"
    exit 1
  fi
  BOOK_HOUR="${BASH_REMATCH[1]}"
  BOOK_MINUTE="${BASH_REMATCH[2]}"
  BOOK_SECOND="${BASH_REMATCH[4]:-00}"
  # strip leading zeros for cron (but keep 0)
  BOOK_HOUR=$((10#$BOOK_HOUR))
  BOOK_MINUTE=$((10#$BOOK_MINUTE))
else
  BOOK_HOUR="${RS_SCHEDULE_HOUR:-0}"
  BOOK_MINUTE="${RS_SCHEDULE_MINUTE:-0}"
  BOOK_SECOND=0
  BOOK_TIME="$(printf '%02d:%02d:%02d' "$BOOK_HOUR" "$BOOK_MINUTE" "$BOOK_SECOND")"
fi

# Fire cron 1 minute early so run-scheduled.sh can refresh + compile before the target second.
# Example: target 00:00 Tue–Fri → cron 23:59 Mon–Thu.
BOOK_PREWARM_MINUTES="${BOOK_PREWARM_MINUTES:-1}"
CRON_BOOK_HOUR="$BOOK_HOUR"
CRON_BOOK_MINUTE="$BOOK_MINUTE"
CRON_BOOK_DAYS="$BOOK_DAYS"
if [ "$BOOK_PREWARM_MINUTES" -gt 0 ] 2>/dev/null; then
  read -r CRON_BOOK_MINUTE CRON_BOOK_HOUR CRON_BOOK_DAYS < <(
    python3 - "$BOOK_MINUTE" "$BOOK_HOUR" "$BOOK_DAYS" "$BOOK_PREWARM_MINUTES" <<'PY'
import sys

minute = int(sys.argv[1])
hour = int(sys.argv[2])
days_raw = sys.argv[3].strip()
lead = int(sys.argv[4])

total = hour * 60 + minute - lead
day_shift = 0
while total < 0:
    total += 24 * 60
    day_shift += 1
cron_hour, cron_minute = divmod(total, 60)

def expand(raw: str):
    days = set()
    for part in raw.split(","):
        part = part.strip()
        if not part:
            continue
        if "-" in part:
            a, b = part.split("-", 1)
            start, end = int(a), int(b)
            if start <= end:
                days.update(range(start, end + 1))
            else:
                days.update(range(start, 7))
                days.update(range(0, end + 1))
        else:
            days.add(int(part))
    return sorted(days)

def compress(days):
    if not days:
        return ""
    # Prefer a single range when contiguous
    if len(days) > 1 and days == list(range(days[0], days[-1] + 1)):
        return f"{days[0]}-{days[-1]}"
    return ",".join(str(d) for d in days)

shifted = sorted({(d - day_shift) % 7 for d in expand(days_raw)})
print(f"{cron_minute} {cron_hour} {compress(shifted)}")
PY
  )
fi

# shellcheck source=cron-dow.sh
source "$(dirname "${BASH_SOURCE[0]}")/cron-dow.sh"

# Evening SSO runs the day before booking (RS_SCHEDULE_DAYS − 1).
# Example: book Tue–Fri (2-5) → SSO Mon–Thu (1-4) at 9 PM.
# Override with SSO_SCHEDULE_DAYS if needed.
if [ -n "${SSO_SCHEDULE_DAYS:-}" ]; then
  SSO_DAYS="$SSO_SCHEDULE_DAYS"
else
  SSO_DAYS="$(shift_cron_dow "$BOOK_DAYS" -1)"
fi

SSO_SCRIPT="$SSO_DIR/run-scheduled-login.sh"
BOOK_SCRIPT="$SCHEDULER_DIR/run-scheduled.sh"
KEEPALIVE_LOOP_SCRIPT="$SSO_DIR/run-session-keepalive-loop.sh"

chmod +x "$SSO_SCRIPT" "$BOOK_SCRIPT" "$KEEPALIVE_LOOP_SCRIPT"

is_parking_line() {
  case "$1" in
    "$MARKER_BEGIN"|"$MARKER_END") return 0 ;;
    "# resource-scheduler-"*) return 0 ;;
    *resource-scheduler-sso-login*|*resource-scheduler-test*|*resource-scheduler/run-*|*resource-scheduler/install*) return 0 ;;
    *run-scheduled-login.sh*|*run-scheduled.sh*|*run-scheduled-reservations.sh*) return 0 ;;
    *run-session-keepalive.sh*) return 0 ;;
    CRON_TZ=Asia/Manila|CRON_TZ="${SCHEDULE_TZ}") return 0 ;;
  esac
  return 1
}

filter_crontab() {
  local in_block=0
  while IFS= read -r line || [ -n "$line" ]; do
    if [ "$line" = "$MARKER_BEGIN" ]; then
      in_block=1
      continue
    fi
    if [ "$line" = "$MARKER_END" ]; then
      in_block=0
      continue
    fi
    if [ "$in_block" -eq 1 ]; then
      continue
    fi
    if is_parking_line "$line"; then
      continue
    fi
    printf '%s\n' "$line"
  done
}

{
  filter_crontab < <(crontab -l 2>/dev/null || true)
  echo ""
  echo "$MARKER_BEGIN"
  echo "CRON_TZ=$SCHEDULE_TZ"
  echo "$SSO_MINUTE $SSO_HOUR * * $SSO_DAYS $SSO_SCRIPT    # evening-before SSO + keep-alive (book days ${BOOK_DAYS} − 1)"
  echo "$CRON_BOOK_MINUTE $CRON_BOOK_HOUR * * $CRON_BOOK_DAYS $BOOK_SCRIPT   # prewarm then book at ${BOOK_TIME}"
  echo "$MARKER_END"
} | sed '/./,$!d' | crontab -

log_success "Installed parking crontab block"
log_kv "Timezone" "$SCHEDULE_TZ"
log_kv "SSO cron" "${SSO_MINUTE} ${SSO_HOUR} * * ${SSO_DAYS}"
log_kv "Book cron" "${CRON_BOOK_MINUTE} ${CRON_BOOK_HOUR} * * ${CRON_BOOK_DAYS} (prewarm → ${BOOK_TIME})"
if [ "$BOOK_PREWARM_MINUTES" -gt 0 ] 2>/dev/null; then
  log_ok "Book cron starts ${BOOK_PREWARM_MINUTES}m early (refresh + compile before target)"
fi
if [ -n "${SSO_SCHEDULE_DAYS:-}" ]; then
  log_info "SSO DOW from SSO_SCHEDULE_DAYS override: ${SSO_DAYS}"
else
  log_ok "SSO DOW = RS_SCHEDULE_DAYS − 1 (${BOOK_DAYS} → ${SSO_DAYS})"
fi
log_section "Crontab block"
crontab -l | sed -n "/$(echo "$MARKER_BEGIN" | sed 's/[].[^$\\/*]/\\&/g')/,/$(echo "$MARKER_END" | sed 's/[].[^$\\/*]/\\&/g')/p"
