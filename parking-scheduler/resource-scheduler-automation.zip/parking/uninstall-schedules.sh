#!/bin/bash
# Remove parking SSO + booking cron (Linux) or LaunchAgents (macOS).
set -euo pipefail

PARKING_DIR="$(cd "$(dirname "$0")" && pwd)"

# shellcheck source=scripts/log.sh
source "$PARKING_DIR/scripts/log.sh"

log_header "Uninstall parking schedules"

case "$(uname -s)" in
  Darwin)
    log_step "Removing macOS LaunchAgents..."
    bash "$PARKING_DIR/resource-scheduler-sso-login/uninstall-schedule.sh"
    bash "$PARKING_DIR/resource-scheduler/uninstall-schedule.sh"
    ;;
  Linux)
    log_step "Removing parking crontab block..."
    bash "$PARKING_DIR/scripts/uninstall-crontab.sh"
    if [ -x "$PARKING_DIR/resource-scheduler-sso-login/run-session-keepalive-loop.sh" ]; then
      log_step "Stopping keep-alive loop (if running)..."
      "$PARKING_DIR/resource-scheduler-sso-login/run-session-keepalive-loop.sh" stop 2>/dev/null || true
    fi
    ;;
  *)
    log_error "Unsupported OS. Remove cron/LaunchAgents manually."
    exit 1
    ;;
esac

log_success "Schedules removed"
log_info "Verify with: parking crontab   (or crontab -l)"
