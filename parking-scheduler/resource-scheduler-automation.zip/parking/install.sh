#!/bin/bash
# Install parking automation (SSO login + booking) and configure credentials.
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
SSO_DIR="$ROOT/resource-scheduler-sso-login"
SCHEDULER_DIR="$ROOT/resource-scheduler"
PASSPHRASE_FILE="${RS_CREDENTIALS_PASSPHRASE_FILE:-$HOME/.config/resource-scheduler/sso-passphrase}"

SKIP_CREDENTIALS=0
INSTALL_SCHEDULES=0
RUN_LOGIN_TEST=0

usage() {
  cat <<EOF
Usage: $0 [options]

Installs dependencies for resource-scheduler-sso-login and resource-scheduler,
copies example config files, and configures encrypted SSM credentials.

Options:
  --skip-credentials   Install only (no passphrase / SSM upload)
  --schedules          Also install schedules (evening SSO, keep-alive, booking from schedule.env)
  --test-login         Run ./run-manual-login.sh after setup
  -h, --help           Show this help

Environment (non-interactive booking setup):
  RS_SLOTS             Comma-separated slots, e.g. R406,R405,R404
  RS_PRIMARY_SLOT      Legacy: primary slot (merged with RS_BACKUP_SLOT into RS_SLOTS)
  RS_BACKUP_SLOT       Legacy: optional backup slot
  RS_START_TIME        Parking slot start, e.g. "6 AM"
  RS_END_TIME          Parking slot end, e.g. "3 PM"

Interactive steps:
  1. Booking slots (comma-separated list) if not yet configured
  2. Reservation time window (start/end on the booked day) if not yet configured
  3. Create local passphrase file (~/.config/resource-scheduler/sso-passphrase)
  4. Set RS_USERNAME in .env
  5. Upload encrypted credentials to SSM (/credentials/<username>) — unless --skip-credentials

See INSTALL.md for full guide.
EOF
}

# shellcheck source=scripts/log.sh
source "$ROOT/scripts/log.sh"

# shellcheck source=resource-scheduler-sso-login/scripts/prompt-input.sh
source "$SSO_DIR/scripts/prompt-input.sh"

while [ $# -gt 0 ]; do
  case "$1" in
    --skip-credentials) SKIP_CREDENTIALS=1 ;;
    --schedules) INSTALL_SCHEDULES=1 ;;
    --test-login) RUN_LOGIN_TEST=1 ;;
    -h|--help) usage; exit 0 ;;
    *)
      log_error "Unknown option: $1"
      usage >&2
      exit 1
      ;;
  esac
  shift
done

require_cmd() {
  local cmd="$1"
  local hint="$2"
  if ! command -v "$cmd" >/dev/null 2>&1; then
    log_error "Missing required command: $cmd"
    log_info "$hint"
    exit 1
  fi
}

check_prerequisites() {
  log_step "Checking prerequisites..."
  require_cmd node "Install Node.js 18+"
  require_cmd npm "Install npm"
  require_cmd java "Install Java (JDK) for booking"
  require_cmd javac "Install JDK (javac) for booking"
  require_cmd python3 "Python 3 is used by shell helper scripts"
  if [ "$SKIP_CREDENTIALS" -eq 0 ]; then
    require_cmd aws "Install AWS CLI and configure credentials (role or aws sso login)"
  fi
  log_ok "Prerequisites OK"
  echo ""
}

set_env_value() {
  local file="$1"
  local key="$2"
  local value="$3"
  if grep -qE "^${key}=" "$file" 2>/dev/null; then
    sed -i "s|^${key}=.*|${key}=${value}|" "$file"
  else
    printf '%s=%s\n' "$key" "$value" >>"$file"
  fi
}

expand_home_path() {
  local path="$1"
  path="${path/#\~/$HOME}"
  case "$path" in
    *\$HOME*) path="${path//\$HOME/$HOME}" ;;
  esac
  printf '%s' "$path"
}

install_sso() {
  log_step "Installing resource-scheduler-sso-login..."
  cd "$SSO_DIR"
  npm install
  npm run install:browsers
  chmod +x run-manual-login.sh run-scheduled-login.sh run-session-keepalive.sh run-session-keepalive-loop.sh scripts/*.sh 2>/dev/null || true
  echo ""
}

install_test() {
  log_step "Installing resource-scheduler..."
  cd "$SCHEDULER_DIR"
  if [ ! -d lib ] || [ -z "$(ls -A lib/*.jar 2>/dev/null)" ]; then
    log_error "lib/*.jar not found. Add OkHttp (and okio/kotlin-stdlib) jars to lib/"
    exit 1
  fi
  mkdir -p target/classes logs/responses
  javac -cp "lib/*" -d target/classes src/main/java/com/apitest/reservation/*.java
  chmod +x run-manual.sh run-multiple.sh run-scheduled.sh scripts/*.sh 2>/dev/null || true
  log_ok "Booking Java compiled"
  echo ""
}

setup_config_files() {
  log_step "Config files..."
  cd "$SSO_DIR"
  if [ ! -f .env ]; then
    cp .env.example .env
    log_ok "Created resource-scheduler-sso-login/.env"
  else
    log_info "Keeping existing resource-scheduler-sso-login/.env"
  fi

  cd "$SCHEDULER_DIR"
  if [ ! -f schedule.env ]; then
    cp schedule.env.example schedule.env
    log_ok "Created resource-scheduler/schedule.env"
  fi
  echo ""
}

normalize_resource_id() {
  local id="${1// /}"
  id="${id^^}"
  if [[ "$id" =~ ^R[0-9]+$ ]]; then
    printf '%s\n' "$id"
  elif [[ "$id" =~ ^[0-9]+$ ]]; then
    printf 'R%s\n' "$id"
  else
    return 1
  fi
}

resource_topic_id() {
  local rid="$1"
  if [[ "$rid" =~ ^R([0-9]+)$ ]]; then
    echo "${BASH_REMATCH[1]}"
  else
    echo "$rid"
  fi
}

booking_slots_configured() {
  [ -f "$SCHEDULER_DIR/.booking-configured" ]
}

migrate_booking_configured_marker() {
  local marker="$SCHEDULER_DIR/.booking-configured"
  local resources="$SCHEDULER_DIR/resources.txt"
  if [ -f "$marker" ]; then
    return 0
  fi
  if [ -f "$resources" ] && grep -vE '^\s*(#|$)' "$resources" | grep -q .; then
    touch "$marker"
    log_ok "Booking slots already set in resources.txt (marker created)"
  fi
}

write_resources_file() {
  local file="$SCHEDULER_DIR/resources.txt"
  local slots=("$@")

  {
    echo "# Slot try order (configured by install.sh)"
    echo "# Tried sequentially until one books; then retries the list until timeout."
    echo "# Optional name comments: R405  # P2-C18  (see resources.txt.example for full car list)"
    local i=0
    for slot in "${slots[@]}"; do
      i=$((i + 1))
      if [ "$i" -eq 1 ]; then
        echo "# Primary (also used for SSO keep-alive TopicId)"
      else
        echo "# Backup $((i - 1))"
      fi
      echo "$slot"
    done
  } >"$file"
}

sync_sso_topic_env() {
  local primary="$1"
  local topic_id
  topic_id="$(resource_topic_id "$primary")"
  local schedule_url="https://asurion.resourcescheduler.net/ResourceScheduler/schedule.asp?Topic=RES&TopicId=${topic_id}&CDate=2026-1-1"

  set_env_value "$SSO_DIR/.env" "RS_TOPIC_ID" "$topic_id"
  set_env_value "$SSO_DIR/.env" "RS_SCHEDULE_URL" "$schedule_url"
}

# Parse comma/space-separated slot list into the named array (normalized, deduped, order preserved).
# Usage: parse_slot_list "R406, R405" SLOTS
parse_slot_list() {
  local raw="$1"
  local -n _slots_out="$2"
  local -a parts=()
  local part normalized existing seen

  _slots_out=()
  IFS=',' read -ra parts <<<"$raw"
  for part in "${parts[@]}"; do
    part="$(printf '%s' "$part" | sed -E 's/^[[:space:]]+//; s/[[:space:]]+$//')"
    [ -z "$part" ] && continue
    if ! normalized="$(normalize_resource_id "$part")"; then
      log_error "Invalid slot ID: $part (use R123 or 123)"
      return 1
    fi
    seen=0
    for existing in "${_slots_out[@]+"${_slots_out[@]}"}"; do
      if [ "$existing" = "$normalized" ]; then
        seen=1
        break
      fi
    done
    if [ "$seen" -eq 0 ]; then
      _slots_out+=("$normalized")
    fi
  done

  if [ ${#_slots_out[@]} -eq 0 ]; then
    log_error "At least one slot is required"
    return 1
  fi
  return 0
}

configure_booking_slots() {
  migrate_booking_configured_marker

  if booking_slots_configured; then
    # shellcheck source=resource-scheduler/scripts/read-resources.sh
    source "$SCHEDULER_DIR/scripts/read-resources.sh"
    read_resources "$SCHEDULER_DIR/resources.txt"
    log_ok "Booking slots already configured: ${RESOURCES[*]}"
    echo ""
    return 0
  fi

  local -a SLOTS=()
  local slots_raw=""

  if [ -n "${RS_SLOTS:-}" ]; then
    slots_raw="$RS_SLOTS"
  elif [ -n "${RS_PRIMARY_SLOT:-}" ]; then
    slots_raw="$RS_PRIMARY_SLOT"
    if [ -n "${RS_BACKUP_SLOT:-}" ]; then
      slots_raw="${slots_raw},${RS_BACKUP_SLOT}"
    fi
  else
    local tty_path=""
    tty_path="$(tty 2>/dev/null || true)"
    if [ -z "$tty_path" ] && [ ! -t 0 ]; then
      log_error "Booking slots not configured"
      log_info "Run from a terminal, or set RS_SLOTS=R406,R405, or edit resources.txt and touch .booking-configured"
      exit 1
    fi

    log_step "Booking slots (resources.txt)..."
    log_info "Enter slot IDs in try order, comma-separated (e.g. R406, R405, R404)"
    log_info "Exactly one reservation is booked; list is retried until success or timeout"
    echo ""

    while [ ${#SLOTS[@]} -eq 0 ]; do
      prompt_read slots_raw "Slots: " || true
      if [ -z "$slots_raw" ]; then
        log_error "At least one slot is required"
        continue
      fi
      if ! parse_slot_list "$slots_raw" SLOTS; then
        SLOTS=()
        continue
      fi
    done
  fi

  if [ ${#SLOTS[@]} -eq 0 ]; then
    if ! parse_slot_list "$slots_raw" SLOTS; then
      exit 1
    fi
  fi

  write_resources_file "${SLOTS[@]}"
  sync_sso_topic_env "${SLOTS[0]}"
  touch "$SCHEDULER_DIR/.booking-configured"

  log_success "Saved slots (try order): ${SLOTS[*]}"
  log_ok "Updated .env RS_TOPIC_ID and RS_SCHEDULE_URL for SSO keep-alive (first slot)"
  echo ""
}

format_rs_time_display() {
  printf '%s\n' "${1//+/ }"
}

normalize_rs_time() {
  local input="$1"
  input="${input^^}"
  input="$(printf '%s' "$input" | sed -E 's/[[:space:]]+/ /g; s/:00//g; s/^[[:space:]]+//; s/[[:space:]]+$//')"
  if [[ "$input" =~ ^([0-9]{1,2})[[:space:]]+(AM|PM)$ ]]; then
    printf '%s+%s\n' "${BASH_REMATCH[1]}" "${BASH_REMATCH[2]}"
    return 0
  fi
  if [[ "$input" =~ ^([0-9]{1,2})\+(AM|PM)$ ]]; then
    printf '%s+%s\n' "${BASH_REMATCH[1]}" "${BASH_REMATCH[2]}"
    return 0
  fi
  return 1
}

reservation_times_configured() {
  [ -f "$SCHEDULER_DIR/.reservation-configured" ]
}

migrate_reservation_configured_marker() {
  local marker="$SCHEDULER_DIR/.reservation-configured"
  local reservation="$SCHEDULER_DIR/reservation.env"
  if [ -f "$marker" ]; then
    return 0
  fi
  # Upgrade path: user hand-edited reservation.env before .reservation-configured existed
  if [ -f "$reservation" ] && grep -qE '^RS_START_HR=' "$reservation" && grep -qE '^RS_END_HR=' "$reservation"; then
    if [ -f "$SCHEDULER_DIR/.booking-configured" ]; then
      touch "$marker"
      log_ok "Reservation times already set in reservation.env (marker created)"
    fi
  fi
}

write_reservation_env() {
  local start_hr="$1"
  local end_hr="$2"
  local file="$SCHEDULER_DIR/reservation.env"

  {
    echo "# Parking slot time window (configured by install.sh)"
    echo "# Resource Scheduler form format: HOUR+AM or HOUR+PM"
    echo "RS_START_HR=$start_hr"
    echo "RS_END_HR=$end_hr"
  } >"$file"
}

configure_reservation_times() {
  migrate_reservation_configured_marker

  if reservation_times_configured; then
    # shellcheck source=resource-scheduler/scripts/load-reservation-env.sh
    source "$SCHEDULER_DIR/scripts/load-reservation-env.sh"
    load_reservation_env "$SCHEDULER_DIR"
    log_ok "Reservation times already configured: $(format_rs_time_display "$RS_START_HR") – $(format_rs_time_display "$RS_END_HR")"
    echo ""
    return 0
  fi

  local start_input="" end_input="" start_hr="" end_hr=""

  if [ -n "${RS_START_TIME:-}" ] && [ -n "${RS_END_TIME:-}" ]; then
    if ! start_hr="$(normalize_rs_time "$RS_START_TIME")"; then
      log_error "Invalid RS_START_TIME: $RS_START_TIME (use 6 AM or 6+AM)"
      exit 1
    fi
    if ! end_hr="$(normalize_rs_time "$RS_END_TIME")"; then
      log_error "Invalid RS_END_TIME: $RS_END_TIME (use 3 PM or 3+PM)"
      exit 1
    fi
  else
    local tty_path=""
    tty_path="$(tty 2>/dev/null || true)"
    if [ -z "$tty_path" ] && [ ! -t 0 ]; then
      log_error "Reservation times not configured"
      log_info "Run from a terminal, or set RS_START_TIME / RS_END_TIME, or edit reservation.env and touch .reservation-configured"
      exit 1
    fi

    log_step "Reservation time window (reservation.env)..."
    log_info "Parking slot start/end on the booked day (e.g. 6 AM, 3 PM)"
    echo ""

    while [ -z "$start_hr" ]; do
      prompt_read start_input "Start time [6 AM]: " || true
      start_input="${start_input:-6 AM}"
      if ! start_hr="$(normalize_rs_time "$start_input")"; then
        log_error "Invalid start time: $start_input (use 6 AM or 6+AM)"
        start_hr=""
      fi
    done

    while [ -z "$end_hr" ]; do
      prompt_read end_input "End time [3 PM]: " || true
      end_input="${end_input:-3 PM}"
      if ! end_hr="$(normalize_rs_time "$end_input")"; then
        log_error "Invalid end time: $end_input (use 3 PM or 3+PM)"
        end_hr=""
      fi
    done
  fi

  write_reservation_env "$start_hr" "$end_hr"
  touch "$SCHEDULER_DIR/.reservation-configured"
  log_success "Saved: $(format_rs_time_display "$start_hr") – $(format_rs_time_display "$end_hr")"
  echo ""
}

setup_passphrase_file() {
  PASSPHRASE_FILE="$(expand_home_path "$PASSPHRASE_FILE")"
  mkdir -p "$(dirname "$PASSPHRASE_FILE")"

  if [ -f "$PASSPHRASE_FILE" ]; then
    log_ok "Passphrase file already exists: $PASSPHRASE_FILE"
    return 0
  fi

  log_step "Create local passphrase (never uploaded to AWS)..."
  local pass1 pass2
  prompt_read pass1 "Choose a credentials passphrase: " 1 || exit 1
  prompt_read pass2 "Confirm passphrase: " 1 || exit 1
  if [ "$pass1" != "$pass2" ]; then
    log_error "Passphrases do not match"
    exit 1
  fi
  printf '%s' "$pass1" >"$PASSPHRASE_FILE"
  chmod 600 "$PASSPHRASE_FILE"
  unset pass1 pass2
  log_ok "Saved: $PASSPHRASE_FILE"
  echo ""
}

configure_username() {
  log_step "SSO username (.env)..."
  cd "$SSO_DIR"
  local current=""
  current="$(grep -E '^RS_USERNAME=' .env 2>/dev/null | head -1 | cut -d= -f2- | tr -d '\r' || true)"

  if [ -n "$current" ]; then
    log_info "Current RS_USERNAME in .env: $current"
    if [ -t 0 ] || [ -n "$(tty 2>/dev/null || true)" ]; then
      local answer=""
      prompt_read answer "Use this username? [Y/n]: " || true
      if [ -z "$answer" ] || [[ "$answer" =~ ^[Yy]$ ]]; then
        RS_USERNAME="$current"
      fi
    else
      RS_USERNAME="$current"
    fi
  fi

  if [ -z "${RS_USERNAME:-}" ]; then
    prompt_read RS_USERNAME "SSO username: " || exit 1
  fi

  set_env_value "$SSO_DIR/.env" "RS_USERNAME" "$RS_USERNAME"
  set_env_value "$SSO_DIR/.env" "RS_CREDENTIALS_PASSPHRASE_FILE" '$HOME/.config/resource-scheduler/sso-passphrase'
  export RS_USERNAME
  export RS_CREDENTIALS_PASSPHRASE_FILE="$PASSPHRASE_FILE"
  echo ""
}

upload_credentials() {
  log_step "Upload encrypted credentials to SSM..."
  cd "$SSO_DIR"
  export RS_CREDENTIALS_PASSPHRASE_FILE="$PASSPHRASE_FILE"
  ./scripts/put-sso-credentials-to-ssm.sh
  echo ""
}

install_schedules() {
  log_step "Installing weekday schedules..."
  (cd "$SSO_DIR" && ./install-schedule.sh)
  echo ""
  (cd "$SCHEDULER_DIR" && ./install-schedule.sh)
  echo ""
}

main() {
  log_header "Parking automation setup"

  check_prerequisites
  install_sso
  install_test
  setup_config_files
  configure_booking_slots
  configure_reservation_times

  if [ "$SKIP_CREDENTIALS" -eq 0 ]; then
    setup_passphrase_file
    configure_username
    upload_credentials
  else
    log_info "Skipped credential setup (--skip-credentials)"
    echo ""
  fi

  if [ "$INSTALL_SCHEDULES" -eq 1 ]; then
    install_schedules
  fi

  log_step "Installing parking CLI on PATH..."
  bash "$ROOT/scripts/install-cli.sh"

  log_success "Setup complete"
  echo ""
  if [ "$INSTALL_SCHEDULES" -eq 1 ]; then
    log_section "Cron is installed"
    log_ok "Evening SSO + midnight booking are on the crontab"
    log_info "Check: parking crontab   (or crontab -l)"
    log_info "Optional manual test: parking book"
  else
    log_section "Next steps"
    log_info "Manual book: parking book"
    log_info "SSO only: parking login"
    log_info "Enable cron: parking install --schedules"
  fi

  if [ "$RUN_LOGIN_TEST" -eq 1 ]; then
    echo ""
    log_step "Testing SSO login..."
    (cd "$SSO_DIR" && ./run-manual-login.sh)
  fi
}

main
